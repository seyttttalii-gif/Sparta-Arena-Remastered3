[app]
title = Sparta Arena
package.name = spartaarena
package.domain = world.sparta
source.dir = app
source.include_exts = py,json,png,jpg,jpeg,ogg,wav,ttf
source.exclude_dirs = __pycache__,.git
version = 0.57.0
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.api = 35
android.minapi = 24
android.archs = arm64-v8a,armeabi-v7a
android.allow_backup = True
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.private_storage = True
android.debug_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 1
