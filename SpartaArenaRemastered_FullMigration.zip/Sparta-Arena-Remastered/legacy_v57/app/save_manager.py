# SPARTA ARENA - Android-safe JSON save manager
import json
import os

SAVE_FILES = {
    "profile": "sparta_arena_profile.json",
    "settings": "settings.json",
    "achievements": "achievements.json",
    "world": "world_conquest.json",
    "sea": "sea_progress.json",
}

DEFAULTS = {
    "profile": {
        "player_name": "Spartalı",
        "language": "tr",
        "gold": 0,
        "selected_character": "Gladyatör"
    },
    "settings": {
        "music_enabled": True,
        "sfx_enabled": True,
        "music_volume": 0.7,
        "sfx_volume": 0.8,
        "control_mode": "analog"
    },
    "achievements": {},
    "world": {
        "hero_name": "Spartalı",
        "kingdom_name": "Yeni Krallık",
        "kingdom_created": False
    },
    "sea": {
        "rod_level": 1,
        "fish_collection": [],
        "islands_discovered": []
    }
}

def _base_dir():
    # Android/Pydroid/Desktop için güvenli, yazılabilir klasör
    try:
        from android.storage import app_storage_path
        return app_storage_path()
    except Exception:
        return os.path.join(os.path.dirname(__file__), "data")

def _path(kind):
    os.makedirs(_base_dir(), exist_ok=True)
    return os.path.join(_base_dir(), SAVE_FILES[kind])

def load(kind):
    path = _path(kind)
    default = DEFAULTS[kind].copy()
    try:
        with open(path, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            default.update(loaded)
    except Exception:
        pass
    return default

def save(kind, data):
    path = _path(kind)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def ensure_all():
    for kind in SAVE_FILES:
        data = load(kind)
        save(kind, data)
