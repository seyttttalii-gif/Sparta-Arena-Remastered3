# SPARTA ARENA V55 - LEGENDS EXPANSION
# V47 menusu, haritalari ve oyun modlari korunmustur.
import pygame, random, math, json, os, sys, struct



# ============================================================
# V55 LEGENDS EXPANSION - NEW CONTENT
# ============================================================
V55_FEATURES = {
    "graphics": ["daha katmanli menu arka plani", "karakter ekipman detaylari",
                 "arena atmosferi", "daha zengin dunya ve deniz dekorlari"],
    "characters": ["Kuzey Kralicesi", "Roma Centurionu", "Samuray Ustasi", "Cöl Krali"],
    "world": ["gezgin olaylari", "sehir itibar sistemi", "kervan ve yol riskleri"],
    "sea": ["balik koleksiyonu", "olta ustaligi", "ada kesif gunlugu"],
    "shop": ["iksir paketi", "nadir ekipman", "guncellenmis kategori mantigi"],
    "achievements": ["120 Tur Efsanesi", "Demirin Efendisi", "Deniz Kasifi"]
}

def v55_progress_defaults():
    return {
        "city_reputation": {},
        "sea_fish_collection": [],
        "sea_rod_mastery": 0,
        "world_events_seen": [],
        "v55_daily_chest_claimed": False,
        "v55_legend_rank": 0,
    }

def v55_migrate_save(data):
    for k,v in v55_progress_defaults().items():
        data.setdefault(k,v)
    return data

# ============================================================
# V54 WORLD CONQUEST EXPANSION
# ============================================================
V54_FEATURES = {
    "world_conquest": ["Warband tarzı şehir girişleri", "oyuncu ve devlet adı",
                       "devlet kurma", "dağ-yol-köy-liman detayları",
                       "pazar-han-garnizon-yönetim"],
    "classic": "30/60/90/120 tur devam sistemi ve başarı",
    "hill": "güçlü itme ve rastgele güçlendirmeler",
    "endless": "150 düşman başarısı ve Demir Kılıç",
    "sea": "olta seviyeleri, nadir balıklar, dalgalar, adalar ve hazineler",
    "shop": "iksirler, ekipmanlar ve nadirlikler",
    "boss": "faz sistemi ve özel saldırılar"
}

def v54_default_progress():
    return {
        "hero_name": "Spartalı",
        "kingdom_name": "Yeni Krallık",
        "kingdom_created": False,
        "kingdom_banner": 0,
        "classic_stage": 1,
        "classic_max_round": 30,
        "classic_finished_120": False,
        "classic_legend_achievement": False,
        "endless_kills_total": 0,
        "iron_sword_unlocked": False,
        "hill_powerups_enabled": True,
        "sea_rod_level": 1,
        "sea_map_fragments": 0,
        "sea_islands_discovered": [],
    }

def v54_migrate_save(data):
    for key, value in v54_default_progress().items():
        data.setdefault(key, value)
    if isinstance(data.get("conquest"), dict):
        c = data["conquest"]
        c.setdefault("hero_name", data["hero_name"])
        c.setdefault("kingdom_name", data["kingdom_name"])
        c.setdefault("kingdom_created", data["kingdom_created"])
        c.setdefault("kingdom_banner", data["kingdom_banner"])
        c.setdefault("city_visit_mode", "warband")
    if isinstance(data.get("sea"), dict):
        data["sea"].setdefault("rod_level", data["sea_rod_level"])
        data["sea"].setdefault("map_fragments", data["sea_map_fragments"])
        data["sea"].setdefault("islands_discovered", data["sea_islands_discovered"])
    return data

# ============================================================
# SPARTA ARENA V46 - BUYUK GUNCELLEME: ATMOSFER, BASARILAR, GUNLUK ODUL
# Duzeltmeler:
# - Ana menude karakter secme yok
# - Cengiz Han ozel ve kilitli karakter
# - Karakter yuzleri/zırhlari gelistirildi
# - Guzel cizimli 5 harita
# - Ayi modu yeniden yapildi
# - Hareket tuslari tam ve ekrana sigacak sekilde
# ============================================================

pygame.init()
pygame.font.init()

try:
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
except:
    screen = pygame.display.set_mode((1280, 720))

W, H = screen.get_size()
clock = pygame.time.Clock()
FPS = 60

def font(size):
    return pygame.font.SysFont(None, max(18, int(size)))

FS = font(H * .032)
FM = font(H * .045)
FB = font(H * .062)
FT = font(H * .080)

# COLORS
WHITE=(245,246,250); BLACK=(15,18,25); GOLD=(245,195,55)
RED=(205,55,48); GREEN=(55,180,90); BLUE=(50,105,205)
PURPLE=(120,65,170); BROWN=(125,78,40); DARK=(34,40,53)
GRAY=(75,84,98); SKY=(105,165,205); SILVER=(190,195,205)
ORANGE=(235,125,35); ICE=(180,225,245)

SAVE_FILE = "sparta_arena_v4_save.json"

def default_data():
    return {
        "gold": 500,
        "bear_gold": 0,
        "map_gold": [0, 0, 0, 0, 0, 0, 0, 0],
        "diamonds": 0,
        "damage": 25,
        "speed": 0,
        "potions": 1,
        "full_potions": 0,
        "arrows": 0,
        "classic_wins": 0,
        "selected_char": 0,
        "conquest": None,
        "mode_game": None,
        "caravan": None,
        "caravan_followers": 0,
        "caravan_followers_level": 0,
        "caravan_upgrade_level": 0,
        "caravan_max_hp": 420,
        "bear": None,
        "conquest_class": 0,
        "bow": False,
        "armor_bonus": 0,
        "shield_bonus": 0,
        "sword_level": 0,
        "sea": {"city":1,"population":120,"troops":20,"ships":0,"cannons":0,"gold":300,"pirates":0},
        "castle": {"troops":0,"catapults":0,"cannons":0},
        "settings": {"sound": True, "volume": 0.65, "control_mode": "buttons"},
        "achievements": {},
        "daily_last": "",
        "total_games": 0
    }

def load_data():
    d = default_data()
    try:
        if os.path.exists(SAVE_FILE):
            with open(SAVE_FILE, "r", encoding="utf-8") as f:
                old = json.load(f)
                d.update(old)
    except:
        pass
    return v55_migrate_save(v54_migrate_save(d))


data = load_data()
if not isinstance(data.get("settings"), dict):
    data["settings"] = {"sound": True, "volume": 0.65, "theme": "dark"}
data["settings"].setdefault("sound", True)
data["settings"].setdefault("volume", 0.65)
data["settings"].pop("brightness", None)
data["settings"].pop("theme", None)
data["settings"]["volume"] = max(0.0, min(1.0, float(data["settings"]["volume"])))
data.setdefault("achievements", {})
data.setdefault("daily_last", "")
data.setdefault("total_games", 0)

# ------------------------------------------------------------
# V52 TAMAMEN YENILENMIS SES MOTORU
# Ton/bip yerine yalnizca yumusak darbe, gurultu ve ortam sesleri.
# Yuksek frekansli "dit" uretilmez.
# ------------------------------------------------------------
SOUND_OK=False
_ui_sounds={}
try:
    if pygame.mixer.get_init() is None:
        pygame.mixer.init(frequency=22050,size=-16,channels=2,buffer=1024)
    _SOUND_RATE=22050

    def _snd(samples):
        buf=bytearray()
        for v in samples:
            buf += struct.pack('<h', max(-32767,min(32767,int(v))))
        return pygame.mixer.Sound(buffer=bytes(buf))

    def _soft_noise(ms=180, vol=.10, smooth=.82, pulse=False):
        frames=max(1,int(_SOUND_RATE*ms/1000)); out=[]; prev=0.0
        for i in range(frames):
            raw=random.uniform(-1,1)
            prev=prev*smooth+raw*(1-smooth)
            env=min(1.0,i/max(1,frames*.10))*max(.0,1-i/frames)**1.35
            if pulse: env*=.72+.28*math.sin(i*.004)
            out.append(32767*vol*env*prev)
        return _snd(out)

    def _impact(ms=95, vol=.17):
        frames=max(1,int(_SOUND_RATE*ms/1000)); out=[]; prev=0.0
        for i in range(frames):
            raw=random.uniform(-1,1)
            prev=prev*.58+raw*.42
            env=max(.0,1-i/frames)**2.6
            out.append(32767*vol*env*prev)
        return _snd(out)

    def _slash_noise():
        frames=int(_SOUND_RATE*.16); out=[]; prev=0.0
        for i in range(frames):
            raw=random.uniform(-1,1)
            prev=prev*.72+raw*.28
            env=max(.0,1-i/frames)**1.7
            # only filtered noise, no oscillator / no beep
            out.append(32767*.13*env*prev)
        return _snd(out)

    _ui_sounds.update({
        'click':_soft_noise(28,.025,.70),
        'hit':_impact(90,.15),
        'coin':_soft_noise(45,.035,.55),
        'win':_soft_noise(320,.07,.92,True),
        'slash':_slash_noise(),
        'thud':_impact(120,.18),
        'arrow':_soft_noise(70,.055,.78),
        'boom':_impact(280,.23),
        'arena':_soft_noise(520,.065,.96,True),
        'sea':_soft_noise(700,.08,.985,True),
        'forest':_soft_noise(520,.04,.94,True),
        'wind':_soft_noise(720,.075,.992,True),
        'lava':_soft_noise(620,.10,.88,True),
        'shore':_soft_noise(650,.075,.98,True),
        'mountain':_soft_noise(420,.045,.96),
        'cave':_soft_noise(360,.055,.93),
        'hill':_soft_noise(420,.045,.94),
        'ice':_soft_noise(700,.075,.993,True),
        'bird':_soft_noise(60,.018,.45),
        'vapor':_soft_noise(620,.06,.98,True)
    })
    SOUND_OK=True
except Exception:
    SOUND_OK=False

# Eski bip tabanli isimler tamamen devre disi.
BEEP_FREE_SFX=set(_ui_sounds.keys())

def play_sfx(name='click'):
    if not SOUND_OK or not data.get('settings',{}).get('sound',True): return
    snd=_ui_sounds.get(name)
    if snd is None: return
    try:
        # Bildirim/efekt sesleri yumusak tutulur; rahatsiz edici ses yok.
        vol=float(data.get('settings',{}).get('volume',0.65))
        snd.set_volume(max(0.0,min(.70,vol*.72)))
        snd.play()
    except Exception: pass

_last_ambient_time=0
_ambient_step=0
def play_map_ambience(mid):
    global _last_ambient_time,_ambient_step
    now=pygame.time.get_ticks()
    if now-_last_ambient_time<3000: return
    _last_ambient_time=now; _ambient_step+=1
    sequences={
        0:['arena'], 1:['wind'], 2:['ice','wind'], 3:['forest','bird'],
        4:['mountain','bird'], 5:['sea','vapor'], 6:['lava'], 7:['sea','wind'], 8:['wind']
    }
    seq=sequences.get(mid,['forest'])
    play_sfx(seq[_ambient_step%len(seq)])

def reset_game_consumables():
    """Yeni oyuna temiz sarf malzemeleriyle basla.
    Ok dusmanlardan gelmez; sadece magazadan satin alinir.
    """
    data["arrows"] = 0
    data["potions"] = 1
    data["full_potions"] = 0

# Her haritanin altini ayri tutulur. Bir haritada kazanilan altin
# diger haritanin magazasina tasinmaz.
if not isinstance(data.get("map_gold"), list):
    data["map_gold"] = [0,0,0,0,0,0,0]
while len(data["map_gold"]) < 7:
    data["map_gold"].append(0)

def current_map_gold():
    if data.get("developer",{}).get("infinite_gold",False):
        return 999999
    return int(data["map_gold"][map_index])

def add_map_gold(amount):
    data["map_gold"][map_index] = max(0, int(data["map_gold"][map_index]) + int(amount))

def spend_map_gold(amount):
    if data.get("developer",{}).get("infinite_gold",False):
        return True
    if current_map_gold() < amount:
        return False
    data["map_gold"][map_index] -= int(amount)
    return True

def reset_current_game_gold():
    """Yeni Classic/Sonsuz/Kervan oyunu baslayinca o oyunun harita altinini sifirlar."""
    data["map_gold"][map_index] = 0

def current_bear_gold():
    return int(data.get("bear_gold", 0))

def add_bear_gold(amount):
    data["bear_gold"] = max(0, current_bear_gold() + int(amount))

def save_data():
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except:
        pass

# ------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------

def text(msg, f, color, x, y, center=True):
    img = f.render(str(msg), True, color)
    rect = img.get_rect(center=(int(x), int(y))) if center else img.get_rect(topleft=(int(x), int(y)))
    screen.blit(img, rect)
    return rect

def panel(rect, color=DARK, border=GOLD, radius=16):
    pygame.draw.rect(screen, color, rect, border_radius=radius)
    pygame.draw.rect(screen, border, rect, 2, border_radius=radius)

def button(rect, label, color=GRAY, small=False):
    pygame.draw.rect(screen, color, rect, border_radius=16)
    pygame.draw.rect(screen, GOLD, rect, 2, border_radius=16)
    text(label, FS if small else FM, WHITE, rect.centerx, rect.centery)

def clamp(v,a,b):
    return max(a,min(b,v))

# ------------------------------------------------------------
# INPUT - TELEFON + MOUSE + KLAVYE
# ------------------------------------------------------------

fingers = {}

def get_input():
    touches=[]
    click=False
    keys=[]

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            save_data()
            pygame.quit()
            sys.exit()

        elif e.type == pygame.KEYDOWN:
            keys.append(e.key)

        elif e.type == pygame.FINGERDOWN:
            fingers[e.finger_id]=(e.x*W,e.y*H)
            click=True

        elif e.type == pygame.FINGERMOTION:
            fingers[e.finger_id]=(e.x*W,e.y*H)

        elif e.type == pygame.FINGERUP:
            fingers.pop(e.finger_id,None)

        elif e.type == pygame.MOUSEBUTTONDOWN:
            click=True

    touches=list(fingers.values())
    if pygame.mouse.get_pressed()[0]:
        touches.append(pygame.mouse.get_pos())

    return touches,click,keys

def touched(touches, rect):
    return any(rect.collidepoint(p) for p in touches)

# ------------------------------------------------------------
# HAREKET TUSLARI
# ------------------------------------------------------------

def control_rects():
    # Android gezinme çubuğundan yukarıda, büyük ve rahat dört yön tuşu.
    s = int(clamp(min(W,H)*.115, 68, 112))
    gap = int(s*.12)
    left = max(24, int(s*.35))
    bottom = H-int(s*2.85)
    return {
        "up":pygame.Rect(left+s+gap,bottom-s-gap,s,s),
        "down":pygame.Rect(left+s+gap,bottom+s+gap,s,s),
        "left":pygame.Rect(left,bottom,s,s),
        "right":pygame.Rect(left+2*s+2*gap,bottom,s,s)
    }

def control_mode():
    return data.setdefault("settings",{}).get("control_mode","buttons")

def analog_geometry():
    r=int(clamp(min(W,H)*.135,78,128))
    cx=int(r*1.35); cy=H-int(r*2.05)
    return cx,cy,r

def draw_controls():
    if control_mode()=="analog":
        cx,cy,r=analog_geometry()
        # gerçek analog yuvası + yön çizgileri
        pygame.draw.circle(screen,(20,28,40),(cx,cy),r+7)
        pygame.draw.circle(screen,(45,56,76),(cx,cy),r)
        pygame.draw.circle(screen,GOLD,(cx,cy),r,4)
        pygame.draw.line(screen,(75,88,112),(cx-r+18,cy),(cx+r-18,cy),2)
        pygame.draw.line(screen,(75,88,112),(cx,cy-r+18),(cx,cy+r-18),2)
        # parmak hangi yöne çekildiyse topuz oraya gider
        knob=getattr(draw_controls,"knob",(cx,cy))
        pygame.draw.circle(screen,(92,110,140),knob,int(r*.40))
        pygame.draw.circle(screen,(205,215,225),knob,int(r*.40),3)
        return
    cs=control_rects(); labels={"up":"▲","down":"▼","left":"◀","right":"▶"}
    for k,rct in cs.items():
        pygame.draw.rect(screen,(42,50,67),rct,border_radius=20)
        pygame.draw.rect(screen,GOLD,rct,3,border_radius=20)
        text(labels[k],FS,WHITE,rct.centerx,rct.centery)

def movement(touches,keys,speed):
    dx=dy=0.0
    if control_mode()=="analog":
        cx,cy,r=analog_geometry(); active=None
        # Analog bölgesindeki en yakın aktif parmak seçilir.
        for p in touches:
            vx=p[0]-cx; vy=p[1]-cy; d=math.hypot(vx,vy)
            if d<=r*1.65:
                active=(vx,vy,d); break
        if active:
            vx,vy,d=active
            if d>6:
                limit=r*.78
                nx=cx+vx/d*min(d,limit); ny=cy+vy/d*min(d,limit)
                draw_controls.knob=(int(nx),int(ny))
                strength=min(1.0,d/r)
                dx=(vx/d)*speed*strength; dy=(vy/d)*speed*strength
            else:
                draw_controls.knob=(cx,cy)
        else:
            draw_controls.knob=(cx,cy)
    else:
        cs=control_rects()
        if touched(touches,cs["up"]): dy-=speed
        if touched(touches,cs["down"]): dy+=speed
        if touched(touches,cs["left"]): dx-=speed
        if touched(touches,cs["right"]): dx+=speed
        if dx and dy: dx*=.707; dy*=.707
    if pygame.K_UP in keys or pygame.K_w in keys: dy=-speed
    if pygame.K_DOWN in keys or pygame.K_s in keys: dy=speed
    if pygame.K_LEFT in keys or pygame.K_a in keys: dx=-speed
    if pygame.K_RIGHT in keys or pygame.K_d in keys: dx=speed
    return dx,dy

# ------------------------------------------------------------
# CHARACTERS
# Cengiz Han: sadece Classic 5 zafer sonrasi acilir.
# ------------------------------------------------------------

CHARACTERS=[
    {"name":"Athena","speed":7,"bonus":1.0,"cape":(195,55,115),"armor":(155,95,55),"hair":(230,190,80),"type":"female","attack":7,"defense":2,"hp_bonus":0},
    # UCRETSIZ GLADYATOR: Sparta tarzi, 1 daha hizli ve 1 daha az hasar bonusu
    {"name":"Gladyator","speed":7,"bonus":1.2,"cape":(145,42,38),"armor":(175,62,48),"hair":(55,35,22),"type":"sparta","attack":3,"defense":5,"hp_bonus":0},
    {"name":"Kral Leonidas","speed":6,"bonus":1.0,"cape":RED,"armor":(175,110,55),"hair":(55,35,22),"type":"male","attack":8,"defense":4,"hp_bonus":6},
    {"name":"Gladyator Maximus","speed":6,"bonus":1.1,"cape":(65,55,48),"armor":(185,145,60),"hair":(60,42,25),"type":"male","attack":9,"defense":3,"hp_bonus":4},
    {"name":"Golge Hercules","speed":6,"bonus":1.2,"cape":PURPLE,"armor":(62,55,70),"hair":(22,20,22),"type":"male","attack":10,"defense":5,"hp_bonus":8},
    {"name":"Imparator Cengiz Han","speed":10,"bonus":2.05,"cape":(35,110,55),"armor":(200,155,50),"hair":(35,25,18),"type":"special","attack":18,"defense":12,"hp_bonus":26},
    {"name":"Herkul","speed":6,"bonus":5.0,"cape":(165,85,35),"armor":(145,95,55),"hair":(70,40,20),"type":"male","attack":12,"defense":7,"hp_bonus":12},
    {"name":"Dev Asker","speed":5,"bonus":9.0,"cape":(75,80,100),"armor":(105,115,135),"hair":(45,45,50),"type":"giant","attack":13,"defense":9,"hp_bonus":20},
    {"name":"Sparta","speed":6,"bonus":1.4,"cape":RED,"armor":(180,55,45),"hair":(55,35,22),"type":"sparta","attack":4,"defense":5,"hp_bonus":0},
    {"name":"Fatih Sultan Mehmet","speed":11,"bonus":2.35,"cape":(35,110,70),"armor":(190,155,70),"hair":(40,30,20),"type":"fatih","attack":20,"defense":16,"hp_bonus":32},
    {"name":"Kutup Muhafizi","speed":8,"bonus":1.35,"cape":(70,145,190),"armor":(145,185,210),"hair":(220,235,245),"type":"male","attack":7,"defense":6,"hp_bonus":14},
    {"name":"Valkyrie","speed":9,"bonus":1.18,"cape":(110,80,180),"armor":(190,190,215),"hair":(235,205,90),"type":"female","attack":10,"defense":7,"hp_bonus":8},
    {"name":"Cöl Avcisi","speed":8,"bonus":1.28,"cape":(185,110,45),"armor":(165,105,55),"hair":(55,32,18),"type":"male","attack":11,"defense":5,"hp_bonus":6},
    {"name":"Ejderha Muhafizi","speed":7,"bonus":1.42,"cape":(145,35,28),"armor":(75,75,85),"hair":(35,25,20),"type":"special","attack":13,"defense":9,"hp_bonus":18},
    {"name":"Ares Muhafizi","speed":8,"bonus":1.50,"cape":(120,20,20),"armor":(125,125,140),"hair":(45,30,20),"type":"male","attack":14,"defense":8,"hp_bonus":16},
    {"name":"Gece Avcisi","speed":10,"bonus":1.32,"cape":(40,35,75),"armor":(85,80,110),"hair":(25,20,30),"type":"male","attack":12,"defense":6,"hp_bonus":8},
    {"name":"Kuzey Kralicesi","speed":9,"bonus":1.55,"cape":(95,160,205),"armor":(190,215,230),"hair":(235,225,170),"type":"female","attack":15,"defense":10,"hp_bonus":20},
    {"name":"Roma Centurionu","speed":7,"bonus":1.60,"cape":(150,35,30),"armor":(175,145,95),"hair":(60,35,20),"type":"male","attack":16,"defense":12,"hp_bonus":24},
    {"name":"Samuray Ustasi","speed":10,"bonus":1.68,"cape":(38,38,42),"armor":(80,55,55),"hair":(25,20,18),"type":"special","attack":18,"defense":9,"hp_bonus":16},
    {"name":"Col Krali","speed":8,"bonus":1.72,"cape":(205,135,55),"armor":(180,120,50),"hair":(45,28,16),"type":"male","attack":19,"defense":11,"hp_bonus":22},
]

char_index = int(clamp(data.get("selected_char",0),0,len(CHARACTERS)-1))

def cengiz_unlocked():
    return data.get("developer",{}).get("unlock_all",False) or data.get("classic_wins",0) >= 5

def fatih_unlocked():
    return data.get("developer",{}).get("unlock_all",False) or data.get("classic_wins",0) >= 7

# ------------------------------------------------------------
# IMPROVED CHARACTER DRAWING
# ------------------------------------------------------------

def _shine_circle(x,y,r,base,highlight):
    pygame.draw.circle(screen,base,(int(x),int(y)),max(1,int(r)))
    pygame.draw.circle(screen,highlight,(int(x-r*.28),int(y-r*.30)),max(1,int(r*.42)))

def draw_detail_armor(x,y,s,armor,enemy=False):
    # layered shoulder plates and metallic highlights
    edge=(95,58,35) if enemy else GOLD
    for dx in (-13,13):
        pygame.draw.circle(screen,armor,(int(x+dx*s),int(y-1*s)),max(3,int(8*s)))
        pygame.draw.circle(screen,edge,(int(x+dx*s),int(y-1*s)),max(3,int(8*s)),max(1,int(2*s)))
    pygame.draw.line(screen,(235,225,190),(int(x-12*s),int(y+4*s)),(int(x+12*s),int(y+4*s)),max(1,int(2*s)))
    pygame.draw.line(screen,(70,45,32),(int(x),int(y+2*s)),(int(x),int(y+28*s)),max(1,int(2*s)))

def draw_warrior(x,y,ch_index,scale=1.0,enemy=False,attacking=False,horse=False):
    c=CHARACTERS[ch_index % len(CHARACTERS)]
    x=int(x); y=int(y)
    s=scale
    skin=(238,190,150) if not enemy else (225,170,135)
    dark=(38,28,23)

    if horse:
        # horse body
        pygame.draw.ellipse(screen,(105,70,42),(x-int(42*s),y+int(12*s),int(84*s),int(38*s)))
        pygame.draw.circle(screen,(115,78,48),(x+int(35*s),y+int(5*s)),int(17*s))
        pygame.draw.line(screen,(55,40,28),(x-int(25*s),y+int(42*s)),(x-int(25*s),y+int(58*s)),max(2,int(4*s)))
        pygame.draw.line(screen,(55,40,28),(x+int(22*s),y+int(42*s)),(x+int(22*s),y+int(58*s)),max(2,int(4*s)))
        y-=18*s

    # cape
    cape=((90+ch_index*17)%190,35+(ch_index*31)%90,35+(ch_index*23)%70) if enemy else c["cape"]
    pygame.draw.polygon(screen,cape,[
        (x-int(17*s),y-int(5*s)),
        (x+int(17*s),y-int(5*s)),
        (x+int(24*s),y+int(34*s)),
        (x-int(24*s),y+int(34*s))
    ])
    # cape fold and shadow details
    pygame.draw.line(screen,tuple(max(0,v-35) for v in cape),(x,y),(x-int(18*s),y+31*int(s)),max(1,int(2*s)))

    # legs and boots
    pygame.draw.rect(screen,(118,76,48),(x-int(11*s),y+int(23*s),int(8*s),int(20*s)),border_radius=3)
    pygame.draw.rect(screen,(118,76,48),(x+int(3*s),y+int(23*s),int(8*s),int(20*s)),border_radius=3)
    pygame.draw.rect(screen,dark,(x-int(13*s),y+int(39*s),int(12*s),int(6*s)),border_radius=3)
    pygame.draw.rect(screen,dark,(x+int(2*s),y+int(39*s),int(12*s),int(6*s)),border_radius=3)

    # armor torso
    armor=((115+ch_index*11)%190,55+(ch_index*19)%90,40+(ch_index*29)%75) if enemy else c["armor"]
    body=pygame.Rect(x-int(18*s),y-int(4*s),int(36*s),int(34*s))
    pygame.draw.rect(screen,armor,body,border_radius=max(4,int(8*s)))
    pygame.draw.rect(screen,GOLD if not enemy else (130,55,35),body,max(1,int(2*s)),border_radius=max(4,int(8*s)))
    draw_detail_armor(x,y,s,armor,enemy)

    # armor strips
    for yy in [6,13,20]:
        pygame.draw.line(screen,(220,180,95), (x-int(14*s),y+int(yy*s)), (x+int(14*s),y+int(yy*s)), max(1,int(2*s)))

    # neck
    pygame.draw.rect(screen,skin,(x-int(6*s),y-int(15*s),int(12*s),int(12*s)),border_radius=3)

    # face
    pygame.draw.circle(screen,skin,(x,y-int(23*s)),int(13*s))

    # ears
    pygame.draw.circle(screen,skin,(x-int(13*s),y-int(23*s)),int(3*s))
    pygame.draw.circle(screen,skin,(x+int(13*s),y-int(23*s)),int(3*s))

    # hair / helmet
    if c["type"]=="female":
        pygame.draw.arc(screen,c["hair"],(x-int(15*s),y-int(37*s),int(30*s),int(25*s)),3.05,6.2,max(3,int(6*s)))
        pygame.draw.rect(screen,c["hair"],(x-int(15*s),y-int(28*s),int(6*s),int(19*s)),border_radius=4)
        pygame.draw.rect(screen,c["hair"],(x+int(9*s),y-int(28*s),int(6*s),int(19*s)),border_radius=4)
    else:
        pygame.draw.arc(screen,c["hair"],(x-int(15*s),y-int(38*s),int(30*s),int(25*s)),3.05,6.25,max(3,int(6*s)))
        if c["type"]=="special":
            pygame.draw.polygon(screen,GOLD,[(x-int(14*s),y-int(29*s)),(x,y-int(44*s)),(x+int(14*s),y-int(29*s))])
        if c["type"]=="giant":
            pygame.draw.rect(screen,(70,75,85),(x-int(16*s),y-int(37*s),int(32*s),int(10*s)),border_radius=5)

    # facial shading and cheek highlights
    pygame.draw.arc(screen,(190,125,95),(x-int(10*s),y-int(30*s),int(20*s),int(18*s)),0.2,2.9,max(1,int(2*s)))
    pygame.draw.circle(screen,(255,215,180),(x-int(5*s),y-int(25*s)),max(1,int(2*s)))
    # eyebrows
    pygame.draw.line(screen,dark,(x-int(8*s),y-int(27*s)),(x-int(2*s),y-int(28*s)),max(1,int(2*s)))
    pygame.draw.line(screen,dark,(x+int(2*s),y-int(28*s)),(x+int(8*s),y-int(27*s)),max(1,int(2*s)))

    # eye whites + eyes
    pygame.draw.circle(screen,(245,245,235),(x-int(5*s),y-int(23*s)),max(1,int(3*s)))
    pygame.draw.circle(screen,(245,245,235),(x+int(5*s),y-int(23*s)),max(1,int(3*s)))
    pygame.draw.circle(screen,BLACK,(x-int(5*s),y-int(23*s)),max(1,int(2*s)))
    pygame.draw.circle(screen,BLACK,(x+int(5*s),y-int(23*s)),max(1,int(2*s)))

    # nose, mouth
    pygame.draw.line(screen,(145,90,70),(x,y-int(22*s)),(x,y-int(17*s)),max(1,int(s)))
    pygame.draw.arc(screen,(115,45,45),(x-int(6*s),y-int(18*s),int(12*s),int(7*s)),0.1,3.0,max(1,int(s)))
    if enemy:
        pygame.draw.line(screen,(90,45,35),(x-int(8*s),y-int(17*s)),(x+int(8*s),y-int(17*s)),max(1,int(3*s)))
        pygame.draw.line(screen,(120,55,45),(x-int(10*s),y-int(24*s)),(x-int(3*s),y-int(14*s)),max(1,int(2*s)))

    # armor emblem
    pygame.draw.circle(screen,(230,210,130),body.center,max(2,int(4*s)))
    pygame.draw.line(screen,(255,240,180),(body.centerx-int(3*s),body.centery),(body.centerx+int(3*s),body.centery),max(1,int(s)))

    # shield
    shield=pygame.Rect(x-int(31*s),y+int(1*s),int(15*s),int(30*s))
    pygame.draw.ellipse(screen,(100,68,43),shield)
    pygame.draw.ellipse(screen,GOLD,shield,max(1,int(2*s)))

    # sword
    sx=x+int(17*s); sy=y+int(13*s)
    ex=x+int((43 if attacking else 32)*s)
    ey=y+int((-17 if attacking else -7)*s)
    pygame.draw.line(screen,(225,230,238),(sx,sy),(ex,ey),max(2,int(4*s)))
    pygame.draw.line(screen,(85,58,38),(sx-int(5*s),sy),(sx+int(8*s),sy+int(5*s)),max(2,int(3*s)))
    # V52: karaktere özel görünür ekipman ve siluet
    draw_character_signature(x,y,ch_index,s,enemy)

def draw_character_signature(x,y,ch_index,s,enemy=False):
    """V52: Her karakterin uzaktan bile ayirt edilmesini saglayan benzersiz siluet."""
    if enemy: return
    idx=ch_index % len(CHARACTERS)
    # Athena: mızrak + baykuş arması
    if idx==0:
        pygame.draw.line(screen,(225,230,235),(x+18*s,y+16*s),(x+34*s,y-34*s),max(2,int(3*s)))
        pygame.draw.polygon(screen,(235,205,80),[(x+28*s,y-28*s),(x+36*s,y-23*s),(x+30*s,y-18*s)])
        pygame.draw.circle(screen,(235,205,80),(int(x),int(y+9*s)),max(2,int(3*s)))
    # Gladyator: miğfer tepesi ve yuvarlak kalkan
    elif idx==1:
        pygame.draw.arc(screen,(210,160,65),(int(x-18*s),int(y-43*s),int(36*s),int(25*s)),3.3,6.0,max(2,int(3*s)))
        pygame.draw.circle(screen,(125,45,35),(int(x-26*s),int(y+12*s)),max(5,int(9*s)))
        pygame.draw.circle(screen,GOLD,(int(x-26*s),int(y+12*s)),max(5,int(9*s)),max(1,int(2*s)))
    # Leonidas / Sparta: belirgin kırmızı tepe + uzun mızrak
    elif idx in (2,8):
        pygame.draw.rect(screen,(150,30,25),(int(x-2*s),int(y-48*s),max(2,int(5*s)),max(8,int(18*s))),border_radius=2)
        pygame.draw.line(screen,(210,215,220),(x+19*s,y+15*s),(x+38*s,y-36*s),max(2,int(3*s)))
        pygame.draw.polygon(screen,(205,205,205),[(x+38*s,y-36*s),(x+32*s,y-29*s),(x+40*s,y-28*s)])
    # Maximus: Roma gladius + omuz pelerini
    elif idx==3:
        pygame.draw.polygon(screen,(55,50,45),[(x-27*s,y-5*s),(x-7*s,y-13*s),(x-4*s,y+27*s),(x-25*s,y+23*s)])
        pygame.draw.line(screen,(235,235,240),(x+17*s,y+14*s),(x+42*s,y-7*s),max(2,int(4*s)))
    # Gölge Hercules: mor enerji ve çift balta
    elif idx==4:
        pygame.draw.circle(screen,(110,55,170),(int(x),int(y+5*s)),max(15,int(24*s)),max(1,int(2*s)))
        for dx in (-1,1):
            pygame.draw.line(screen,(185,190,205),(x+dx*20*s,y+12*s),(x+dx*35*s,y-14*s),max(2,int(3*s)))
    # Cengiz: yay ve atlı hükümdar havası
    elif idx==5:
        pygame.draw.arc(screen,(125,75,35),(int(x+15*s),int(y-18*s),int(30*s),int(42*s)),-1.35,1.35,max(2,int(3*s)))
        pygame.draw.line(screen,(230,220,180),(x+18*s,y+2*s),(x+41*s,y+4*s),max(1,int(2*s)))
    # Herkul: devasa sopa
    elif idx==6:
        pygame.draw.line(screen,(95,58,30),(x+17*s,y+15*s),(x+37*s,y-30*s),max(5,int(8*s)))
        pygame.draw.circle(screen,(115,70,35),(int(x+39*s),int(y-33*s)),max(4,int(7*s)))
    # Dev Asker: ekstra büyük omuzlar
    elif idx==7:
        pygame.draw.circle(screen,(105,115,135),(int(x-20*s),int(y-2*s)),max(6,int(11*s)))
        pygame.draw.circle(screen,(105,115,135),(int(x+20*s),int(y-2*s)),max(6,int(11*s)))
    # Fatih: Osmanlı miğferi + hilalli sancak
    elif idx==9:
        pygame.draw.polygon(screen,(235,215,155),[(x-16*s,y-38*s),(x,y-49*s),(x+16*s,y-38*s)])
        pygame.draw.line(screen,(210,185,100),(x-31*s,y+25*s),(x-31*s,y-40*s),max(2,int(3*s)))
        pygame.draw.arc(screen,WHITE,(int(x-26*s),int(y-39*s),int(12*s),int(12*s)),.5,5.7,max(1,int(2*s)))
    # Kutup Muhafızı: buz kristalleri
    elif idx==10:
        for a in range(0,360,60):
            ang=math.radians(a); ex=x+math.cos(ang)*22*s; ey=y+math.sin(ang)*22*s
            pygame.draw.line(screen,(190,235,255),(x,y),(ex,ey),max(1,int(2*s)))
    # Valkyrie: kanatlar
    elif idx==11:
        pygame.draw.polygon(screen,(215,220,230),[(x-17*s,y-8*s),(x-38*s,y-22*s),(x-27*s,y+10*s)])
        pygame.draw.polygon(screen,(215,220,230),[(x+17*s,y-8*s),(x+38*s,y-22*s),(x+27*s,y+10*s)])
    # Çöl Avcısı: sarık + eğri kılıç
    elif idx==12:
        pygame.draw.arc(screen,(230,190,120),(int(x-17*s),int(y-42*s),int(34*s),int(20*s)),3.1,6.1,max(2,int(4*s)))
        pygame.draw.arc(screen,(230,235,230),(int(x+13*s),int(y-8*s),int(34*s),int(28*s)),-1.7,1.3,max(2,int(3*s)))
    # Ejderha Muhafızı: boynuzlu miğfer + ejder kanadı
    elif idx==13:
        pygame.draw.polygon(screen,(170,45,30),[(x-18*s,y-35*s),(x-29*s,y-48*s),(x-10*s,y-39*s)])
        pygame.draw.polygon(screen,(170,45,30),[(x+18*s,y-35*s),(x+29*s,y-48*s),(x+10*s,y-39*s)])
        pygame.draw.polygon(screen,(110,30,25),[(x-18*s,y+2*s),(x-40*s,y-8*s),(x-31*s,y+22*s)])
    # Ares: savaş baltası
    elif idx==14:
        pygame.draw.line(screen,(95,60,35),(x+16*s,y+18*s),(x+39*s,y-30*s),max(2,int(4*s)))
        pygame.draw.polygon(screen,(170,175,180),[(x+34*s,y-28*s),(x+48*s,y-25*s),(x+39*s,y-12*s)])
    # Gece Avcısı: koyu kapüşon + çift hançer
    elif idx==15:
        pygame.draw.arc(screen,(20,18,32),(int(x-17*s),int(y-40*s),int(34*s),int(28*s)),3.0,6.2,max(3,int(5*s)))
        pygame.draw.line(screen,(180,190,220),(x-18*s,y+13*s),(x-34*s,y-6*s),max(2,int(3*s)))
        pygame.draw.line(screen,(180,190,220),(x+18*s,y+13*s),(x+34*s,y-6*s),max(2,int(3*s)))

def hpbar(x,y,hp,maxhp,w=75):
    pygame.draw.rect(screen,(90,30,30),(int(x-w/2),int(y),w,8),border_radius=3)
    pygame.draw.rect(screen,RED,(int(x-w/2),int(y),w,8),border_radius=3)
    pygame.draw.rect(screen,GREEN,(int(x-w/2),int(y),int(w*max(0,hp)/maxhp),8),border_radius=3)

# ------------------------------------------------------------
# BEAUTIFUL MAPS
# ------------------------------------------------------------

MAPS=[
    "Antik Roma Arenasi",
    "Kadim Col Piramidi",
    "Karli Buz Kalesi",
    "Karanlik Orman",
    "Daglik Warband Vadisi",
    "Sahil Kiyisi",
    "Lav Diyari",
    "Firtinali Liman",
    "Gunes Tapinagi"
]

map_index=0

def draw_map(map_id):
    # V49 yeni haritasi: Gunes Tapinagi
    if map_id==8:
        screen.fill((205,125,55))
        pygame.draw.circle(screen,(255,226,120),(W-105,95),48)
        for i in range(18):
            x=(i*97+31)%W; y=130+(i*53)%int(H-160)
            pygame.draw.circle(screen,(238,174,82),(x,y),2+(i%3))
        pygame.draw.polygon(screen,(148,92,48),[(W*.5,85),(W*.24,H*.72),(W*.76,H*.72)])
        pygame.draw.polygon(screen,(220,165,78),[(W*.5,120),(W*.31,H*.70),(W*.69,H*.70)])
        for x in [W*.18,W*.82]:
            pygame.draw.rect(screen,(115,74,44),(int(x-22),int(H*.28),44,int(H*.46)))
            pygame.draw.circle(screen,(240,190,90),(int(x),int(H*.31)),17)
        pygame.draw.circle(screen,(255,215,70),(W//2,int(H*.46)),58,5)
        return
    if map_id==7:
        screen.fill((35,62,92))
        for y in range(110,H,20):
            pygame.draw.line(screen,(40,78+int((y%60)/3),112),(0,y),(W,y),2)
        # firtinali deniz limani: dalgalar, iskele, fener ve sis
        for i in range(14):
            yy=int(H*.28+i*42); pygame.draw.arc(screen,(130,180,210),(i*120-40,yy,150,34),0,math.pi,2)
        pygame.draw.rect(screen,(93,64,42),(0,int(H*.73),W,int(H*.27)))
        for x in range(0,W,120): pygame.draw.rect(screen,(120,82,50),(x,int(H*.70),28,int(H*.30)))
        pygame.draw.rect(screen,(205,185,135),(int(W*.84),int(H*.27),22,int(H*.43)))
        pygame.draw.polygon(screen,(245,235,185),[(int(W*.80),int(H*.29)),(int(W*.90),int(H*.29)),(int(W*.85),int(H*.16))])
        for i in range(12):
            x=(i*113+37)%W; y=int(H*.18+(i%5)*H*.10); pygame.draw.line(screen,(180,190,205),(x,y),(x+18,y+35),2)
        return
    if map_id==0:
        # V52: detayli Roma Kolezyumu
        screen.fill((126,82,58))
        # uzak gokyuzu ve seyirci katmanlari
        pygame.draw.rect(screen,(71,53,50),(0,0,W,int(H*.22)))
        for row in range(5):
            yy=int(H*.12+row*H*.065)
            pygame.draw.rect(screen,(86+row*7,67+row*6,58+row*4),(0,yy,W,int(H*.07)))
            for i in range(20):
                px=int(i*W/19 + (row%2)*14)
                pygame.draw.circle(screen,((95+row*12)%180,78+row*7,60+row*5),(px,yy+14),3+(i%3))
        # dev tas tribün ve kemerler
        for side in (-20,int(W*.80)):
            pygame.draw.rect(screen,(100,78,65),(side,int(H*.18),int(W*.22),int(H*.58)))
            for r in range(3):
                ay=int(H*.24+r*H*.17)
                for c in range(3):
                    ax=side+18+c*int(W*.065)
                    pygame.draw.rect(screen,(78,62,55),(ax,ay,44,58))
                    pygame.draw.arc(screen,(185,160,128),(ax,ay-22,44,44),math.pi,2*math.pi,5)
                    pygame.draw.arc(screen,(52,43,40),(ax+8,ay-12,28,30),math.pi,2*math.pi,3)
        # arena kumu, gölge ve merkez halkasi
        pygame.draw.ellipse(screen,(193,145,88),(int(W*.16),int(H*.31),int(W*.68),int(H*.58)))
        pygame.draw.ellipse(screen,(226,182,112),(int(W*.21),int(H*.37),int(W*.58),int(H*.46)))
        pygame.draw.ellipse(screen,(154,111,72),(int(W*.31),int(H*.47),int(W*.38),int(H*.25)),5)
        # kum izleri ve taslar
        for i in range(48):
            px=int((i*97+41)%W); py=int(H*.34+(i*53)%max(1,int(H*.53)))
            pygame.draw.ellipse(screen,(180,132,82),(px,py,3+(i%5),2))
        # mesaleler + Roma sancaklari
        for px in (int(W*.11),int(W*.89)):
            pygame.draw.rect(screen,(82,48,30),(px-4,int(H*.23),8,int(H*.38)))
            pygame.draw.polygon(screen,(142,34,32),[(px+4,int(H*.24)),(px+52,int(H*.29)),(px+4,int(H*.35))])
            pygame.draw.circle(screen,(255,185,65),(px,int(H*.20)),12)
            pygame.draw.circle(screen,(255,225,120),(px-3,int(H*.196)),5)
        # merkezde dekoratif Roma amblemi
        cx,cy=W//2,int(H*.58)
        pygame.draw.circle(screen,(236,194,92),(cx,cy),42,4)
        pygame.draw.line(screen,(236,194,92),(cx-28,cy),(cx+28,cy),3)
        pygame.draw.line(screen,(236,194,92),(cx,cy-28),(cx,cy+28),3)

    elif map_id==1:
        screen.fill((225,185,95))
        pygame.draw.polygon(screen,(175,128,55),[(W*.5,80),(W*.23,H*.52),(W*.77,H*.52)])
        pygame.draw.polygon(screen,(205,158,65),[(W*.5,80),(W*.45,H*.52),(W*.55,H*.52)])
        for i in range(12):
            yy=H*.55+i*35
            pygame.draw.line(screen,(238,200,115),(0,yy),(W,yy),2)
        pygame.draw.circle(screen,(255,235,145),(W-100,100),35)

    elif map_id==2:
        screen.fill((165,205,225))
        for x in range(0,W,150):
            pygame.draw.polygon(screen,(235,245,250),[(x,H*.35),(x+70,H*.08),(x+145,H*.35)])
        for i in range(30):
            x=(i*97)%W; y=70+(i*67)%int(H-100)
            pygame.draw.circle(screen,WHITE,(x,y),2)
        pygame.draw.rect(screen,(110,155,185),(0,H-90,W,90))

    elif map_id==3:
        screen.fill((32,73,50))
        for x in range(35,W,115):
            pygame.draw.rect(screen,(70,43,25),(x,95,24,160))
            pygame.draw.circle(screen,(22,90,42),(x+12,80),55)
            pygame.draw.circle(screen,(28,112,52),(x-10,112),38)
        pygame.draw.circle(screen,(245,115,35),(W*.15,H*.82),25)
        pygame.draw.circle(screen,(245,115,35),(W*.85,H*.82),25)

    elif map_id==4:
        screen.fill((93,132,78))
        # distant mountains
        for i in range(10):
            x=i*W/9-W/9
            pygame.draw.polygon(screen,(61,68,72),[(x,H*.35),(x+W/9,H*.07),(x+W*2/9,H*.35)])
            pygame.draw.polygon(screen,(105,108,102),[(x+W/9,H*.07),(x+W*.075,H*.20),(x+W*.15,H*.20)])
        # road and river
        pygame.draw.polygon(screen,(155,120,70),[(W*.42,H),(W*.55,H),(W*.53,0),(W*.48,0)])
        pygame.draw.polygon(screen,(65,130,175),[(0,H*.72),(W*.25,H*.64),(W*.5,H*.70),(W*.8,H*.61),(W,H*.66),(W,H*.76),(W*.75,H*.72),(W*.48,H*.80),(W*.2,H*.73),(0,H*.82)])
        # Warband tarzı kale, kayalar ve sisli tepeler
        pygame.draw.rect(screen,(92,86,78),(int(W*.72),int(H*.18),int(W*.12),int(H*.18)))
        for tx in [W*.72,W*.76,W*.80,W*.84]:
            pygame.draw.rect(screen,(75,72,70),(int(tx),int(H*.14),int(W*.025),int(H*.08)))
        pygame.draw.rect(screen,(65,60,58),(int(W*.755),int(H*.28),int(W*.035),int(H*.08)))
        for i in range(8):
            rx=int((i*137+70)%W); ry=int(H*.42+(i*53)%(H*.4))
            pygame.draw.ellipse(screen,(88,86,76),(rx,ry,38,22))
            pygame.draw.ellipse(screen,(125,120,104),(rx+5,ry-5,25,14))
        # pine trees
        for i in range(24):
            x=(i*83+40)%W; y=int(H*.38+(i*71)%(H*.48))
            pygame.draw.rect(screen,(65,45,30),(x-4,y,8,24))
            pygame.draw.polygon(screen,(24,82,45),[(x,y-35),(x-22,y+8),(x+22,y+8)])
            pygame.draw.polygon(screen,(28,100,52),[(x,y-18),(x-26,y+20),(x+26,y+20)])

    elif map_id==5:
        screen.fill((70,145,190))
        pygame.draw.rect(screen,(225,195,125),(0,int(H*.62),W,int(H*.38)))
        pygame.draw.rect(screen,(35,105,150),(0,int(H*.47),W,int(H*.16)))
        for i in range(8):
            x=i*W//7+30
            pygame.draw.arc(screen,WHITE,(x,int(H*.48),110,42),0.1,2.8,3)
        pygame.draw.circle(screen,(250,210,80),(W-110,90),42)
        for i in range(12):
            x=(i*137)%W; y=int(H*.65)+(i*53)%int(H*.28)
            pygame.draw.circle(screen,(55,125,70),(x,y),10+(i%3)*4)
            pygame.draw.rect(screen,(95,60,32),(x-3,y,6,20))
        # rocks and a coastal watch tower
        pygame.draw.polygon(screen,(90,88,78),[(70,int(H*.6)),(130,int(H*.5)),(185,int(H*.62))])
        pygame.draw.rect(screen,(160,130,95),(W-170,int(H*.42),50,int(H*.22)))
        pygame.draw.polygon(screen,(120,65,45),[(W-185,int(H*.42)),(W-145,int(H*.32)),(W-105,int(H*.42))])

    elif map_id==6:
        screen.fill((38,24,28))
        # glowing lava rivers and volcanoes
        for i in range(6):
            x=i*W/5-W/10
            pygame.draw.polygon(screen,(72,58,58),[(x,H*.42),(x+W*.10,H*.08),(x+W*.22,H*.42)])
            pygame.draw.polygon(screen,(115,45,28),[(x+W*.07,H*.40),(x+W*.10,H*.08),(x+W*.13,H*.40)])
        for y in [H*.62,H*.83]:
            pts=[]
            for x in range(-40,W+80,80): pts.append((x,int(y+math.sin(x*.025+y)*24)))
            pygame.draw.lines(screen,(255,92,25),False,pts,22)
            pygame.draw.lines(screen,(255,185,45),False,pts,6)
        for i in range(20):
            x=(i*97)%W; y=int(H*.45+(i*61)%max(1,H*.45))
            pygame.draw.circle(screen,(105,70,62),(x,y),random.randint(6,15))
        pygame.draw.circle(screen,(255,125,25),(W*.83,H*.16),38)
    draw_map_atmosphere(map_id)
# ------------------------------------------------------------
# V46 SINEMATIK HARITA ATMOSFERI
# Hafif animasyonlar: oyunu kasmadan her haritaya daha canli bir gorunum verir.
def draw_map_atmosphere(map_id):
    t=pygame.time.get_ticks()/1000.0
    if map_id==0: # Roma: mesaleler ve kum parcaciklari
        for i in range(18):
            x=int((i*113+t*22)%W); y=int(H*.22+(i*67)%int(H*.65))
            pygame.draw.circle(screen,(245,215,150),(x,y),1)
    elif map_id==1: # Col: sicak kum
        for i in range(14):
            x=int((i*91+t*18)%W); y=int(H*.35+(i*53)%int(H*.55))
            pygame.draw.line(screen,(255,225,145),(x,y),(x+6,y),1)
    elif map_id==2: # Buz: kar
        for i in range(35):
            x=int((i*71+t*17)%W); y=int((i*41+t*28)%H)
            pygame.draw.circle(screen,WHITE,(x,y),1+(i%3==0))
    elif map_id==3: # Orman: atesbocekleri
        for i in range(18):
            x=int((i*97+math.sin(t+i)*20)%W); y=int(H*.30+(i*71)%int(H*.55))
            pygame.draw.circle(screen,(220,205,70),(x,y),2)
    elif map_id==4: # Dag: ince sis
        surf=pygame.Surface((W,H),pygame.SRCALPHA)
        yy=int(H*.52+math.sin(t*.5)*18)
        pygame.draw.ellipse(surf,(210,225,235,18),(-W//8,yy,W*5//4,90))
        screen.blit(surf,(0,0))
    elif map_id==5: # Sahil: kuslar ve parlayan dalga
        for i in range(5):
            x=int((i*W/5+t*35)%W); y=int(H*.16+(i%2)*38)
            pygame.draw.arc(screen,WHITE,(x,y,24,10),3.3,6.1,1)
    elif map_id==6: # Lav: kor parcaciklari
        for i in range(22):
            x=int((i*79+t*(18+i%4*7))%W); y=int(H*.25+(i*47)%int(H*.65))
            pygame.draw.circle(screen,ORANGE,(x,y),2+(i%2))

# Basarilar ve gunluk odul sistemi
def achievement_list():
    return [
        ("ILK ZAFER", data.get("classic_wins",0)>=1, "Classic modunda 1 kez kazan"),
        ("ARENA USTASI", data.get("classic_wins",0)>=5, "Classic modunu 5 kez tamamla"),
        ("EFSANE FATIH", data.get("classic_wins",0)>=7, "Fatih Sultan Mehmet'i ac"),
        ("DENIZCI", data.get("sea",{}).get("ships",0)>=3, "3 gemiye sahip ol"),
        ("ZENGIN SAVASCI", data.get("gold",0)>=1000, "1000 altina ulas"),
        ("FETIHCI", data.get("conquest") is not None, "Dunya Fethinde yolculuga basla"),
    ]

def achievements_menu(touches,click):
    global state
    draw_menu_background(); text("🏆 BASARILAR",FT,GOLD,W//2,H*.10)
    y=int(H*.19)
    done=0
    for name,ok,desc in achievement_list():
        r=pygame.Rect(W//2-330,y,660,62)
        panel(r,(42,92,56) if ok else (55,55,66),GOLD if ok else GRAY,14)
        text(("✓ " if ok else "🔒 ")+name,FM,GOLD if ok else SILVER,r.x+22,r.y+20,False)
        text(desc,FS,WHITE,r.x+22,r.y+45,False)
        done+=1 if ok else 0; y+=72
    text(f"TAMAMLANAN: {done}/{len(achievement_list())}",FM,GOLD,W//2,int(H*.78))
    back=pygame.Rect(25,20,130,50); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="settings"; play_sfx("click")

def daily_reward():
    import datetime
    today=str(datetime.date.today())
    if data.get("daily_last","")==today: return False,0
    reward=100+min(400,data.get("classic_wins",0)*20)
    data["gold"]+=reward; data["daily_last"]=today; save_data(); return True,reward

state="language"
mode=None
game_difficulty="ORTA"
DIFFICULTY_STATS={"KOLAY":(0.75,0.78,0.88),"ORTA":(1.0,1.0,1.0),"ZOR":(1.45,1.35,1.20)}
message=""
message_timer=0

def set_message(msg,t=0.9):
    global message,message_timer
    message=msg
    # V52: yazilar ekranda uzun kalmaz. Uzun istense bile en fazla 0.85 sn.
    message_timer=max(0.35,min(float(t),0.85))


# ------------------------------------------------------------
# AYARLAR - SES
# ------------------------------------------------------------
def settings_menu(touches,click):
    global state
    draw_menu_background(); text("⚙ AYARLAR",FT,GOLD,W//2,H*.10)
    st=data.setdefault("settings",{"sound":True,"volume":0.65,"control_mode":"buttons"})
    toggle=pygame.Rect(W//2-230,int(H*.19),460,58); button(toggle,"SESI KAPAT" if st.get("sound",True) else "SESI AC",GREEN if st.get("sound",True) else RED)
    text(f"SES SEVIYESI: %{int(st.get('volume',.65)*100)}",FS,WHITE,W//2,H*.30)
    minus=pygame.Rect(W//2-230,int(H*.34),180,55); plus=pygame.Rect(W//2+50,int(H*.34),180,55); button(minus,"- SES",BLUE); button(plus,"+ SES",GREEN)
    text("KONTROL MODU",FS,GOLD,W//2,H*.47)
    analog=pygame.Rect(W//2-230,int(H*.51),220,62)
    buttons=pygame.Rect(W//2+10,int(H*.51),220,62)
    mode=st.get("control_mode","buttons")
    button(analog,"🕹 ANALOG",GREEN if mode=="analog" else GRAY)
    button(buttons,"🔘 DUGMELER",GREEN if mode=="buttons" else GRAY)
    active="ANALOG" if mode=="analog" else "DUGME"
    text("AKTIF: "+active,FS,WHITE,W//2,H*.60)
    ach=pygame.Rect(W//2-230,int(H*.65),460,55); button(ach,"🏆 BASARILAR",GOLD)
    daily=pygame.Rect(W//2-230,int(H*.73),460,55); button(daily,"🎁 GUNLUK ODUL AL",PURPLE)
    info=pygame.Rect(W//2-230,int(H*.81),460,55); button(info,"ℹ YAPAN HAKKINDA",PURPLE)
    devbtn=pygame.Rect(W//2-230,int(H*.88),460,48); button(devbtn,"🛠 GELISTIRICI OZELLIKLERI",RED)
    back=pygame.Rect(25,20,130,50); button(back,"GERI",GRAY,True)
    if click:
        if touched(touches,toggle): st["sound"]=not st.get("sound",True); play_sfx("click"); save_data()
        elif touched(touches,minus): st["volume"]=max(0.0,round(float(st.get("volume",.65))-.1,2)); save_data(); play_sfx("click")
        elif touched(touches,plus): st["volume"]=min(1.0,round(float(st.get("volume",.65))+.1,2)); save_data(); play_sfx("click")
        elif touched(touches,analog): st["control_mode"]="analog"; save_data(); play_sfx("click"); set_message("ANALOG KONTROL AKTIF",2)
        elif touched(touches,buttons): st["control_mode"]="buttons"; save_data(); play_sfx("click"); set_message("DUGME KONTROLU AKTIF",2)
        elif touched(touches,ach): state="achievements"; play_sfx("click")
        elif touched(touches,daily):
            ok,reward=daily_reward()
            set_message((f"GUNLUK ODUL: +{reward} ALTIN" if ok else "BUGUN ODULUNU ZATEN ALDIN!"),2.5)
            play_sfx("coin" if ok else "click")
        elif touched(touches,info): state="about"; play_sfx("click")
        elif touched(touches,devbtn): state="developer_settings"; play_sfx("click")
        elif touched(touches,back): state="menu"; play_sfx("click")

def about_menu(touches,click):
    global state
    draw_menu_background()
    panel(pygame.Rect(W//2-280,int(H*.16),560,int(H*.62)),(24,29,42),GOLD,22)
    text("ℹ YAPAN HAKKINDA",FT,GOLD,W//2,H*.24)
    text("SPARTA ARENA",FM,WHITE,W//2,H*.34)
    text("YAPAN / YONETMEN / TASARIM",FS,GOLD,W//2,H*.44)
    text("Seyit Ali",FM,WHITE,W//2,H*.50)
    text("GELISTIRME DESTEGI / KOD",FS,GOLD,W//2,H*.59)
    text("ChatGPT",FM,WHITE,W//2,H*.65)
    text("FIKIRLER, YONETIM VE OYUN VIZYONU",FS,GOLD,W//2,H*.72)
    text("Seyit Ali",FM,WHITE,W//2,H*.77)
    back=pygame.Rect(25,20,130,50); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): play_sfx("click"); state="settings"

# ------------------------------------------------------------
# MAIN MENU - KARAKTERLER BURADA YOK
# ------------------------------------------------------------

def draw_menu_background():
    # Epic layered illustrated background
    screen.fill((5,9,19))
    for y in range(H):
        t=y/max(1,H-1)
        col=(int(8+18*t),int(15+28*t),int(32+38*t))
        pygame.draw.line(screen,col,(0,y),(W,y))
    # stars and atmospheric mist
    for i in range(48):
        x=(i*137+29)%W; y=(i*71+19)%int(H*.55)
        r=1+(i%3==0)
        pygame.draw.circle(screen,(120,145,185),(x,y),r)
    # moon glow
    mx,my=int(W*.82),int(H*.17)
    for r in range(95,35,-12): pygame.draw.circle(screen,(22+r//8,34+r//7,60+r//5),(mx,my),r,2)
    pygame.draw.circle(screen,(255,218,145),(mx,my),34)
    # mountain layers
    layers=[((15,27,45),.43),((24,43,65),.53),((35,60,78),.66)]
    for li,(col,yy) in enumerate(layers):
        step=max(120,W//6)
        for i,x in enumerate(range(-step,W+step,step)):
            peak=int(H*(yy+((i+li)%3)*.035))
            pygame.draw.polygon(screen,col,[(x,H),(x+step//2,peak),(x+step,H)])
            pygame.draw.line(screen,(70,90,110),(x+step//2,peak),(x+step//2+step//7,peak+H*.12),2)
    # castle silhouette
    cx=int(W*.12); cy=int(H*.48)
    pygame.draw.rect(screen,(20,24,31),(cx-70,cy,140,int(H*.25)))
    for dx in (-55,-15,25,55): pygame.draw.rect(screen,(20,24,31),(cx+dx,cy-35,22,60))
    # foreground trees
    for i in range(14):
        x=i*W/13
        trunk=(int(x),int(H*.72))
        pygame.draw.rect(screen,(37,57,42),(trunk[0]-4,trunk[1],8,int(H*.28)))
        for rr,dy in [(34,-18),(27,-42),(21,-65)]: pygame.draw.circle(screen,(22,68+(i%3)*8,48),(trunk[0],trunk[1]+dy),rr)
    # subtle frame
    pygame.draw.rect(screen,(150,112,50),(10,10,W-20,H-20),3,border_radius=18)
    # V55 premium atmospheric particles
    for i in range(24):
        px=(i*211+43)%W; py=int(H*.18)+(i*97)%max(1,int(H*.55))
        pygame.draw.circle(screen,(185,150,82),(px,py),1+(i%2))


def main_menu(touches,click):
    global state
    draw_menu_background()

    text("⚔ SPARTA ARENA ⚔",FT,(40,25,10),W//2+4,H*.095+5)
    text("⚔ SPARTA ARENA ⚔",FT,GOLD,W//2,H*.095)
    text("ULTIMATE WARFARE • WORLD • SEA • SIEGE • LEGENDS",FS,SILVER,W//2,H*.165)

    buttons=[
        (pygame.Rect(W//2-260,int(H*.27),520,72),"OFFLINE OYNA",BLUE),
        (pygame.Rect(W//2-260,int(H*.39),520,72),"MULTIPLAYER",PURPLE),
        (pygame.Rect(W//2-260,int(H*.51),520,72),"FETIH MODU",BROWN),
        (pygame.Rect(W//2-260,int(H*.63),520,72),"DENIZ SAVASI",(35,120,170)),
        (pygame.Rect(W//2-260,int(H*.75),520,58),"⚙ AYARLAR",GRAY),
    ]
    for r,l,c in buttons:
        button(r,l,c)

    text("SPARTA WORLD • ARENA • WORLD • SEA • SIEGE",FS,SILVER,W//2,H*.84)
    text("Karakterini oyun moduna girdikten sonra secersin.",FS,SILVER,W//2,H*.875)
    text("Cengiz Han: Classic modu 5 kez tamamlayinca acilir.",FS,SILVER,W//2,H*.91)

    if click:
        if touched(touches,buttons[0][0]): state="offline"
        elif touched(touches,buttons[1][0]): state="server_multiplayer"
        elif touched(touches,buttons[2][0]): state="conquest_class"
        elif len(buttons)>3 and touched(touches,buttons[3][0]): play_sfx("click"); state="sea_hub"
        elif len(buttons)>4 and touched(touches,buttons[4][0]): play_sfx("click"); state="settings"

# ------------------------------------------------------------
# OFFLINE
# ------------------------------------------------------------

def offline_menu(touches,click):
    global state,mode
    draw_menu_background()
    text("OFFLINE OYUN MODLARI",FT,GOLD,W//2,60)

    items=[
        ("CLASSIC ARENA",RED),
        ("SONSUZ DUSMAN",PURPLE),
        ("AYIDAN SAKLAN",BROWN),
        ("KERVAN KORUMA",BLUE),
        ("SICAK PATATES",PURPLE),
        ("KALE FETHI",BROWN),
        ("TEPENIN KRALI",GOLD),
        ("FIRTINA DÜELLOSU",(55,105,160)),
        ("EFSANEVI BOSS ARENASİ",(120,45,35)),
        ("SAKLAMBAÇ • ZOMBI AVI",(55,135,85))
    ]
    rects=[]
    for i,(name,col) in enumerate(items):
        r=pygame.Rect(W//2-250,110+i*70,500,58)
        rects.append(r)
        button(r,name,col)

    back=pygame.Rect(25,20,130,50)
    button(back,"GERI",GRAY,True)

    if click and touched(touches,back):
        state="menu"

    if click:
        for i,r in enumerate(rects):
            if touched(touches,r):
                mode=i
                if i==2:
                    state="bear_start"
                elif i==4:
                    setup_hot_potato("offline")
                    state="hot_potato"
                elif i==5:
                    state="castle_difficulty"
                elif i==6:
                    state="hill_char"
                elif i==7:
                    setup_storm_duel(); state="storm_duel"
                elif i==8:
                    setup_boss_arena(); state="boss_arena"
                elif i==9:
                    setup_hide_seek("offline"); state="hide_seek"
                elif i in (0,1):
                    state="difficulty_select"
                else:
                    state="map_select"

# ------------------------------------------------------------
# MAP + CHARACTER SELECT
# ------------------------------------------------------------

def map_select(touches,click):
    global state,map_index
    draw_menu_background()
    text("HARITA SEC",FT,GOLD,W//2,48)

    cols=[(170,120,75),(220,175,75),(150,200,225),(35,85,50),(90,125,75),(70,150,190),(120,45,30),(55,95,135)]
    while len(data.get("map_gold",[])) < len(MAPS): data.setdefault("map_gold",[]).append(0)
    for i,name in enumerate(MAPS):
        r=pygame.Rect(W//2-280,90+i*82,560,64)
        button(r,f"{name}  |  ALTIN: {int(data.get('map_gold',[0]*len(MAPS))[i])}",cols[i%len(cols)])
        if click and touched(touches,r):
            map_index=i
            state="game_char"

    back=pygame.Rect(25,20,130,50)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="offline"

def bear_start_screen(touches,click):
    global state
    draw_menu_background()
    text("AYIDAN SAKLAN",FT,GOLD,W//2,H*.16)
    text("GUNDUZ 30 SANiYE - GECE 5 SANiYE SONRA DEV AYI",FS,SILVER,W//2,H*.25)
    new_btn=pygame.Rect(W//2-250,int(H*.34),500,72)
    cont_btn=pygame.Rect(W//2-250,int(H*.46),500,72)
    back=pygame.Rect(25,20,130,50)
    button(new_btn,"YENI OYUN",GREEN)
    button(cont_btn,"KAYITTAN DEVAM ET",BLUE)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,new_btn):
        # Yeni Ayidan Saklan oyunu: eski oyunun altini ve ilerlemesi tasinmaz.
        data["bear"]=None
        data["bear_gold"]=0
        reset_game_consumables()
        save_data()
        state="bear_char"
    if click and touched(touches,cont_btn):
        if data.get("bear"):
            load_bear_progress()
            state="bear"
        else:
            set_message("KAYITLI AYI MODU YOK!",2)
    if click and touched(touches,back):
        state="offline"

def character_select(touches,click,bear_only=False):
    global state,char_index
    draw_menu_background()
    title="AYIDAN SAKLAN - KARAKTER SEC" if bear_only else "SAVASCI KARAKTERINI SEC"
    text(title,FB,GOLD,W//2,42)

    # Tum karakterler artik ekrana sigmama yuzunden kaybolmuyor: sayfali secim.
    per_page=5
    page=int(data.get("char_page",0))
    max_page=max(0,(len(CHARACTERS)-1)//per_page)
    page=int(clamp(page,0,max_page))
    data["char_page"]=page
    start_i=page*per_page
    shown=CHARACTERS[start_i:start_i+per_page]
    card_h=max(78,min(98,int(H*.115)))
    start=max(78,int(H*.12))

    for local_i,c in enumerate(shown):
        i=start_i+local_i
        y=start+local_i*(card_h+8)
        locked=(("Cengiz Han" in c.get("name", "")) and not cengiz_unlocked()) or (c.get("name")=="Fatih Sultan Mehmet" and not fatih_unlocked())
        r=pygame.Rect(W//2-315,y,630,card_h)
        panel(r,(48,52,63) if not locked else (58,35,35),c["cape"] if not locked else RED,14)
        draw_warrior(r.x+55,r.centery+8,i,1.08,False,False)
        name=("KILITLI - FATIH SULTAN MEHMET" if c.get("name")=="Fatih Sultan Mehmet" and not fatih_unlocked() else ("KILITLI - CENGIZ HAN" if locked else c["name"]))
        text(name,FM,WHITE,r.x+115,r.y+card_h*.30,False)
        if locked:
            info=(f"ACMA SARTI: Classic Zafer {data.get('classic_wins',0)}/7" if c.get("name")=="Fatih Sultan Mehmet" else f"ACMA SARTI: Classic Zafer {data.get('classic_wins',0)}/5")
            lx=r.right-46; ly=r.y+18
            pygame.draw.arc(screen,GOLD,(lx-13,ly-14,26,25),3.15,6.28,4)
            pygame.draw.rect(screen,GOLD,(lx-17,ly,34,28),border_radius=5)
            pygame.draw.circle(screen,(55,42,28),(lx,ly+12),3)
        else:
            info=f"HIZ {c['speed']} | HASAR +{c.get('attack',int(c['bonus']*5))} | SAVUNMA +{c.get('defense',0)} | CAN +{c.get('hp_bonus',0)}"
        text(info,FS,GOLD,r.x+115,r.y+card_h*.70,False)
        if click and touched(touches,r):
            if locked: set_message("Bu karakter henuz kilitli!",2)
            else:
                char_index=i; data["selected_char"]=i; save_data()
                if bear_only: setup_bear(); state="bear"
                else: state="mode_start"

    if max_page>0:
        prev=pygame.Rect(W//2-300,H-70,120,48); nxt=pygame.Rect(W//2+180,H-70,120,48)
        button(prev,"< ONCEKI",BLUE,True); button(nxt,"SONRAKI >",BLUE,True)
        text(f"SAYFA {page+1}/{max_page+1}",FS,GOLD,W//2,H-46)
        if click and touched(touches,prev): data["char_page"]=(page-1)% (max_page+1); save_data()
        if click and touched(touches,nxt): data["char_page"]=(page+1)% (max_page+1); save_data()
    back=pygame.Rect(25,20,130,50); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="offline" if bear_only else "map_select"

def game_char_select(touches,click):
    character_select(touches,click,False)

def bear_char_select(touches,click):
    character_select(touches,click,True)

def draw_resource_hud():
    r=pygame.Rect(W-330,18,310,52)
    panel(r,(25,30,42),GOLD,12)
    text(f"{MAPS[map_index][:9]} ALTIN {current_map_gold()} | OK {data['arrows']} | IKSIR {data['potions']} | TAM {data.get('full_potions',0)}",FS,WHITE,r.centerx,r.centery)

def draw_bear_gold_hud():
    r=pygame.Rect(W-300,18,280,52)
    panel(r,(25,30,42),GOLD,12)
    text(f"ALTIN {current_bear_gold()} | OK {data['arrows']} | IKSIR {data['potions']} | TAM {data.get('full_potions',0)}",FS,WHITE,r.centerx,r.centery)

# ------------------------------------------------------------
# OK / YAY SISTEMI - GERCEK UCAN OK ANIMASYONU
# ------------------------------------------------------------
arrow_projectiles=[]
def fire_arrow(px,py,targets):
    if not data.get("bow") or data.get("arrows",0)<=0 or not targets:
        return False
    target=min(targets,key=lambda e:(e["x"]-px)**2+(e["y"]-py)**2)
    dx=target["x"]-px; dy=target["y"]-py; d=max(1,math.hypot(dx,dy))
    data["arrows"]-=1
    arrow_projectiles.append({"x":px,"y":py,"vx":dx/d*18,"vy":dy/d*18,"life":1.4})
    return True

def update_draw_arrows(targets):
    for a in arrow_projectiles[:]:
        ox,oy=a["x"],a["y"]
        a["x"]+=a["vx"]; a["y"]+=a["vy"]; a["life"]-=1/FPS
        pygame.draw.line(screen,(240,225,170),(ox,oy),(a["x"],a["y"]),3)
        ang=math.atan2(a["vy"],a["vx"]); tip=(a["x"],a["y"])
        pygame.draw.polygon(screen,ICE,[tip,(tip[0]-10*math.cos(ang-.5),tip[1]-10*math.sin(ang-.5)),(tip[0]-10*math.cos(ang+.5),tip[1]-10*math.sin(ang+.5))])
        hit=None
        for e in targets:
            if math.hypot(e["x"]-a["x"],e["y"]-a["y"])<42:
                hit=e; break
        if hit:
            hit["hp"]-=data["damage"]*CHARACTERS[char_index]["bonus"]*.28
            if a in arrow_projectiles: arrow_projectiles.remove(a)
        elif a["life"]<=0 or a["x"]<0 or a["x"]>W or a["y"]<0 or a["y"]>H:
            if a in arrow_projectiles: arrow_projectiles.remove(a)

# ------------------------------------------------------------
# GENERIC OFFLINE GAME (CLASSIC / ENDLESS / CARAVAN)
# ------------------------------------------------------------

player=[W*.28,H*.52]
enemies=[]
round_no=1
attack_flash=0
player_hp=140
caravan_hp=420

def save_mode_progress(explicit=False):
    """Mevcut Classic/Sonsuz/Kervan oyununu kaydeder.
    explicit=True sadece oyuncu oyun icindeki KAYDET ekranindan kaydederse olur.
    """
    data["mode_game"]={
        "mode": int(mode if mode is not None else 0),
        "map_index": int(map_index),
        "char_index": int(char_index),
        "player": [float(player[0]), float(player[1])],
        "player_hp": float(player_hp),
        "round_no": int(round_no),
        "caravan_hp": float(caravan_hp),
        "caravan_followers": int(data.get("caravan_followers",0)),
        "caravan_upgrade_level": int(data.get("caravan_upgrade_level",0)),
        "enemies": [dict(e) for e in enemies],
        "explicit": bool(explicit)
    }

def load_mode_progress():
    global mode,map_index,char_index,player,enemies,round_no,player_hp,caravan_hp,attack_flash,arrow_projectiles
    m=data.get("mode_game") or {}
    if not m or not m.get("explicit", False):
        return False
    mode=int(m.get("mode",0)); map_index=int(clamp(m.get("map_index",0),0,len(MAPS)-1))
    char_index=int(clamp(m.get("char_index",data.get("selected_char",0)),0,len(CHARACTERS)-1))
    player=list(m.get("player",[W*.28,H*.52]))
    player_hp=float(m.get("player_hp",140)); round_no=int(m.get("round_no",1))
    caravan_hp=float(m.get("caravan_hp",data.get("caravan_max_hp",420))); enemies=[dict(e) for e in m.get("enemies",[])]
    attack_flash=0; arrow_projectiles=[]
    return True

def mode_start_screen(touches,click):
    global state
    # Eski surumlerin otomatik/yanlis kayitlari "kayit var" gibi gorunmesin.
    stale=data.get("mode_game")
    if stale and int(stale.get("mode",-1))==int(mode) and not stale.get("explicit",False):
        data["mode_game"]=None
        save_data()
    draw_menu_background()
    names=["CLASSIC ARENA","SONSUZ DUSMAN","AYIDAN SAKLAN","KERVAN KORUMA","SICAK PATATES"]
    text(names[mode] if mode is not None and mode < len(names) else "OYUN",FT,GOLD,W//2,H*.18)
    text("YENI OYUN veya KAYITTAN DEVAM ET sec.",FS,WHITE,W//2,H*.27)
    new_btn=pygame.Rect(W//2-250,int(H*.36),500,72)
    cont_btn=pygame.Rect(W//2-250,int(H*.48),500,72)
    back=pygame.Rect(25,20,130,50)
    button(new_btn,"YENI OYUN",GREEN)
    button(cont_btn,"KAYITTAN DEVAM ET",BLUE)
    button(back,"GERI",GRAY,True)
    has=(data.get("mode_game") and data["mode_game"].get("explicit",False)
         and int(data["mode_game"].get("mode",-1))==int(mode))
    text("Bu mod icin kayit var." if has else "Bu mod icin kayit yok.",FS,GOLD if has else SILVER,W//2,H*.60)
    if click and touched(touches,new_btn):
        # Yeni oyun demek yeni oyun ekonomisi demektir: secili haritanin altini sifirlanir.
        data["mode_game"]=None
        reset_current_game_gold()
        reset_game_consumables()
        save_data()
        setup_mode_game(); state="mode_game"
    elif click and touched(touches,cont_btn):
        if has and load_mode_progress(): state="mode_game"
        else: set_message("BU MOD ICIN KAYIT YOK! YENI OYUN BASLAT.",2)
    elif click and touched(touches,back): state="game_char"

def setup_mode_game():
    global player,enemies,round_no,player_hp,attack_flash,arrow_projectiles,caravan_hp
    # Secilen zorluk dusman dalgalarini gercekten etkiler
    player=[W*.28,H*.52]
    player_hp=140+CHARACTERS[char_index].get("hp_bonus",0)
    caravan_hp=float(data.get("caravan_max_hp",420))
    attack_flash=0
    round_no=1
    enemies=[]
    arrow_projectiles=[]
    count=1 if mode==0 else 7
    if mode==0:
        enemies.append(spawn_classic_round_enemy(round_no))
        return
    if mode==3:
        # Kervan modunda ilk dalga: bazı haydutlar oyuncuya,
        # bazıları doğrudan kervana saldırır.
        count=2
    hp_mul,pow_mul,spd_mul=DIFFICULTY_STATS.get(game_difficulty,(1,1,1))
    for i in range(count):
        e={"x":random.randint(W//2,W-90),"y":random.randint(100,H-180),"hp":70*hp_mul,"max_hp":70*hp_mul,"cd":0,
           "speed":1.45*spd_mul,"power":8*pow_mul,"ch":random.choice([1,2,3,5,6])}
        if mode==3:
            e["target"]="caravan" if i%2==0 else "player"
        enemies.append(e)

def spawn_classic_round_enemy(r):
    """Classic Arena: zorlugu secilen seviyeye gore guclenen dusmanlar; her 10. round BOSS."""
    hp_mul,pow_mul,spd_mul=DIFFICULTY_STATS.get(game_difficulty,(1,1,1))
    is_boss = (r % 10 == 0)
    if is_boss:
        hp = (360 + r * 35)*hp_mul
        return {
            "x": random.randint(W//2, W-100), "y": random.randint(120, H-180),
            "hp": hp, "max_hp": hp, "cd": 0, "ch": random.choice([1,2,3,5,6]),
            "speed": (2.15 + r * 0.025)*spd_mul, "power": (16 + r * 1.2)*pow_mul,
            "boss": True
        }
    hp = (95 + r * 12)*hp_mul
    return {
        "x": random.randint(W//2, W-90), "y": random.randint(110, H-170),
        "hp": hp, "max_hp": hp, "cd": 0, "ch": random.choice([1,2,3,5,6]),
        "speed": (1.75 + r * 0.035)*spd_mul, "power": (9 + r * 0.75)*pow_mul,
        "boss": False
    }

def draw_caravan():
    cx=W*.48; cy=H*.52
    pygame.draw.rect(screen,(100,65,38),(cx-45,cy-24,90,48),border_radius=6)
    pygame.draw.rect(screen,(180,120,55),(cx-34,cy-18,68,35),border_radius=4)
    pygame.draw.circle(screen,(40,35,30),(int(cx-32),int(cy+28)),16)
    pygame.draw.circle(screen,(40,35,30),(int(cx+32),int(cy+28)),16)
    pygame.draw.line(screen,(70,45,28),(cx+45,cy),(cx+95,cy-15),4)
    text("KERVAN",FS,GOLD,cx,cy-55)

def mode_game(touches,click,keys):
    global state,attack_flash,player_hp,round_no,caravan_hp

    bg_index=map_index
    draw_map(bg_index)
    play_map_ambience(bg_index)
    draw_resource_hud()

    speed=CHARACTERS[char_index]["speed"]+data["speed"]
    dx,dy=movement(touches,keys,speed)
    player[0]=clamp(player[0]+dx,30,W-30)
    player[1]=clamp(player[1]+dy,80,H-30)

    caravan_x=W*.48
    caravan_y=H*.52
    if mode==3:
        draw_caravan()
        hpbar(caravan_x,caravan_y-92,caravan_hp,data.get("caravan_max_hp",420),105)

    atk=pygame.Rect(W-155,H-125,125,70)
    full_btn=pygame.Rect(W-315,H-125,145,70)
    potion_btn=pygame.Rect(W-475,H-125,145,70)
    shop_btn=pygame.Rect(W-170,82,150,52)
    save_btn=pygame.Rect(20,82,150,52)
    follower_btn=pygame.Rect(W-345,82,160,52) if mode==3 else None
    upgrade_btn=pygame.Rect(W-520,82,160,52) if mode==3 else None
    button(atk,"VUR",RED,True)
    button(full_btn,f"TAM CAN x{data.get('full_potions',0)}",GREEN,True)
    button(potion_btn,f"IKSIR x{data.get('potions',0)}",BLUE,True)
    if data.get("bow"):
        arrow_btn=pygame.Rect(W-155,H-210,125,62)
        button(arrow_btn,"OKLA VUR",BLUE,True)
    else:
        arrow_btn=None
    button(shop_btn,"MAGAZA",BROWN,True)
    button(save_btn,"KAYDET",GREEN,True)
    if follower_btn: button(follower_btn,"YANDAS AL",PURPLE,True)
    if upgrade_btn: button(upgrade_btn,"KERVANI GELISTIR",ORANGE,True)

    if click and touched(touches,atk):
        attack_flash=.22
        play_sfx("slash")
    if click and touched(touches,full_btn):
        if data.get("full_potions",0)>0:
            data["full_potions"]-=1
            player_hp=140
            save_data()
            set_message("CAN TAMAMEN DOLDU!",1.5)
        else:
            set_message("MAGAZADAN 70 ALTINA TAM CAN IKSIRI AL!",1.5)
    if click and touched(touches,potion_btn):
        if data.get("potions",0)>0:
            data["potions"]-=1
            player_hp=min(140+CHARACTERS[char_index].get("hp_bonus",0),player_hp+55)
            save_data()
            set_message("IKSIR KULLANILDI: +55 CAN",1.5)
        else:
            set_message("IKSIRIN YOK! MAGAZADAN AL.",1.5)
    if arrow_btn and click and touched(touches,arrow_btn):
        fire_arrow(player[0],player[1]-18,enemies)
    if click and touched(touches,shop_btn):
        state="mode_shop"; return
    if follower_btn and click and touched(touches,follower_btn):
        state="caravan_follower_shop"; return
    if upgrade_btn and click and touched(touches,upgrade_btn):
        state="caravan_upgrade_shop"; return
    if click and touched(touches,save_btn):
        open_save_screen("mode_game"); return

    attack_flash=max(0,attack_flash-1/FPS)

    for e in enemies[:]:
        # Kervan modunda haydutların bir kısmı kervanı,
        # diğer kısmı oyuncuyu hedefler.
        if mode==3 and e.get("target")=="caravan":
            tx,ty=caravan_x,caravan_y
        else:
            tx,ty=player[0],player[1]

        vx=tx-e["x"]; vy=ty-e["y"]
        dist=max(1,math.hypot(vx,vy))
        enemy_speed=e.get("speed",1.35)
        e["x"]+=vx/dist*enemy_speed
        e["y"]+=vy/dist*enemy_speed
        e["cd"]-=1/FPS

        # Saldırı hedefe göre uygulanır.
        if dist<58 and e["cd"]<=0:
            base_damage=e.get("power",8)
            damage=max(1,base_damage-data.get("armor_bonus",0)-data.get("shield_bonus",0)-CHARACTERS[char_index].get("defense",0))
            if mode==3 and e.get("target")=="caravan":
                caravan_hp-=damage
            else:
                player_hp-=damage
            e["cd"]=.8
            play_sfx("hit")

        # Oyuncunun yakın dövüşü her hayduta işler.
        p_dist=math.hypot(player[0]-e["x"],player[1]-e["y"])
        if attack_flash>0 and p_dist<88:
            dmg=data["damage"]*CHARACTERS[char_index]["bonus"]*.12
            e["hp"]-=dmg

        if e["hp"]<=0:
            enemies.remove(e)
            add_map_gold(20)
            # Dusman oldurmek OK vermez. Ok sadece magazadan satin alinir.
        else:
            enemy_scale = 1.42 if e.get("boss") else 1.0
            draw_warrior(e["x"],e["y"],e.get("ch",1),enemy_scale,True)
            max_enemy_hp = e.get("max_hp", 70)
            hpbar(e["x"],e["y"]-(72 if e.get("boss") else 55),e["hp"],max_enemy_hp,120 if e.get("boss") else 95)
            if e.get("boss"):
                text("BOSS", FS, RED, e["x"], e["y"]-95)
            if mode==3:
                role="KERVAN" if e.get("target")=="caravan" else "SEN"
                text(role,FS,RED if role=="KERVAN" else WHITE,e["x"],e["y"]-72)

    # Kervan yandaslari oyuncuya yakin durur ve yakindaki haydutlara otomatik saldirir.
    if mode==3 and data.get("caravan_followers",0)>0:
        fcount=int(data.get("caravan_followers",0))
        for i in range(fcount):
            fx=player[0]-55-(i%2)*34; fy=player[1]+(i//2)*48-25
            draw_warrior(fx,fy,random.choice([1,2,3,5,6]),0.82,False)
            for e in enemies:
                if math.hypot(fx-e["x"],fy-e["y"])<95:
                    e["hp"]-=0.18+0.04*data.get("caravan_followers_level",0)
        text(f"YANDAS: {fcount}",FS,GOLD,W//2,H-28)

    update_draw_arrows(enemies)
    draw_warrior(player[0],player[1],char_index,1.25,False,attack_flash>0)
    hpbar(player[0],player[1]-68,player_hp,140,95)
    draw_controls()

    names=["CLASSIC ARENA","SONSUZ DUSMAN","AYIDAN SAKLAN","KERVAN KORUMA"]
    text(f"{names[mode]} • {game_difficulty}",FM,GOLD,W//2,32)

    if mode==0:
        boss_note = " | BOSS!" if round_no % 10 == 0 else ""
        text(f"ROUND {round_no}/{data.get('classic_max_round',30)}{boss_note}",FS,RED if round_no % 10 == 0 else WHITE,W//2,66)
    elif mode==1:
        text(f"KALAN DUSMAN {len(enemies)}",FS,WHITE,W//2,66)
    elif mode==3:
        text(f"ROUND {round_no}/20  |  HAYDUTLAR: {len(enemies)}",FS,WHITE,W//2,66)

    if not enemies:
        if mode==0:
            round_no+=1
            if round_no>data.get("classic_max_round",30):
                current_cap=data.get("classic_max_round",30)
                if current_cap < 120:
                    data["classic_stage"]=data.get("classic_stage",1)+1
                    data["classic_max_round"]=min(120,current_cap+30)
                    data["classic_continue_ready"]=True
                    save_data()
                    set_message(f"{current_cap} TUR TAMAMLANDI! MENUDE DEVAM ET: {data['classic_max_round']} TURA KADAR!",3)
                    state="offline"
                else:
                    data["classic_wins"]+=1
                    data["classic_finished_120"]=True
                    data["classic_legend_achievement"]=True
                    data["classic_continue_ready"]=False
                    save_data()
                    set_message("120 TUR TAMAMLANDI! CLASSIC EFSANESI BASARISI ACILDI!",4)
                    state="offline"
            else:
                enemies.append(spawn_classic_round_enemy(round_no))
                if round_no % 10 == 0:
                    set_message(f"BOSS ROUND {round_no}! DIKKAT!", 2.5)
                else:
                    set_message(f"ROUND {round_no}: DUSMAN DAHA HIZLI VE GUCLU!", 1.5)
        elif mode==1:
            hp_mul,pow_mul,spd_mul=DIFFICULTY_STATS.get(game_difficulty,(1,1,1))
            for _ in range(8):
                hp=(120+round_no*8)*hp_mul
                enemies.append({"x":random.randint(W//2,W-80),"y":random.randint(100,H-150),"hp":hp,"max_hp":hp,"cd":0,"speed":2.0*spd_mul,"power":11*pow_mul,"ch":random.choice([1,2,3,5,6])})
        elif mode==3:
            # Kervan: toplam 20 round. Her roundda hedefler karışık gelir.
            round_no+=1
            if round_no>20:
                add_map_gold(500)
                save_data()
                set_message("20 ROUND KERVAN KORUNDU! +500 HARITA ALTINI",4)
                state="offline"
            else:
                # Klasik gibi her round guclenir; her 5 roundda dusman sayisi artar.
                count=2 + ((round_no-1)//5)
                hp=70 + round_no*10
                power=7 + round_no*1.4
                enemy_speed=1.25 + round_no*0.035
                for i in range(count):
                    enemies.append({
                        "x":random.randint(W//2,W-70),
                        "y":random.randint(100,H-150),
                        "hp":hp,
                        "cd":0,
                        "ch":random.choice([1,2,3,5,6]),
                        "speed":enemy_speed,
                        "power":power,
                        # Bazilari kervana, bazilari oyuncuya saldirir.
                        "target":"caravan" if i%2==0 else "player"
                    })
                set_message(f"ROUND {round_no}/20: {count} HAYDUT - DAHA GUCLU!",2)

    if mode==3 and caravan_hp<=0:
        caravan_hp=0
        save_data()
        set_message("KERVAN YOK EDILDI!",3)
        state="offline"
        return

    if player_hp<=0:
        # Olunce Classic/Sonsuz/Kervan kaydi silinir; kayittan devam edilemez.
        data["mode_game"]=None
        save_data()
        set_message("SAVASI KAYBETTIN! KAYIT SILINDI.",2)
        state="offline"

    back=pygame.Rect(20,20,125,48)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,back):
        # GERI otomatik kayit yapmaz. Kayit sadece oyun icindeki KAYDET ile olur.
        state="offline"

# ------------------------------------------------------------
# BEAR MODE - PROPER DAY/NIGHT + CAVES
# ------------------------------------------------------------

bear_player=[W*.25,H*.55]
bear=[W*.82,H*.48]
bear_hp=800
bear_clock=0
bear_day=True
bear_spawned=False
bear_enemies=[]
bear_attack=0
bear_player_hp=160
bear_day_level=1
caves=[]

def setup_bear():
    global bear_player,bear,bear_hp,bear_clock,bear_day,bear_spawned,bear_enemies,bear_attack,bear_player_hp,bear_day_level,caves,arrow_projectiles
    bear_player=[W*.25,H*.55]
    bear=[W*.82,H*.48]
    bear_hp=800
    bear_clock=0
    bear_day=True
    bear_spawned=False
    bear_attack=0
    bear_player_hp=160
    bear_day_level=1
    arrow_projectiles=[]
    caves=[
        pygame.Rect(55,130,120,90),
        pygame.Rect(W-185,H-250,125,95),
        pygame.Rect(W//2-60,110,120,88)
    ]
    bear_enemies=[]
    for _ in range(8):
        bear_enemies.append({"x":random.randint(150,W-150),"y":random.randint(180,H-180),"hp":75,"max_hp":75,"speed":1.75,"power":10,"cd":0})

def save_bear_progress():
    data["bear"]={
        "player":[float(bear_player[0]),float(bear_player[1])],
        "bear":[float(bear[0]),float(bear[1])],
        "bear_hp":float(bear_hp),
        "clock":float(bear_clock),
        "day":bool(bear_day),
        "spawned":bool(bear_spawned),
        "player_hp":float(bear_player_hp),
        "day_level":int(bear_day_level),
        "enemies":[dict(e) for e in bear_enemies],
        "char":int(char_index),
        "map":int(map_index)
    }
    save_data()

def load_bear_progress():
    global bear_player,bear,bear_hp,bear_clock,bear_day,bear_spawned,bear_enemies,char_index,map_index,bear_attack,bear_player_hp,bear_day_level,caves,arrow_projectiles
    b=data.get("bear") or {}
    if not b:
        setup_bear(); return
    bear_player=list(b.get("player",[W*.25,H*.55]))
    bear=list(b.get("bear",[W*.82,H*.48]))
    bear_hp=float(b.get("bear_hp",800))
    bear_clock=float(b.get("clock",0))
    bear_day=bool(b.get("day",bear_clock<30))
    bear_spawned=bool(b.get("spawned",bear_clock>=35))
    bear_enemies=[dict(e) for e in b.get("enemies",[])]
    char_index=int(b.get("char",data.get("selected_char",0)))
    map_index=int(b.get("map",0))
    bear_attack=0
    bear_player_hp=float(b.get("player_hp",160))
    bear_day_level=int(b.get("day_level",1))
    arrow_projectiles=[]
    caves=[pygame.Rect(55,130,120,90),pygame.Rect(W-185,H-250,125,95),pygame.Rect(W//2-60,110,120,88)]

def draw_bear_map():
    # fixed beautiful mountain landscape
    screen.fill((101,150,88) if bear_day else (20,31,52))
    skycol=(120,178,215) if bear_day else (22,35,65)
    pygame.draw.rect(screen,skycol,(0,0,W,int(H*.38)))

    for i in range(9):
        x=i*W//8-W//8
        pygame.draw.polygon(screen,(65,72,78),[(x,H*.38),(x+W//8,H*.08),(x+W//4,H*.38)])
        pygame.draw.polygon(screen,(105,108,105),[(x+W//8,H*.08),(x+W*.095,H*.17),(x+W*.13,H*.17)])

    if bear_day:
        pygame.draw.circle(screen,(255,225,115),(W-90,80),34)
    else:
        pygame.draw.circle(screen,(225,235,245),(W-90,80),28)
        for i in range(35):
            x=(i*73)%W; y=30+(i*41)%int(H*.34)
            pygame.draw.circle(screen,WHITE,(x,y),1)

    for i in range(18):
        x=(i*89+20)%W; y=int(H*.40+(i*59)%(H*.45))
        pygame.draw.rect(screen,(70,45,27),(x-4,y,8,25))
        pygame.draw.polygon(screen,(22,85,43),[(x,y-38),(x-25,y+10),(x+25,y+10)])

    for c in caves:
        pygame.draw.ellipse(screen,(85,70,55),c)
        inner=c.inflate(-20,-15)
        pygame.draw.ellipse(screen,(22,20,23),inner)
        text("MAGARA",FS,GOLD,c.centerx,c.bottom+16)

def bear_mode(touches,click,keys):
    global bear_clock,bear_day,bear_hp,bear_attack,state,bear_spawned,bear_player_hp,bear_day_level

    bear_clock+=1/FPS
    # Her dongu: 30 sn gunduz -> 5 sn ayidan once gece -> 20 sn ayi gecesi.
    # Gece biterse yeni sabah baslar ve botlar bir seviye daha guclenir.
    if bear_clock>=55.0:
        bear_clock=0.0
        bear_day_level+=1
        bear_day=True
        bear_spawned=False
        bear_hp=800 + (bear_day_level-1)*220
        bear_enemies.clear()
        for _ in range(8):
            mhp=75+bear_day_level*22
            bear_enemies.append({"x":random.randint(150,W-150),"y":random.randint(180,H-180),"hp":mhp,"max_hp":mhp,"speed":1.75+bear_day_level*0.18,"power":10+bear_day_level*3,"cd":0})
        set_message(f"SABAH OLDU! BOTLAR SEVIYE {bear_day_level} - DAHA GUCLU VE HIZLI!",2.5)
    bear_day=bear_clock<30.0
    if bear_clock>=35.0:
        bear_spawned=True

    draw_bear_map()
    # Ayidan Saklan modunda kazanilan altinlar global olarak gorunur ve magarada harcanir.
    draw_bear_gold_hud()
    hpbar(W//2,H-42,bear_player_hp,160,170)
    text(f"CAN {int(max(0,bear_player_hp))}/160 | GUN {bear_day_level}",FS,WHITE,W//2,H-67)

    speed=CHARACTERS[char_index]["speed"]+data["speed"]
    dx,dy=movement(touches,keys,speed)
    bear_player[0]=clamp(bear_player[0]+dx,28,W-28)
    bear_player[1]=clamp(bear_player[1]+dy,90,H-28)

    atk=pygame.Rect(W-155,H-125,125,70)
    full_btn=pygame.Rect(W-315,H-125,145,70)
    potion_btn=pygame.Rect(W-475,H-125,145,70)
    button(atk,"VUR",RED,True)
    button(full_btn,f"TAM CAN x{data.get('full_potions',0)}",GREEN,True)
    button(potion_btn,f"IKSIR x{data.get('potions',0)}",BLUE,True)
    if click and touched(touches,atk):
        bear_attack=.25
    if click and touched(touches,full_btn):
        if data.get("full_potions",0)>0:
            data["full_potions"]-=1
            bear_player_hp=160
            save_data()
            set_message("TAM CAN IKSIRI KULLANILDI!",1.5)
        else:
            set_message("MAGARADAN 70 ALTINA TAM CAN IKSIRI AL!",1.5)
    if click and touched(touches,potion_btn):
        if data.get("potions",0)>0:
            data["potions"]-=1
            bear_player_hp=min(160,bear_player_hp+55)
            save_data()
            set_message("IKSIR KULLANILDI!",1.5)
        else:
            set_message("IKSIRIN YOK! MAGARADAN AL.",1.5)
    bear_attack=max(0,bear_attack-1/FPS)

    targets = bear_enemies if bear_day else ([{"x":bear[0],"y":bear[1],"hp":bear_hp}] if bear_spawned else [])
    arrow_btn=None
    if data.get("bow"):
        arrow_btn=pygame.Rect(W-300,H-210,145,62)
        button(arrow_btn,"OKLA VUR",BLUE,True)
        if click and touched(touches,arrow_btn):
            fire_arrow(bear_player[0],bear_player[1]-18,targets)

    in_any_cave=any(c.inflate(25,25).collidepoint(bear_player) for c in caves)
    if in_any_cave:
        cave_shop=pygame.Rect(W//2-145,H-112,290,58)
        button(cave_shop,"MAGARA MAGAZASI",BROWN,True)
        if click and touched(touches,cave_shop):
            state="bear_shop"
            return

    if bear_day:
        for e in bear_enemies[:]:
            vx=bear_player[0]-e["x"]; vy=bear_player[1]-e["y"]
            dist=max(1,math.hypot(vx,vy))
            enemy_speed=e.get("speed",1.75 + bear_day_level*0.18)
            e["x"]+=vx/dist*enemy_speed; e["y"]+=vy/dist*enemy_speed
            e["cd"]=max(0,e.get("cd",0)-1/FPS)
            if bear_attack>0 and dist<90:
                e["hp"]-=data["damage"]*CHARACTERS[char_index]["bonus"]*.15
            # Botlar artik oyuncuya vurur. Magarada oldukca guvendesin.
            if dist<68 and e["cd"]<=0 and not in_any_cave:
                damage=max(2,e.get("power",10+bear_day_level*2)-data.get("armor_bonus",0)-data.get("shield_bonus",0))
                bear_player_hp-=damage
                e["cd"]=0.72
                set_message(f"DUSMAN VURDU! -{int(damage)} CAN",0.5)
            if e["hp"]<=0:
                bear_enemies.remove(e)
                add_bear_gold(5)
                save_data()
                set_message("+5 ALTIN",0.8)
            else:
                draw_warrior(e["x"],e["y"],1,1,True)
                hpbar(e["x"],e["y"]-55,e["hp"],e.get("max_hp",75))
        if len(bear_enemies)<4:
            for _ in range(8-len(bear_enemies)):
                mhp=75+bear_day_level*22
                bear_enemies.append({"x":random.randint(W//2,W-80),"y":random.randint(150,H-160),"hp":mhp,"max_hp":mhp,"speed":1.75+bear_day_level*0.18,"power":10+bear_day_level*3,"cd":0})
        if bear_player_hp<=0:
            set_message("YENILDIN! AYI MODU KAYDI BITTI.",3)
            state="bear_start"
            return
        update_draw_arrows(bear_enemies)
        remaining=max(0,math.ceil(30-bear_clock))
        text(f"GUNDUZ - GECEYE: {remaining} SANiYE",FM,GOLD,W//2,30)

    else:
        if not bear_spawned:
            remaining=max(0,math.ceil(35-bear_clock))
            text(f"GECE OLDU! DEV AYI {remaining} SANiYE SONRA GELiYOR",FM,GOLD,W//2,30)
        else:
            vx=bear_player[0]-bear[0]; vy=bear_player[1]-bear[1]
            dist=max(1,math.hypot(vx,vy))
            bear[0]+=vx/dist*1.85; bear[1]+=vy/dist*1.85
            bx=int(bear[0]); by=int(bear[1])
            # Gelistirilmis Dev Ayi: golge, katmanli tuy, kulak, goz ve burun detaylari
            pygame.draw.ellipse(screen,(35,25,22),(bx-55,by+25,108,22))
            pygame.draw.ellipse(screen,(105,55,30),(bx-50,by-34,102,76))
            pygame.draw.ellipse(screen,(145,82,43),(bx-42,by-29,80,56))
            pygame.draw.circle(screen,(135,72,38),(bx+38,by-25),34)
            pygame.draw.circle(screen,(85,48,30),(bx+20,by-52),12)
            pygame.draw.circle(screen,(85,48,30),(bx+55,by-52),12)
            pygame.draw.circle(screen,(180,105,58),(bx+39,by-29),27)
            pygame.draw.circle(screen,(245,235,190),(bx+31,by-31),6)
            pygame.draw.circle(screen,(245,235,190),(bx+51,by-31),6)
            pygame.draw.circle(screen,BLACK,(bx+32,by-31),3)
            pygame.draw.circle(screen,BLACK,(bx+52,by-31),3)
            pygame.draw.ellipse(screen,(48,30,25),(bx+35,by-13,23,15))
            pygame.draw.arc(screen,(55,28,24),(bx+25,by-9,40,25),0.15,2.95,3)
            for tx,ty in [(bx-25,by-5),(bx-10,by+12),(bx+5,by-3)]:
                pygame.draw.line(screen,(185,105,58),(tx,ty),(tx+9,ty+5),2)
            if dist<105 and not in_any_cave:
                bear_player_hp-=0.65
            if bear_attack>0 and dist<115:
                bear_hp-=data["damage"]*CHARACTERS[char_index]["bonus"]*.10
            # Ucan ok animasyonu ayiya da hasar verir.
            bear_target=[{"x":bear[0],"y":bear[1],"hp":bear_hp}]
            before_hp=bear_target[0]["hp"]
            update_draw_arrows(bear_target)
            bear_hp=bear_target[0]["hp"]
            hpbar(bear[0],bear[1]-72,bear_hp,800,120)
            text("DEV AYI",FS,RED,bear[0],bear[1]-95)
            if in_any_cave:
                text("GUVENTEDESIN - MAGARADA AYI SANA ZARAR VEREMZ",FS,GREEN,W//2,H-155)
            if bear_player_hp<=0:
                set_message("DEV AYI SENI YENDI!",3)
                state="bear_start"
                return
            if bear_hp<=0:
                add_bear_gold(1500)
                data["bear"]=None
                save_data()
                set_message("DEV AYIYI YENDIN! MODU KAZANDIN!",5)
                state="offline"
                return
            text("GECE: AYIDAN MAGARAYA KAC VEYA AYIYI YEN!",FM,GOLD,W//2,30)

    draw_warrior(bear_player[0],bear_player[1],char_index,1.3,False,bear_attack>0)
    draw_controls()

    back=pygame.Rect(20,20,125,48)
    save_btn=pygame.Rect(W-170,82,150,52)
    button(back,"GERI",GRAY,True)
    button(save_btn,"KAYDET",GREEN,True)
    if click and touched(touches,save_btn):
        save_bear_progress()
        open_save_screen("bear"); return
    if click and touched(touches,back):
        save_bear_progress()
        state="offline"

# ------------------------------------------------------------
# OYUN ICI KAYDETME EKRANI
# ------------------------------------------------------------

def save_game_screen(touches,click):
    global state, save_return_state
    screen.fill((20,25,35))
    panel(pygame.Rect(W//2-310,H//2-170,620,340),(37,45,60),GOLD,24)
    text("OYUNU KAYDET",FT,GOLD,W//2,H//2-110)
    text("KAYDET tusuna basinca mevcut esyalar ve harita altinlari saklanir.",FS,WHITE,W//2,H//2-55)
    wallet = current_bear_gold() if save_return_state=="bear" else current_map_gold()
    wallet_name = "AYI MODU ALTINI" if save_return_state=="bear" else "HARITA ALTINI"
    text(f"{wallet_name}: {wallet}   OK: {data['arrows']}   IKSIR: {data['potions']}",FS,SILVER,W//2,H//2-15)
    save_btn=pygame.Rect(W//2-230,H//2+35,460,68)
    back=pygame.Rect(W//2-230,H//2+120,460,55)
    button(save_btn,"SIMDI KAYDET",GREEN)
    button(back,"OYUNA DON",GRAY,True)
    if click and touched(touches,save_btn):
        if save_return_state=="mode_game":
            save_mode_progress(explicit=True)
        elif save_return_state in ("conquest","city"):
            save_conquest()
        elif save_return_state=="bear":
            save_bear_progress()
        save_data()
        set_message("OYUN BASARIYLA KAYDEDILDI!",2)
    if click and touched(touches,back):
        state=save_return_state

def open_save_screen(return_state):
    global state,save_return_state
    save_return_state=return_state
    state="save_game"

save_return_state="menu"

# ------------------------------------------------------------
# KERVAN YANDAS VE GELISTIRME MAGAZALARI
# ------------------------------------------------------------
def caravan_follower_shop(touches,click):
    global state
    screen.fill((26,30,38))
    text("KERVAN YANDASLARI",FT,GOLD,W//2,48)
    text(f"HARITA ALTINI: {current_map_gold()} | YANDAS: {data.get('caravan_followers',0)}/6",FS,WHITE,W//2,100)
    # Her yeni yandas alindiginda diger yandaslar daha pahali olur.
    # Egitim fiyati sabit kalir; sadece yandas satin alma fiyatlari artar.
    follower_count=data.get("caravan_followers",0)
    options=[("Kilicli Yandas",120,1,"Yakinda haydutlara saldirir"),("2 Yandas Paketi",210,2,"Kervani daha iyi korur"),("Yandas Egitimi",180,0,"Yandas saldiri gucunu arttirir")]
    for i,(name,base_cost,amount,desc) in enumerate(options):
        # Mevcut her yandas, yeni yandas fiyatini %15 arttirir.
        # Paket de mevcut yandas sayisina gore pahalanir.
        cost=base_cost if amount==0 else int(base_cost*(1+0.15*follower_count))
        r=pygame.Rect(W//2-270,145+i*105,540,82)
        button(r,f"{name} - {cost} ALTIN",PURPLE)
        text(desc,FS,SILVER,W//2,r.bottom+16)
        if amount:
            text(f"Mevcut yandas: {follower_count} | Sonraki alim daha pahali",FS,GOLD,W//2,r.bottom+36)
        if click and touched(touches,r):
            if current_map_gold()<cost: set_message("Yeterli harita altini yok!",1.5)
            elif amount and data.get("caravan_followers",0)+amount>6: set_message("En fazla 6 yandas alabilirsin!",1.5)
            else:
                spend_map_gold(cost)
                if amount: data["caravan_followers"]=data.get("caravan_followers",0)+amount
                else: data["caravan_followers_level"]=data.get("caravan_followers_level",0)+1
                save_data(); set_message("KERVAN YANDASI GELISTIRILDI!",1.5)
    back=pygame.Rect(20,20,125,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="mode_game"

def caravan_upgrade_shop(touches,click):
    global state,caravan_hp
    screen.fill((35,25,22))
    text("KERVAN GELISTIRME",FT,GOLD,W//2,48)
    text(f"HARITA ALTINI: {current_map_gold()} | KERVAN CANI: {data.get('caravan_max_hp',420)}",FS,WHITE,W//2,100)
    level=int(data.get("caravan_upgrade_level",0))
    options=[("ZIRHLI KERVAN",140,"+100 Kervan Can"),("GUCLU TEKERLER",160,"Haydutlar kervana daha gec ulasir"),("MUHAFIZ KULUBESI",240,"+2 ek yandas kapasitesi") ]
    for i,(name,cost,desc) in enumerate(options):
        r=pygame.Rect(W//2-270,150+i*110,540,82)
        button(r,f"{name} - {cost} ALTIN",ORANGE)
        text(desc,FS,SILVER,W//2,r.bottom+16)
        if click and touched(touches,r):
            if current_map_gold()<cost: set_message("Yeterli harita altini yok!",1.5)
            elif i==0:
                spend_map_gold(cost); data["caravan_max_hp"]=data.get("caravan_max_hp",420)+100; caravan_hp=min(data["caravan_max_hp"],caravan_hp+100)
                data["caravan_upgrade_level"]=level+1; save_data(); set_message("KERVAN ZIRHI GELISTIRILDI!",1.5)
            elif i==1:
                spend_map_gold(cost); data["caravan_upgrade_level"]=level+1; save_data(); set_message("KERVAN GELISTIRILDI!",1.5)
            else:
                spend_map_gold(cost); data["caravan_followers"]=min(8,data.get("caravan_followers",0)+1); save_data(); set_message("EK MUHAFIZ KATILDI!",1.5)
    back=pygame.Rect(20,20,125,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="mode_game"

# ------------------------------------------------------------
# SHOP
# ------------------------------------------------------------

SHOP_ITEMS=[
    ("Bronz Kilic +8",100,"damage",8),
    ("Sparta Kilici +18",240,"damage",18),
    ("Imparator Kilici +30",450,"damage",30),
    ("Efsane Kilic +45",700,"damage",45),
    ("Yay - OKLA VUR ACILIR",220,"bow",True),
    ("OK TORBASI +10 OK",80,"arrows",10),
    ("Hizli Ok Torbasi +25 Ok",180,"arrows",25),
    ("Avci Oklari +50 Ok",300,"arrows",50),
    ("Deri Zirh - Hasar -2",160,"armor_bonus",2),
    ("Demir Zirh - Hasar -4",320,"armor_bonus",4),
    ("Sparta Zirhi - Hasar -6",520,"armor_bonus",6),
    ("Yuvarlak Kalkan - Hasar -2",180,"shield_bonus",2),
    ("Kule Kalkani - Hasar -4",360,"shield_bonus",4),
    ("Kral Kalkani - Hasar -6",600,"shield_bonus",6),
    ("Can Iksiri +1",80,"potions",1),
    ("3 Can Iksiri",210,"potions",3),
    ("TAM CAN IKSIRI - CANI FULLE",70,"full_potions",1),
]

def shop_screen(touches,click,back_state):
    global state
    screen.fill((24,22,30))
    titles={"bear":"MAGARA MAGAZASI","bear_shop":"MAGARA MAGAZASI","city":"SEHIR MAGAZASI","mode_game":"SAHA MAGAZASI","growth":"GELISIM MAGAZASI","arena":"ARENA MAGAZASI","race_hub":"YARIS MAGAZASI"}
    text(titles.get(back_state,"OYUN MAGAZASI"),FT,GOLD,W//2,42)
    wallet = current_map_gold() if back_state=="mode_game" else (current_bear_gold() if back_state=="bear_shop" else data["gold"])
    wallet_name = "HARITA ALTINI" if back_state=="mode_game" else ("AYI MODU ALTINI" if back_state=="bear_shop" else "ALTIN")
    text(f"{wallet_name} {wallet} | OK {data['arrows']} | YAY {'VAR' if data.get('bow') else 'YOK'}",FS,WHITE,W//2,92)
    cols=2; bw=min(470,int(W*.43)); rows=(len(SHOP_ITEMS)+1)//2; bh=max(42,min(58,int((H-155-(rows-1)*8)/max(1,rows)))); gap=8
    for i,(name,price,key,amount) in enumerate(SHOP_ITEMS):
        col=i%cols; row=i//cols
        x=W//2-bw-8 if col==0 else W//2+8
        y=125+row*(bh+gap)
        r=pygame.Rect(x,y,bw,bh)
        button(r,f"{name} - {price} ALTIN",PURPLE,True)
        if click and touched(touches,r):
            already=(key=="bow" and data.get("bow"))
            if already:
                set_message("Bu esya zaten sende!",1.5)
            elif wallet>=price:
                if back_state=="mode_game":
                    spend_map_gold(price)
                elif back_state=="bear_shop":
                    data["bear_gold"] = current_bear_gold()-price
                else:
                    data["gold"]-=price
                if key=="bow": data["bow"]=True
                else: data[key]=data.get(key,0)+amount
                save_data(); set_message(f"ALINDI: {name}",1.2)
            else: set_message("Yeterli altin yok!",1.5)
    back=pygame.Rect(20,20,125,48)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state=back_state

# ------------------------------------------------------------
# CONQUEST / WARBAND STYLE - GELISTIRILMIS
# ------------------------------------------------------------

# ------------------------------------------------------------
# FETIH DUNYASI V21 - LIMANLAR, KITA GECITLERI, KESIF VE CANLI DUNYA
# ------------------------------------------------------------
CONTINENT_COUNT=6
WORLD_W=W*CONTINENT_COUNT
WORLD_H=max(H,900)
cities=[]
bandits=[]
world_player=[W*.35,H*.62]
soldiers=0
owned=0
conquest_class=0
conquest_level=1
conquest_xp=0
bandit_loot=0
trade_post=[W*.55,H*.18]
world_camera_x=0
aggression=0
world_day=0
nation_armies=[]
nation_timer=0
siege_count=0
unlocked_continents=1
continent_notice=0
conquest_hp=120
conquest_hp_max=120
nation_wars=[]
war_timer=0
world_tick=0
joined_nation=-1
nation_rank=0
king_of=-1
nation_favor=0

NATIONS=[
    {"name":"Kuzey Kralligi","color":(65,120,205)},
    {"name":"Kizil Imparatorluk","color":(185,55,50)},
    {"name":"Dag Hanligi","color":(130,95,55)},
    {"name":"Yesil Birlik","color":(45,145,75)},
    {"name":"Altin Sultanligi","color":(190,145,40)},
    {"name":"Kara Lejyon","color":(105,70,135)},
]

CONQUEST_CLASSES=[
    ("Kasli Adam","Yakin dovus gucu yuksek",(185,70,55)),
    ("Tuccar","Haydut satisinda daha cok kazanc",(190,145,45)),
    ("Cevik Adam","Hareket hizi +3",(60,160,115))
]

def army_limit():
    limits={1:15,2:21,3:28}
    return limits.get(conquest_level,28+(conquest_level-3)*7)

def city_recruit_cost(c):
    return 35+max(0,c.get("power",10)-10)*2

def continent_names():
    return ["BATI KITASI","MERKEZ KITASI","KUZEY BUZ KITASI","UZAK DOGU","GUNEY IMPARATORLUGU","EFSANE KITASI"]

CITY_POOLS=[
    ["Sivas","Kuzey Kalesi","Demirhisar","Golkent","Dagkapi","Camlik","Kizilova","Yelhisar","Kartal Kalesi","Bozkir","Akyol","Bati Hisari"],
    ["Taskent","Sarp Dag","Gumuskent","Son Kale","Akdag","Karakaya","Yildizhisar","Kurt Kalesi","Aslanova","Celik Kapi","Yayla Kent","Buyuk Liman"],
    ["Buz Hisari","Firtina Limani","Donmus Gecit","Kutup Kalesi","Ayisigi Kent","Kuzgunova","Karli Taht","Beyaz Surlar","Yalcin Tepe","Demirkoy","Kiskapi","Buztaht"],
    ["Ejder Ovasi","Kizil Liman","Gunes Kent","Zumrut Kale","Kaplan Gecidi","Altinova","Dogu Tahti","Yedi Kule","Savas Limani","Kara Dag","Ipek Sehir","Simsek Kalesi"],
    ["Guney Taht","Yasli Orman","Aslan Limani","Col Kapisi","Sultan Hisari","Kum Denizi","Atesova","Yesil Saray","Golge Kent","Kral Yolu","Yanan Kale","Sonsuz Liman"],
    ["Efsane Sehir","Ejder Tahti","Karanlik Hisar","Titan Kapisi","Gokyuzu Kalesi","Son Imparatorluk","Yildirim Kent","Kader Ovasi","Demir Taht","Sonsuz Surlar","Kayip Liman","Zafer Kalesi"],
]

def generate_continent(continent):
    if any(c.get("continent")==continent for c in cities):
        return
    names=CITY_POOLS[continent]
    for local,n in enumerate(names):
        col=local%4; row=local//4
        x=continent*W+115+col*(W-230)/3
        y=175+row*175+((local*37+continent*19)%48)
        nation=(local+continent*2)%6
        power=10+continent*15+(local*4)%25
        recruits=2+(local%5)+continent
        gate=260+continent*200+local*25
        cities.append({"name":n,"x":x,"y":y,"owner":False,"nation":nation,
                       "power":power,"recruits":recruits,"gate_hp":gate,"gate_max":gate,
                       "defenders":max(4,power//3),"continent":continent})

def spawn_bandits_for_continent(continent,count=8):
    existing=sum(1 for b in bandits if b.get("continent")==continent)
    for _ in range(max(0,count-existing)):
        hp=75+continent*42+random.randint(0,35)
        # Her kıtada yalnızca bir HAYDUT LIDERI gerçek meydan savaşına girer.
        is_leader = (existing == 0 and _ == 0) or (not any(b.get("continent")==continent and b.get("leader") for b in bandits) and _ == 0)
        if is_leader:
            hp *= 3
        bandits.append({"x":continent*W+random.randint(100,W-100),"y":random.randint(170,H-110),
                        "continent":continent,"hp":hp,"max_hp":hp,
                        "strength":(12+continent*7 if is_leader else 6+continent*4+random.randint(0,6)),"loot":(6+continent*3 if is_leader else 1+continent),
                        "leader":is_leader,"name":("HAYDUT LIDERI" if is_leader else "HAYDUT"),
                        "vx":random.choice([-1,1])*random.uniform(.4,1.0),"vy":random.uniform(-.7,.7),
                        "attack_cd":0})

def spawn_patrol_armies(continent):
    existing=sum(1 for a in nation_armies if a.get("continent")==continent and a.get("kind")=="patrol")
    for i in range(max(0,6-existing)):
        n=(continent*2+i)%6
        nation_armies.append({"nation":n,"x":continent*W+random.randint(120,W-120),"y":random.randint(160,H-100),
                              "count":8+continent*5+random.randint(0,8),"continent":continent,
                              "kind":"patrol","target_city":None,"target":"wander","vx":random.uniform(-1,1),"vy":random.uniform(-1,1),"attack_cd":0})

def owned_on_continent(ci):
    return sum(1 for c in cities if c.get("continent")==ci and c.get("owner"))

def discovery_requirement(ci):
    return min(4,2+ci)

def can_discover_next(ci):
    return owned_on_continent(ci)>=discovery_requirement(ci) or conquest_level>=ci+2

def unlock_continent(ci):
    global unlocked_continents,continent_notice
    if ci>=CONTINENT_COUNT or ci<unlocked_continents:
        return False
    generate_continent(ci); spawn_bandits_for_continent(ci,8+ci*2); spawn_patrol_armies(ci)
    unlocked_continents=ci+1; continent_notice=220
    set_message(f"YENI KITA KESFEDILDI: {continent_names()[ci]}!",3)
    return True

def setup_conquest(reset=False):
    global cities,bandits,world_player,soldiers,owned,conquest_level,conquest_xp,bandit_loot,aggression,world_day,nation_armies,nation_timer,siege_count,unlocked_continents,continent_notice,conquest_hp,nation_wars,war_timer,world_tick,joined_nation,nation_rank,king_of,nation_favor
    saved=data.get("conquest")
    if saved and not reset:
        try:
            cities=saved.get("cities",[]); world_player=saved.get("player",[W*.35,H*.62])
            soldiers=saved.get("soldiers",0); owned=saved.get("owned",sum(1 for c in cities if c.get("owner")))
            conquest_level=saved.get("level",1); conquest_xp=saved.get("xp",0); bandit_loot=saved.get("bandit_loot",0)
            aggression=saved.get("aggression",0); world_day=saved.get("world_day",1)
            nation_armies=saved.get("nation_armies",[]); bandits=saved.get("bandits",[])
            unlocked_continents=max(1,min(CONTINENT_COUNT,saved.get("unlocked_continents",1)))
            conquest_hp=saved.get("hp",conquest_hp_max); nation_wars=saved.get("nation_wars",[])
            siege_count=saved.get("siege_count",0); joined_nation=saved.get("joined_nation",-1); nation_rank=saved.get("nation_rank",0); king_of=saved.get("king_of",-1); nation_favor=saved.get("nation_favor",0); nation_timer=0; war_timer=0; world_tick=0; continent_notice=0
            for ci in range(unlocked_continents):
                generate_continent(ci); spawn_bandits_for_continent(ci,8+ci*2); spawn_patrol_armies(ci)
            return
        except Exception:
            pass
    cities=[]; bandits=[]; nation_armies=[]; nation_wars=[]; unlocked_continents=1; continent_notice=0
    generate_continent(0); spawn_bandits_for_continent(0,8); spawn_patrol_armies(0)
    world_player=[W*.30,H*.62]; soldiers=0; owned=0; conquest_level=1; conquest_xp=0; bandit_loot=0
    aggression=0; joined_nation=-1; nation_rank=0; king_of=-1; nation_favor=0; world_day=1; nation_timer=0; war_timer=0; world_tick=0; siege_count=0; conquest_hp=conquest_hp_max
    data["gold"]=150; save_data()

def save_conquest():
    data["conquest"]={"cities":cities,"player":world_player,"soldiers":soldiers,"owned":owned,
        "level":conquest_level,"xp":conquest_xp,"bandit_loot":bandit_loot,"aggression":aggression,
        "world_day":world_day,"nation_armies":nation_armies,"bandits":bandits,"hp":conquest_hp,
        "nation_wars":nation_wars,"unlocked_continents":unlocked_continents,"siege_count":siege_count,"joined_nation":joined_nation,"nation_rank":nation_rank,"king_of":king_of,"nation_favor":nation_favor}
    save_data()

def conquest_class_screen(touches,click):
    global state,conquest_class
    draw_menu_background(); text("FETIH KAHRAMANINI SEC",FT,GOLD,W//2,65)
    text("6 devlet, limanlar, kita gecitleri ve canli dunya.",FS,WHITE,W//2,115)
    for i,(name,bonus,col) in enumerate(CONQUEST_CLASSES):
        r=pygame.Rect(W//2-285,160+i*110,570,88); panel(r,(43,49,60),col,16)
        draw_warrior(r.x+58,r.centery+8,min(i+1,3),1.25); text(name,FM,WHITE,r.x+120,r.y+27,False); text(bonus,FS,GOLD,r.x+120,r.y+62,False)
        if click and touched(touches,r): conquest_class=i; data["conquest_class"]=i; state="conquest_start"
    back=pygame.Rect(20,20,125,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,back):state="menu"

def conquest_start_screen(touches,click):
    global state
    draw_menu_background(); text("FETIH MODU",FT,GOLD,W//2,H*.18)
    text("Yeni oyun 150 ALTIN ile baslar. Yeni kitalar liman ve gecitlerden kesfedilir.",FS,WHITE,W//2,H*.27)
    new_btn=pygame.Rect(W//2-250,int(H*.36),500,72); cont_btn=pygame.Rect(W//2-250,int(H*.48),500,72); back=pygame.Rect(25,20,130,50)
    button(new_btn,"YENI OYUN - 150 ALTIN",GREEN); button(cont_btn,"KAYITTAN DEVAM ET",BLUE); button(back,"GERI",GRAY,True)
    if click and touched(touches,new_btn): data["conquest"]=None; setup_conquest(True); state="conquest"
    elif click and touched(touches,cont_btn):
        if data.get("conquest"): setup_conquest(False); state="conquest"
        else:set_message("KAYITLI FETIH OYUNU YOK!",2)
    elif click and touched(touches,back):state="conquest_class"

def draw_port(x,y,cam,label,locked=False):
    sx=x-cam
    if not -100<sx<W+100:return
    col=(120,80,45) if not locked else (75,75,80)
    pygame.draw.rect(screen,col,(int(sx-30),int(y-18),60,36),border_radius=8)
    pygame.draw.polygon(screen,WHITE,[(sx,y-55),(sx,y-18),(sx+45,y-18)])
    pygame.draw.line(screen,(80,55,35),(sx,y-55),(sx,y+25),4)
    text(label,FS,GOLD if not locked else SILVER,sx,y+43)

def draw_conquest_world():
    screen.fill((35,98,140)); cam=world_camera_x
    biomes=[(70,118,68),(102,92,58),(120,140,150),(170,118,58),(62,125,82),(83,61,96)]
    for k in range(unlocked_continents):
        left=k*W-cam; land=biomes[k]
        pygame.draw.rect(screen,(40,108,154),(int(left),0,W,H))
        pygame.draw.rect(screen,land,(int(left+35),100,W-70,H-145),border_radius=32)
        # her kitada farkli dag, orman ve yol yogunlugu
        for i in range(10+k%3):
            x=left+i*W/9-55; peak=100+(i*31+k*43)%140
            pygame.draw.polygon(screen,(43,55,61),[(x,255),(x+W/18,peak),(x+W/8,255)])
            pygame.draw.polygon(screen,(110,115,110),[(x+W/18,peak),(x+W/14,peak+42),(x+W/18,255)])
        for i in range(24):
            x=left+65+(i*137+k*47)%int(W-130); y=265+(i*91+k*29)%max(130,H-370)
            pygame.draw.circle(screen,(26,78,42),(int(x),int(y)),7+(i%5)*3)
        # liman ve kita gecidi
        draw_port(k*W+W*.82,H*.73,cam,"LIMAN",False)
        if k<CONTINENT_COUNT-1:
            gx=(k+1)*W-58; gy=H*.32; sx=gx-cam
            pygame.draw.rect(screen,(88,67,42),(int(sx-18),int(gy-42),36,84),border_radius=5)
            pygame.draw.rect(screen,GOLD if can_discover_next(k) else GRAY,(int(sx-20),int(gy-44),40,88),3,border_radius=5)
            text("KITA GECIDI",FS,GOLD if can_discover_next(k) else SILVER,sx,gy+63)
        text(continent_names()[k],FS,GOLD,left+W/2,76)
    # kesif sisi ve yeni kitaya ait koyu alan
    fog_left=unlocked_continents*W-cam
    if fog_left<W:
        pygame.draw.rect(screen,(18,24,34),(int(max(0,fog_left)),0,W,H))
        text("KESFEDILMEMIS TOPRAKLAR",FM,(145,150,165),max(0,fog_left)+W//2,H//2)
    tx,ty=trade_post; tx-=cam
    if -80<tx<W+80:
        pygame.draw.rect(screen,(105,72,42),(int(tx-25),int(ty-20),50,40)); pygame.draw.polygon(screen,(145,50,40),[(tx-32,ty-20),(tx,ty-48),(tx+32,ty-20)])
        text("HAYDUT PAZARI",FS,GOLD,tx,ty+35)

def start_nation_war():
    global nation_wars
    a=random.randrange(6); b=random.randrange(6)
    while b==a:b=random.randrange(6)
    pair=[a,b]
    if not any(set(w.get("pair",[]))==set(pair) for w in nation_wars):
        nation_wars.append({"pair":pair,"time":random.randint(35,65)})
        set_message(f"SAVAS ILANI! {NATIONS[a]['name']} vs {NATIONS[b]['name']}",3)

def choose_enemy_city(nation):
    enemies=[]
    for w in nation_wars:
        if nation in w.get("pair",[]):
            other=w["pair"][0] if w["pair"][1]==nation else w["pair"][1]
            enemies += [c for c in cities if not c.get("owner") and c.get("nation")==other and c.get("continent",0)<unlocked_continents]
    return random.choice(enemies) if enemies else None

def spawn_nation_army(nation,target_city=None,kind="patrol"):
    ci=target_city.get("continent",0) if target_city else random.randrange(max(1,unlocked_continents))
    x=ci*W+random.randint(100,W-100); y=random.randint(150,H-90)
    count=8+ci*5+random.randint(0,8)+aggression//3
    nation_armies.append({"nation":nation,"x":x,"y":y,"count":count,"continent":ci,"kind":kind,
                          "target_city":target_city.get("name") if target_city else None,
                          "target":"city" if target_city else "wander","vx":random.uniform(-1,1),"vy":random.uniform(-1,1),"attack_cd":0})

def update_nation_armies(dt):
    global nation_timer,war_timer,world_day,owned,aggression,conquest_hp
    nation_timer+=dt; war_timer+=dt
    if war_timer>18:
        war_timer=0
        if random.random()<.75:start_nation_war()
    for w in nation_wars[:]:
        w["time"]-=dt
        if w["time"]<=0:nation_wars.remove(w)
    if nation_timer>7:
        nation_timer=0; world_day+=1
        # savastaki devletler hedef sehirlere yeni ordular gonderir
        for w in nation_wars:
            for n in w["pair"]:
                target=choose_enemy_city(n)
                if target:spawn_nation_army(n,target,"war")
        # saldirganlik artarsa oyuncu ve sehirleri avlayan ordular
        if aggression>=8:
            for n in range(6):
                if random.random()<min(.8,.20+aggression*.04):
                    spawn_nation_army(n,None,"hunter")
    for a in nation_armies[:]:
        if a.get("kind")=="hunter":
            tx,ty=world_player
        elif a.get("target_city"):
            target=next((c for c in cities if c.get("name")==a["target_city"]),None)
            if target:tx,ty=target["x"],target["y"]
            else:tx,ty=a["x"]+a.get("vx",0)*100,a["y"]+a.get("vy",0)*100
        else:
            target=choose_enemy_city(a["nation"])
            if target:
                a["target_city"]=target["name"]; a["kind"]="war"; tx,ty=target["x"],target["y"]
            else:
                if random.random()<.015:a["vx"]+=random.uniform(-1,1);a["vy"]+=random.uniform(-1,1)
                tx,ty=a["x"]+a.get("vx",0)*80,a["y"]+a.get("vy",0)*80
        dx=tx-a["x"];dy=ty-a["y"];d=max(1,math.hypot(dx,dy)); sp=1.0+min(1.5,a["count"]*.025)
        a["x"]+=dx/d*sp; a["y"]+=dy/d*sp
        a["x"]=clamp(a["x"],50,unlocked_continents*W-50);a["y"]=clamp(a["y"],120,H-55)
        # devlet ordusu oyuncuya saldirabilir
        pd=math.hypot(world_player[0]-a["x"],world_player[1]-a["y"])
        if a.get("kind")=="hunter" and pd<52:
            a["attack_cd"]=max(0,a.get("attack_cd",0)-dt)
            if a["attack_cd"]<=0:
                a["attack_cd"]=1.1; dmg=max(5,a["count"]//3); conquest_hp-=dmg
                set_message(f"{NATIONS[a['nation']]['name']} ordusu sana saldirdi! -{dmg} CAN",1.5)
        # hedef sehre varan ordu sehri ele gecirir
        if a.get("target_city") and d<45:
            target=next((c for c in cities if c.get("name")==a["target_city"]),None)
            if target and not target.get("owner"):
                target["nation"]=a["nation"]; a["target_city"]=None; a["kind"]="patrol"
                set_message(f"{NATIONS[a['nation']]['name']} {target['name']} sehrini ele gecirdi!",2.5)

def update_bandits(dt):
    global conquest_hp
    for b in bandits[:]:
        if b.get("continent",0)>=unlocked_continents:continue
        b["attack_cd"]=max(0,b.get("attack_cd",0)-dt)
        d=math.hypot(world_player[0]-b["x"],world_player[1]-b["y"])
        # Güçlü haydut saldırır, zayıf haydut oyuncudan kaçar.
        player_power=conquest_level*12 + soldiers*8 + (18 if conquest_class==0 else 0)
        bandit_power=b.get("strength",10)*10 + (35 if b.get("leader") else 0)
        if d<330:
            dx=(world_player[0]-b["x"])/max(1,d);dy=(world_player[1]-b["y"])/max(1,d)
            if bandit_power>=player_power:
                b["vx"]+=dx*.10;b["vy"]+=dy*.10
            else:
                b["vx"]-=dx*.14;b["vy"]-=dy*.14
        elif random.random()<.02:
            b["vx"]+=random.uniform(-.4,.4);b["vy"]+=random.uniform(-.4,.4)
        sp=max(.35,math.hypot(b["vx"],b["vy"])); maxsp=1.55 if d<330 else 1.0
        b["vx"]=b["vx"]/sp*min(maxsp,sp);b["vy"]=b["vy"]/sp*min(maxsp,sp)
        b["x"]+=b["vx"]*1.7;b["y"]+=b["vy"]*1.45
        lo=b["continent"]*W+55;hi=(b["continent"]+1)*W-55
        if b["x"]<lo or b["x"]>hi:b["vx"]*=-1;b["x"]=clamp(b["x"],lo,hi)
        if b["y"]<140 or b["y"]>H-55:b["vy"]*=-1;b["y"]=clamp(b["y"],140,H-55)
        if d<48 and bandit_power>=player_power and b["attack_cd"]<=0:
            b["attack_cd"]=.9; dmg=max(4,b["strength"]//2);conquest_hp-=dmg
            set_message(f"HAYDUT SALDIRDI! -{dmg} CAN",1.1)

def handle_conquest_defeat():
    global conquest_hp,world_player,soldiers
    if conquest_hp>0:return
    loss=min(data.get("gold",0),50);data["gold"]-=loss;soldiers=max(0,soldiers-1);conquest_hp=conquest_hp_max
    world_player=[W*.25,H*.62];set_message(f"YENILDIN! {loss} ALTIN VE 1 ASKER KAYBETTIN.",3)

def conquest_screen(touches,click,keys):
    global state,world_player,world_camera_x,bandit_loot,conquest_xp,conquest_level,aggression,continent_notice,owned,joined_nation,nation_rank,king_of,nation_favor,soldiers
    dt=1/FPS; update_nation_armies(dt);update_bandits(dt);handle_conquest_defeat()
    speed=4+data["speed"]+(3 if conquest_class==2 else 0)
    dx,dy=movement(touches,keys,speed)
    max_x=unlocked_continents*W-35
    world_player[0]=clamp(world_player[0]+dx,25,max_x);world_player[1]=clamp(world_player[1]+dy,85,H-25)
    world_camera_x=clamp(world_player[0]-W*.5,0,max(0,unlocked_continents*W-W));cam=world_camera_x
    draw_conquest_world();draw_resource_hud()

    # sehirler
    for c in cities:
        if c.get("continent",0)>=unlocked_continents:continue
        sx=c["x"]-cam
        if -60<sx<W+60:
            col=GREEN if c.get("owner") else NATIONS[c.get("nation",0)]["color"]
            pygame.draw.rect(screen,col,(int(sx-22),int(c["y"]-17),44,34),border_radius=7);pygame.draw.rect(screen,GOLD,(int(sx-22),int(c["y"]-17),44,34),2,border_radius=7)
            text(c["name"],FS,WHITE,sx,c["y"]+30);text(f"GUC {c['power']}",FS,SILVER,sx,c["y"]+47)
    # haydutlar
    for b in bandits:
        if b.get("continent",0)>=unlocked_continents:continue
        sx=b["x"]-cam
        if -35<sx<W+35:
            pygame.draw.circle(screen,(42,26,25),(int(sx),int(b["y"])),16);pygame.draw.circle(screen,(200,70,45),(int(sx),int(b["y"])),16,2)
            text("L" if b.get("leader") else "H",FS,WHITE,sx,b["y"]-7)
            text("LIDER" if b.get("leader") else f"{b['strength']}",FS,GOLD,sx,b["y"]-30)
    # devlet ordulari
    for a in nation_armies:
        if a.get("continent",0)>=unlocked_continents:continue
        sx=a["x"]-cam
        if -35<sx<W+35:
            pygame.draw.circle(screen,NATIONS[a["nation"]]["color"],(int(sx),int(a["y"])),14);pygame.draw.circle(screen,WHITE,(int(sx),int(a["y"])),14,2)
            text(str(a["count"]),FS,WHITE,sx,a["y"]-28)

    # oyuncu
    draw_warrior(world_player[0]-cam,world_player[1],char_index,1.05);draw_controls()
    text(f"FETIH | LVL {conquest_level} | ASKER {soldiers}/{army_limit()} | SALDIRGANLIK {aggression}",FS,GOLD,W//2,28)
    text(f"CAN {int(conquest_hp)}/{conquest_hp_max} | KESIF {unlocked_continents}/{CONTINENT_COUNT} KITA | HAYDUT {len(bandits)}",FS,WHITE,W//2,54)
    wars=" | ".join(f"{NATIONS[w['pair'][0]]['name']} vs {NATIONS[w['pair'][1]]['name']}" for w in nation_wars[:2])
    if wars:text(wars,FS,ORANGE,W//2,80)
    if joined_nation>=0:text(f"DEVLET: {NATIONS[joined_nation]['name']} | RUTBE {nation_rank}",FS,GOLD,W//2,105)

    # Yakın devlet ordusu: saldırınca artık doğrudan hasar değil, gerçek meydan savaşı açılır.
    near_army=min(nation_armies,key=lambda a:math.hypot(world_player[0]-a["x"],world_player[1]-a["y"]),default=None)
    if near_army and math.hypot(world_player[0]-near_army["x"],world_player[1]-near_army["y"])<115:
        ar=pygame.Rect(W-270,270,240,52); button(ar,"ORDUYA SALDIR",RED,True)
        talk=pygame.Rect(W-270,330,240,52); button(talk,"ORDUYLA KONUS",BLUE,True)
        if click and touched(touches,talk):
            if joined_nation<0:
                joined_nation=near_army.get("nation",0); nation_rank=1; nation_favor+=5; set_message("ORDUYA KATILDIN!",2)
            elif joined_nation==near_army.get("nation"):
                nation_favor+=10; set_message("ORDUYLA KONUSTUN VE ITIBAR KAZANDIN!",2)
            else:
                set_message("BU ORDU DUSMAN DEVLETE AIT!",2)
        if click and touched(touches,ar):
            start_world_battle("army",near_army)
            return
        if joined_nation==near_army.get("nation"):
            jr=pygame.Rect(W-270,390,240,52);button(jr,"ORDUYA KATIL / DESTEK",GREEN,True)
            if click and touched(touches,jr):
                give=min(soldiers,2); near_army["count"]+=give; soldiers-=give; nation_favor+=8+give*2;set_message("DEVLET ORDUSUNA DESTEK VERDIN!",2)
    nb=pygame.Rect(20,80,170,52);button(nb,"DEVLETLER",BLUE,True)
    if click and touched(touches,nb):state="nation";return

    # Haydutlarda normal savaş eski hızlı sistemdir. SADECE HAYDUT LIDERI gerçek savaşa sokar.
    near_bandit=min(bandits,key=lambda b:math.hypot(world_player[0]-b["x"],world_player[1]-b["y"]),default=None)
    if near_bandit and math.hypot(world_player[0]-near_bandit["x"],world_player[1]-near_bandit["y"])<105:
        bb=pygame.Rect(W-255,270,225,55)
        if near_bandit.get("leader"):
            button(bb,"LIDERE SALDIR",RED,True)
            if click and touched(touches,bb):
                start_world_battle("leader",near_bandit)
                return
        else:
            button(bb,"HAYDUTA SALDIR",BROWN,True)
            if click and touched(touches,bb):
                power=18+soldiers*2+conquest_level*6+(10 if conquest_class==0 else 0);near_bandit["hp"]-=power
            if near_bandit["hp"]<=0:
                bandit_loot+=near_bandit["loot"];conquest_xp+=7+near_bandit["continent"]*4;bandits.remove(near_bandit);set_message("HAYDUT YENILDI! GANIMET ALDIN.",2)
                while conquest_xp>=conquest_level*45:
                    conquest_xp-=conquest_level*45;conquest_level+=1;set_message(f"FETIH SEVIYESI {conquest_level}!",2)
            else:set_message("Hayduta darbe vurdun!",1)

    # kita gecidi ve liman kesfi
    current=min(unlocked_continents-1,int(world_player[0]//W))
    next_ci=current+1
    if next_ci<CONTINENT_COUNT:
        gate_x=(current+1)*W-58;port_x=current*W+W*.82
        dg=math.hypot(world_player[0]-gate_x,world_player[1]-H*.32);dp=math.hypot(world_player[0]-port_x,world_player[1]-H*.73)
        if dg<115 or dp<115:
            ok=can_discover_next(current); label="GECIDE GIR" if dg<115 else "LIMANDAN YOLA CIK"
            r=pygame.Rect(W-290,H-125,260,58);button(r,label,GREEN if ok else GRAY,True)
            req=f"GEREKEN: {discovery_requirement(current)} SEHIR FETHET VEYA LVL {current+2}"
            text("YENI KITA HAZIR!" if ok else req,FS,GOLD if ok else SILVER,W//2,H-35)
            if click and touched(touches,r) and ok:
                if next_ci>=unlocked_continents:unlock_continent(next_ci)
                world_player=[next_ci*W+120,H*.62];world_camera_x=max(0,next_ci*W);set_message(f"{continent_names()[next_ci]} topraklarina vardin!",3)

    visible_cities=[c for c in cities if c.get("continent",0)<unlocked_continents]
    near=min(visible_cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))
    dist=math.hypot(world_player[0]-near["x"],world_player[1]-near["y"])
    enter=pygame.Rect(W-250,75,220,55);attack=pygame.Rect(W-250,140,220,55);save_btn=pygame.Rect(W-250,205,220,55)
    button(enter,"SEHRE GIR",BLUE,True);button(attack,"SEHRE SALDIR",RED,True);button(save_btn,"KAYDET",GREEN,True)
    if dist<90:
        text(f"YAKINDA: {near['name']} | {NATIONS[near['nation']]['name']} | GUC {near['power']}",FS,WHITE,W//2,H-62)
        if click and touched(touches,enter):state="city"
        if click and touched(touches,attack):
            if near.get("owner"):set_message("BU SEHIR ZATEN SENIN!",2)
            else:start_siege(near)
    td=math.hypot(world_player[0]-trade_post[0],world_player[1]-trade_post[1])
    if td<100:
        sell=pygame.Rect(W//2-180,H-115,360,58);button(sell,f"HAYDUT GANIMETI SAT ({bandit_loot})",BROWN,True)
        if click and touched(touches,sell):state="trade"
    if click and touched(touches,save_btn):save_conquest();open_save_screen("conquest");return
    back=pygame.Rect(20,20,125,48);button(back,"MENU",GRAY,True)
    if click and touched(touches,back):save_conquest();state="menu"

def nation_screen(touches,click):
    global state,joined_nation,nation_rank,king_of,nation_favor,data
    screen.fill((30,35,48))
    text("DEVLETLER VE KRALLIK",FT,GOLD,W//2,55)
    if joined_nation>=0:
        title="KRAL" if king_of==joined_nation else ("KOMUTAN" if nation_rank>=3 else ("SUBAY" if nation_rank>=2 else "ASKER"))
        text(f"{NATIONS[joined_nation]['name']} | RUTBE: {title} | ITIBAR: {nation_favor}",FS,WHITE,W//2,105)
        promote=pygame.Rect(W//2-260,145,520,58); need=40+nation_rank*35
        button(promote,f"RUTBE YUKSELT ({need} ITIBAR)",GREEN)
        if click and touched(touches,promote) and nation_favor>=need:
            nation_favor-=need; nation_rank+=1; set_message("RUTBEN YUKSELDI!",2)
        king=pygame.Rect(W//2-260,215,520,58)
        button(king,"KRALLIGI ILAN ET (RUTBE 5 + 3 SEHIR)",RED if nation_rank>=5 and owned>=3 else GRAY)
        if click and touched(touches,king):
            if nation_rank>=5 and owned>=3:
                king_of=joined_nation; set_message(f"ARTIK {NATIONS[joined_nation]['name']} KRALISIN!",3)
            else:set_message("KRAL OLMAK ICIN RUTBE 5 VE 3 SEHIR GEREKLI!",2)
        leave=pygame.Rect(W//2-260,285,520,58);button(leave,"DEVLETTEN AYRIL",GRAY)
        if click and touched(touches,leave):joined_nation=-1;nation_rank=0;king_of=-1;nation_favor=0;set_message("DEVLETTEN AYRILDIN",2)
    else:
        text("Bir devlete katil, ordulariyla savas ve itibar kazan.",FS,SILVER,W//2,105)
        for i,n in enumerate(NATIONS):
            r=pygame.Rect(W//2-300,135+i*62,600,52);button(r,f"{n['name']} DEVLETINE KATIL",n['color'])
            if click and touched(touches,r):joined_nation=i;nation_rank=1;nation_favor=0;set_message(f"{n['name']} ordusuna katildin!",2);break
    back=pygame.Rect(20,20,120,48);button(back,"GERI",GRAY,True)
    if click and touched(touches,back):state="conquest"

def city_screen(touches,click):
    global state,soldiers
    screen.fill((45,38,31))
    near=min(cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))
    # Visual city scene
    pygame.draw.rect(screen,(86,66,47),(0,int(H*.30),W,H))
    for i in range(8):
        x=30+i*(W-60)//7
        pygame.draw.rect(screen,(112,84,57),(x,H//2,58,110))
        pygame.draw.polygon(screen,(70,48,34),[(x-8,H//2),(x+29,H//2-42),(x+66,H//2)])
    pygame.draw.rect(screen,(105,78,54),(W//2-75,H//2-70,150,170))
    pygame.draw.rect(screen,(55,40,29),(W//2-25,H//2+40,50,100))

    text(f"{near['name']} SEHRINE GIRIS",FT,GOLD,W//2,58)
    text(f"{NATIONS[near['nation']]['name']} • GUC {near['power']} • NUFUS {near.get('recruits',0)}",FS,WHITE,W//2,108)
    text("Sokaklarda serbestsin: gitmek istedigin yeri sec.",FS,SILVER,W//2,140)

    market=pygame.Rect(W//2-270,180,255,62)
    tavern=pygame.Rect(W//2+15,180,255,62)
    barracks=pygame.Rect(W//2-270,260,255,62)
    castle_btn=pygame.Rect(W//2+15,260,255,62)
    manage=pygame.Rect(W//2-270,340,255,62)
    walk=pygame.Rect(W//2-270,340,255,62)
    back=pygame.Rect(W//2+15,340,255,62)

    button(market,"PAZARA GIR",BROWN)
    button(tavern,"HANA GIT",PURPLE)
    button(barracks,"GARNIZONA GIT",GREEN)
    button(castle_btn,"KALEYE GIT",RED)
    button(manage,"SEHIR BILGILERI",BLUE)
    button(walk,"SEHIRDE DOLAS",GREEN)
    button(back,"SEHIRDEN CIK",GRAY)

    if click and touched(touches,market):
        state="city_shop"
    elif click and touched(touches,tavern):
        state="city_tavern"
    elif click and touched(touches,barracks):
        state="city_barracks"
    elif click and touched(touches,castle_btn):
        state="city_castle"
    elif click and touched(touches,manage):
        state="city_info"
    elif click and touched(touches,walk):
        city_walk_init()
        state="city_walk"
    elif click and touched(touches,back):
        state="conquest"

def city_tavern_screen(touches,click):
    global state
    screen.fill((40,28,20)); text("HAN • YOLCULAR VE YOLDASLAR",FT,GOLD,W//2,70)
    text("Yolcularla konus, bilgi topla ve yeni maceralar bul.",FS,WHITE,W//2,125)
    text("Sehir dedikodusu: yakindaki yollar haydutlarla dolu.",FS,SILVER,W//2,180)
    back=pygame.Rect(W//2-220,H-120,440,62); button(back,"SEHIR MEYDANINA DON",GRAY)
    if click and touched(touches,back): state="city"

def city_barracks_screen(touches,click):
    global state,soldiers
    screen.fill((32,45,36)); near=min(cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))
    cost=city_recruit_cost(near)
    text("GARNIZON VE ASKERE ALIM",FT,GOLD,W//2,70)
    text(f"Mevcut Ordu: {soldiers}/{army_limit()} • Sehirdeki Gönüllü: {near['recruits']}",FS,WHITE,W//2,125)
    rec=pygame.Rect(W//2-250,180,500,70); back=pygame.Rect(W//2-250,280,500,60)
    button(rec,f"GONULLU ASKERE AL - {cost} ALTIN",GREEN); button(back,"SEHIR MEYDANINA DON",GRAY)
    if click and touched(touches,rec):
        if soldiers>=army_limit(): set_message(f"ASKER LIMITI {army_limit()}! SEVIYE ATLA.",2)
        elif near["recruits"]<=0: set_message("BU SEHIRDE GONULLU KALMADI!",2)
        elif data["gold"]>=cost:
            data["gold"]-=cost; soldiers+=1; near["recruits"]-=1; save_conquest(); set_message("ASKER ORDUYA KATILDI!",1.5)
        else: set_message(f"{cost} ALTIN GEREKLI!",1.5)
    elif click and touched(touches,back): state="city"

def city_castle_screen(touches,click):
    global state
    near=min(cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))
    screen.fill((36,36,42)); text("KALE",FT,GOLD,W//2,70)
    text(f"Kapi Dayanikliligi: {near['gate_hp']} • Sehir Savunma Gucu: {near['power']}",FS,WHITE,W//2,130)
    text("Yonetim, diplomasi ve savunma burada takip edilir.",FS,SILVER,W//2,175)
    back=pygame.Rect(W//2-220,H-120,440,62); button(back,"SEHIR MEYDANINA DON",GRAY)
    if click and touched(touches,back): state="city"

def city_info_screen(touches,click):
    global state
    near=min(cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))
    screen.fill((32,40,50)); text("SEHIR BILGILERI",FT,GOLD,W//2,70)
    lines=[f"Devlet: {NATIONS[near['nation']]['name']}",f"Guc: {near['power']}",f"Garnizon: {near.get('defenders',0)}",f"Gonullu: {near['recruits']}"]
    for i,line in enumerate(lines): text(line,FS,WHITE,W//2,130+i*42)
    back=pygame.Rect(W//2-220,H-120,440,62); button(back,"SEHIR MEYDANINA DON",GRAY)
    if click and touched(touches,back): state="city"

def trade_screen(touches,click):
    global state,bandit_loot
    screen.fill((42,34,27));text("HAYDUT TICARETI",FT,GOLD,W//2,90);text(f"ELINDEKI HAYDUT GANIMETI: {bandit_loot}",FM,WHITE,W//2,160)
    sell=pygame.Rect(W//2-240,240,480,72);back=pygame.Rect(W//2-240,340,480,62);value=bandit_loot*(15 if conquest_class==1 else 10)
    button(sell,f"HEPSINI SAT - {value} ALTIN",GREEN);button(back,"DUNYAYA DON",GRAY)
    if click and touched(touches,sell):
        if bandit_loot>0:data["gold"]+=value;bandit_loot=0;save_conquest();set_message("GANIMET SATILDI!",2)
        else:set_message("SATACAK HAYDUT GANIMETI YOK!",2)
    elif click and touched(touches,back):state="conquest"


# ------------------------------------------------------------
# FETIH MEYDAN SAVASI: devlet ordusu ve haydut lideri için gerçek savaş
# ------------------------------------------------------------
world_battle_target=None; world_battle_kind=""; world_battle=[]; world_battle_allies=[]
world_battle_player=[0,0]; world_battle_hp=160; world_battle_attack=0

def start_world_battle(kind,target):
    global world_battle_target,world_battle_kind,world_battle,world_battle_allies,world_battle_player,world_battle_hp,world_battle_attack,state,aggression
    world_battle_target=target; world_battle_kind=kind; world_battle=[]; world_battle_allies=[]
    world_battle_player=[W*.20,H*.52]; world_battle_hp=160; world_battle_attack=0
    if kind=="army":
        enemy_count=max(4,min(24,int(target.get("count",8))))
        enemy_hp=65+target.get("count",8)*3+conquest_level*8
        aggression+=2
    else:
        enemy_count=max(5,min(20,7+target.get("continent",0)*3))
        enemy_hp=75+target.get("strength",12)*8+conquest_level*10
    for i in range(enemy_count):
        world_battle.append({"x":random.randint(W//2,W-80),"y":random.randint(120,H-120),"hp":enemy_hp,"maxhp":enemy_hp,"cd":0})
    for i in range(min(soldiers,10)):
        world_battle_allies.append({"x":W*.25+(i%3)*38,"y":H*.38+(i//3)*46,"hp":95,"cd":0})
    state="world_battle"
    set_message("GERCEK MEYDAN SAVASI BASLADI!",2)

def world_battle_screen(touches,click,keys):
    global state,world_battle_attack,world_battle_hp,soldiers,bandit_loot,conquest_xp,nation_favor,data,aggression
    screen.fill((86,103,70))
    # savaş alanı dekoru
    for i in range(9):
        x=60+i*W//9; pygame.draw.circle(screen,(55,82,48),(x,120+(i%3)*55),18)
    title="DEVLET ORDUSU SAVASI" if world_battle_kind=="army" else "HAYDUT LIDERI SAVASI"
    text(title,FM,GOLD,W//2,32)
    speed=5+data["speed"]
    dx,dy=movement(touches,keys,speed)
    world_battle_player[0]=clamp(world_battle_player[0]+dx,25,W-25); world_battle_player[1]=clamp(world_battle_player[1]+dy,85,H-25)
    atk=pygame.Rect(W-165,H-125,135,70);button(atk,"VUR",RED,True)
    if click and touched(touches,atk): world_battle_attack=.25
    world_battle_attack=max(0,world_battle_attack-1/FPS)
    # düşman yapay zekası
    for e in world_battle[:]:
        targets=[("p",world_battle_player[0],world_battle_player[1])]+[(a,a["x"],a["y"]) for a in world_battle_allies]
        tgt=min(targets,key=lambda t:math.hypot(t[1]-e["x"],t[2]-e["y"]))
        vx=tgt[1]-e["x"]; vy=tgt[2]-e["y"]; d=max(1,math.hypot(vx,vy))
        e["x"]+=vx/d*2.1; e["y"]+=vy/d*2.1; e["cd"]-=1/FPS
        if d<48 and e["cd"]<=0:
            dmg=8+conquest_level*2
            if tgt[0]=="p": world_battle_hp-=dmg
            else: tgt[0]["hp"]-=dmg
            e["cd"]=.7
        if world_battle_attack>0 and math.hypot(world_battle_player[0]-e["x"],world_battle_player[1]-e["y"])<95:
            e["hp"]-=data["damage"]*CHARACTERS[char_index]["bonus"]*.15
        if e["hp"]<=0: world_battle.remove(e); conquest_xp+=3
        else:
            draw_warrior(e["x"],e["y"],1,1,True); hpbar(e["x"],e["y"]-55,e["hp"],e["maxhp"])
    # oyuncunun askerleri
    for a in world_battle_allies[:]:
        if a["hp"]<=0:
            world_battle_allies.remove(a); soldiers=max(0,soldiers-1); continue
        if world_battle:
            e=min(world_battle,key=lambda z:math.hypot(z["x"]-a["x"],z["y"]-a["y"]))
            vx=e["x"]-a["x"];vy=e["y"]-a["y"];d=max(1,math.hypot(vx,vy))
            a["x"]+=vx/d*1.8;a["y"]+=vy/d*1.8;a["cd"]-=1/FPS
            if d<62 and a["cd"]<=0:e["hp"]-=13+conquest_level*3;a["cd"]=.6
        draw_warrior(a["x"],a["y"],0,.82,False);hpbar(a["x"],a["y"]-45,a["hp"],95,55)
    draw_warrior(world_battle_player[0],world_battle_player[1],char_index,1.2,False,world_battle_attack>0)
    hpbar(world_battle_player[0],world_battle_player[1]-68,world_battle_hp,160,105); draw_controls()
    text(f"DUSMAN {len(world_battle)} | SENIN ASKERLERIN {len(world_battle_allies)}",FS,WHITE,W//2,62)
    if world_battle_hp<=0:
        set_message("SAVASI KAYBETTIN!",2); state="conquest"; return
    if not world_battle:
        if world_battle_kind=="army":
            if world_battle_target in nation_armies:nation_armies.remove(world_battle_target)
            reward=45+conquest_level*12; data["gold"]+=reward
            if world_battle_target.get("nation")==joined_nation:nation_favor+=12
            set_message(f"DEVLET ORDUSU YENILDI! +{reward} ALTIN",3)
        else:
            if world_battle_target in bandits:bandits.remove(world_battle_target)
            reward=world_battle_target.get("loot",8); bandit_loot+=reward; conquest_xp+=25
            set_message(f"HAYDUT LIDERI YENILDI! +{reward} GANIMET",3)
        save_conquest(); state="conquest"

# Kuşatma: oyuncunun topladığı askerler savaşa gerçekten katılır.
battle_city=None; battle=[]; allies=[]; battle_player=[W*.2,H*.5]; battle_hp=150; battle_attack=0; castle=None; gate_hp=0; gate_max=0; wave_timer=0

def spawn_siege_wave():
    global battle,wave_timer
    count=max(3,battle_city.get("defenders",5)+battle_city["power"]//7+conquest_level)
    battle=[]
    basehp=60+battle_city["power"]*4
    for _ in range(count):
        battle.append({"x":random.randint(W//2,W-190),"y":random.randint(120,H-170),"hp":basehp,"maxhp":basehp,"cd":0,"type":"enemy"})
    wave_timer=0

def start_siege(city):
    global battle_city,battle,allies,battle_player,battle_hp,battle_attack,castle,state,gate_hp,gate_max,wave_timer,aggression,siege_count
    battle_city=city; battle_player=[W*.18,H*.52];battle_hp=150;battle_attack=0
    gate_max=city.get("gate_hp",300);gate_hp=gate_max;castle=pygame.Rect(W-165,H//2-105,150,210);wave_timer=0
    allies=[]
    # En fazla ordudaki askerlerin tamamı, ekrana uygun biçimde savaşa katılır.
    for i in range(soldiers):
        allies.append({"x":W*.23+(i%4)*28,"y":H*.42+(i//4)*35,"hp":85,"cd":0})
    aggression+=2; siege_count+=1; spawn_siege_wave();state="siege"

def siege_screen(touches,click,keys):
    global state,battle_hp,battle_attack,owned,soldiers,gate_hp,wave_timer,bandit_loot,conquest_xp,conquest_level,aggression
    screen.fill((112,104,82));pygame.draw.rect(screen,(80,76,72),(W-185,70,170,H-140));pygame.draw.rect(screen,(62,50,42),castle)
    gate=pygame.Rect(castle.x,castle.centery-45,42,90);pygame.draw.rect(screen,(82,48,28),gate);text("KALE KAPISI",FS,GOLD,castle.centerx,castle.y-20);hpbar(gate.centerx,gate.y-15,gate_hp,gate_max,100)
    speed=5+data["speed"];dx,dy=movement(touches,keys,speed);battle_player[0]=clamp(battle_player[0]+dx,25,W-25);battle_player[1]=clamp(battle_player[1]+dy,85,H-25)
    atk=pygame.Rect(W-155,H-125,125,70);button(atk,"VUR",RED,True)
    if click and touched(touches,atk):battle_attack=.25
    battle_attack=max(0,battle_attack-1/FPS)
    # Düşmanlar oyuncuya veya en yakın askere saldırır.
    for e in battle[:]:
        targets=[("p",battle_player[0],battle_player[1])]+[(a,a["x"],a["y"]) for a in allies]
        tgt=min(targets,key=lambda t:math.hypot(t[1]-e["x"],t[2]-e["y"]))
        vx=tgt[1]-e["x"];vy=tgt[2]-e["y"];d=max(1,math.hypot(vx,vy));e["x"]+=vx/d*(2.0+battle_city["power"]*.025);e["y"]+=vy/d*(2.0+battle_city["power"]*.025);e["cd"]-=1/FPS
        if d<48 and e["cd"]<=0:
            dmg=8+battle_city["power"]*.35
            if tgt[0]=="p": battle_hp-=dmg
            else: tgt[0]["hp"]-=dmg
            e["cd"]=.7
        if battle_attack>0 and math.hypot(battle_player[0]-e["x"],battle_player[1]-e["y"])<95:e["hp"]-=data["damage"]*CHARACTERS[char_index]["bonus"]*.14
        if e["hp"]<=0:battle.remove(e);bandit_loot+=1;conquest_xp+=5
        else:draw_warrior(e["x"],e["y"],1,1,True);hpbar(e["x"],e["y"]-55,e["hp"],e["maxhp"])
    # Bizim askerlerimiz gerçekten saldırır.
    for a in allies[:]:
        if a["hp"]<=0:
            allies.remove(a); soldiers=max(0,soldiers-1); continue
        if battle:
            e=min(battle,key=lambda z:math.hypot(z["x"]-a["x"],z["y"]-a["y"]))
            dx=e["x"]-a["x"];dy=e["y"]-a["y"];d=max(1,math.hypot(dx,dy));a["x"]+=dx/d*1.8;a["y"]+=dy/d*1.8;a["cd"]-=1/FPS
            if d<62 and a["cd"]<=0:e["hp"]-=12+conquest_level*3;a["cd"]=.6
        draw_warrior(a["x"],a["y"],0,.82,False);hpbar(a["x"],a["y"]-45,a["hp"],85,55)
    if not battle and gate_hp>0:
        if battle_attack>0 and math.hypot(battle_player[0]-gate.centerx,battle_player[1]-gate.centery)<125:gate_hp-=data["damage"]*CHARACTERS[char_index]["bonus"]*.10
        # Askerler kapıya da yardım eder.
        for a in allies:
            if math.hypot(a["x"]-gate.centerx,a["y"]-gate.centery)<150: gate_hp-=.7
        wave_timer+=1/FPS;text(f"YENI BIRLIK: {max(0,3-wave_timer):.1f} sn",FS,RED,W//2,68)
        if wave_timer>=3:spawn_siege_wave();set_message("KALEYE YENI SAVUNMA BIRLIGI GELDI!",2)
    draw_warrior(battle_player[0],battle_player[1],char_index,1.2,False,battle_attack>0);hpbar(battle_player[0],battle_player[1]-68,battle_hp,150,100);draw_controls()
    text(f"KUSATMA | SENIN ASKERLERIN: {len(allies)} | DUSMAN: {len(battle)}",FM,GOLD,W//2,32)
    if battle_hp<=0:set_message("Kusatma kaybedildi!",2);state="conquest"
    if gate_hp<=0 and not battle and battle_player[0]>=castle.x:
        battle_city["owner"]=True;owned+=1;conquest_xp+=50+battle_city["power"]*2;data["gold"]+=battle_city["power"]*8
        aggression+=1; save_conquest();set_message("SEHIR FETHEDILDI! DEVLETLER SENI TEHDIT OLARAK GORUYOR.",3);state="conquest"
    while conquest_xp>=conquest_level*100:
        conquest_xp-=conquest_level*100;conquest_level+=1;set_message(f"SEVIYE {conquest_level}! ASKER LIMITI {army_limit()}",3)

# ------------------------------------------------------------
# MULTIPLAYER LOBBY
# ------------------------------------------------------------

# Multiplayer mod seçimi ve bekleme lobisi.
# Oyun seçilir ama ikinci oyuncu gelmeden maç başlamaz.
selected_multi_mode = None
waiting_started = 0
waiting_players = 1
room_ip = "192.168.1.10"

def multiplayer_screen(touches,click):
    global state, selected_multi_mode
    draw_menu_background()
    text("MULTIPLAYER LOBISI",FT,GOLD,W//2,55)
    text("Bir mod seç, sonra KATIL ile odaya gir.",FS,WHITE,W//2,105)

    fight15=pygame.Rect(W//2-250,145,500,62)
    potato=pygame.Rect(W//2-250,220,500,62)
    growth_btn=pygame.Rect(W//2-250,295,500,58)
    hill_btn=pygame.Rect(W//2-250,365,500,54)
    hide_btn=pygame.Rect(W//2-250,425,500,54)
    join=pygame.Rect(W//2-250,485,500,58)
    ip_join=pygame.Rect(W//2-250,550,500,42)
    back=pygame.Rect(20,20,125,48)

    button(fight15,"15 ROUND DOVUS MODU",RED)
    button(potato,"SICAK PATATES",PURPLE)
    button(growth_btn,"GELIS MODU",GREEN)
    button(hill_btn,"TEPENIN KRALI • 2:30",GOLD)
    button(hide_btn,"SAKLAMBAÇ • ZOMBI AVI",GREEN)
    button(join,"KATIL" if selected_multi_mode else "ONCE MOD SEC",BLUE)
    button(ip_join,"IP ILE ODAYA KATIL",BROWN,True)
    button(back,"MENU",GRAY,True)

    # Seçili modu belirginleştir.
    if selected_multi_mode:
        names={"fight":"15 ROUND DOVUS","potato":"SICAK PATATES","growth":"GELIS MODU","hill":"TEPENIN KRALI","hide":"SAKLAMBAÇ"}
        text("SECILI: "+names[selected_multi_mode],FS,GOLD,W//2,545)

    if click and touched(touches,fight15):
        selected_multi_mode="fight"; set_message("15 ROUND secildi. KATIL'a bas.",1.5)
    elif click and touched(touches,potato):
        selected_multi_mode="potato"; set_message("SICAK PATATES secildi. KATIL'a bas.",1.5)
    elif click and touched(touches,growth_btn):
        selected_multi_mode="growth"; set_message("GELIS MODU secildi. KATIL'a bas.",1.5)
    elif click and touched(touches,hill_btn):
        selected_multi_mode="hill"; set_message("TEPENIN KRALI secildi. KATIL'a bas.",0.9)
    elif click and touched(touches,hide_btn):
        selected_multi_mode="hide"; set_message("SAKLAMBAÇ secildi. KATIL'a bas.",0.9)
    elif click and touched(touches,join) and selected_multi_mode:
        start_multiplayer_wait(False)
    elif click and touched(touches,ip_join):
        state="multi_ip"
    elif click and touched(touches,back):
        state="menu"

def start_multiplayer_wait(from_ip=False):
    global state, waiting_started, waiting_players
    waiting_started=pygame.time.get_ticks()
    waiting_players=1
    state="multi_wait"

def multi_ip_screen(touches,click):
    global state, selected_multi_mode, room_ip
    draw_menu_background()
    text("IP ILE KATIL",FT,GOLD,W//2,65)
    text("IP: "+room_ip,FM,WHITE,W//2,150)
    text("Bu sürümde LAN odası bekleme ekranı kullanılır.",FS,SILVER,W//2,195)
    text("Önce multiplayer modunu seç, sonra IP odasına katıl.",FS,WHITE,W//2,235)
    join=pygame.Rect(W//2-240,300,480,72)
    back=pygame.Rect(W//2-240,390,480,60)
    button(join,"IP ODASINA KATIL",BLUE)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,join):
        if not selected_multi_mode:
            set_message("Once bir multiplayer modu sec!",2); state="multiplayer"
        else:
            start_multiplayer_wait(True)
    elif click and touched(touches,back): state="multiplayer"

def multi_wait_screen(touches,click):
    global state, waiting_players
    draw_menu_background()
    elapsed=(pygame.time.get_ticks()-waiting_started)/1000.0
    # Tek cihaz testinde lobi kilitli kalmasın; ikinci oyuncu 2 saniye sonra gelir.
    if elapsed>=2.0: waiting_players=2
    text("ODA BEKLENIYOR",FT,GOLD,W//2,90)
    text(f"OYUNCULAR: {waiting_players}/2",FB,WHITE,W//2,185)
    text("Oyun en az 2 oyuncu olmadan baslamaz.",FS,SILVER,W//2,245)
    panel(pygame.Rect(W//2-230,300,460,70),DARK,GOLD,18)
    text("2. OYUNCU BAGLANIYOR..." if waiting_players<2 else "2 OYUNCU HAZIR!",FM,GREEN if waiting_players>=2 else GOLD,W//2,335)
    cancel=pygame.Rect(W//2-180,420,360,62)
    button(cancel,"LOBDEN CIK",GRAY,True)
    if waiting_players>=2:
        text("MAC BASLIYOR...",FM,GOLD,W//2,535)
        if elapsed>=3.0:
            if selected_multi_mode=="fight": setup_multi_fight(); state="multi_fight"
            elif selected_multi_mode=="potato": setup_hot_potato("multiplayer"); state="hot_potato"
            elif selected_multi_mode=="growth": state="growth"
            elif selected_multi_mode=="hill": setup_hill("multiplayer"); state="hill"
            elif selected_multi_mode=="hide": setup_hide_seek("multiplayer"); state="hide_seek"
    if click and touched(touches,cancel): state="multiplayer"

# ------------------------------------------------------------
# MULTIPLAYER 15 ROUND FIGHT
# ------------------------------------------------------------
multi_player=[W*.28,H*.52]
multi_enemies=[]
multi_round=1
multi_hp=160
multi_attack=0

def setup_multi_fight():
    global multi_player,multi_enemies,multi_round,multi_hp,multi_attack,arrow_projectiles
    multi_player=[W*.28,H*.52]; multi_round=1; multi_hp=160; multi_attack=0; arrow_projectiles=[]
    multi_enemies=[{"x":random.randint(W//2,W-80),"y":random.randint(110,H-160),"hp":80,"cd":0} for _ in range(4)]

def multi_fight_screen(touches,click,keys):
    global state,multi_hp,multi_round,multi_attack
    draw_map(map_index)
    text("MULTIPLAYER - 15 ROUND",FT,GOLD,W//2,35)
    text(f"ROUND {multi_round}/15",FS,WHITE,W//2,72)
    speed=CHARACTERS[char_index]["speed"]+data["speed"]
    dx,dy=movement(touches,keys,speed)
    multi_player[0]=clamp(multi_player[0]+dx,30,W-30); multi_player[1]=clamp(multi_player[1]+dy,90,H-30)
    atk=pygame.Rect(W-155,H-125,125,70); back=pygame.Rect(20,20,125,48); save_btn=pygame.Rect(W-170,82,150,48)
    button(atk,"VUR",RED,True);
    arrow_btn=pygame.Rect(W-155,H-205,125,62) if data.get("bow") else None
    if arrow_btn: button(arrow_btn,"OKLA VUR",BLUE,True)
    button(back,"GERI",GRAY,True)
    button(save_btn,"KAYDET",GREEN,True)
    if click and touched(touches,save_btn): open_save_screen("multi_fight"); return
    if click and touched(touches,atk): multi_attack=.22
    if arrow_btn and click and touched(touches,arrow_btn): fire_arrow(multi_player[0],multi_player[1]-18,multi_enemies)
    if click and touched(touches,back): state="multiplayer"; return
    multi_attack=max(0,multi_attack-1/FPS)
    for e in multi_enemies[:]:
        vx=multi_player[0]-e["x"]; vy=multi_player[1]-e["y"]; dist=max(1,math.hypot(vx,vy))
        e["x"]+=vx/dist*1.5; e["y"]+=vy/dist*1.5; e["cd"]-=1/FPS
        if dist<52 and e["cd"]<=0: multi_hp-=7; e["cd"]=.75
        if multi_attack>0 and dist<92: e["hp"]-=data["damage"]*CHARACTERS[char_index]["bonus"]*.12
        if e["hp"]<=0: multi_enemies.remove(e); data["gold"]+=10
        else:
            draw_warrior(e["x"],e["y"],e.get("ch",1),1.0,True); hpbar(e["x"],e["y"]-55,e["hp"],80)
    update_draw_arrows(multi_enemies)
    draw_warrior(multi_player[0],multi_player[1],char_index,1.25,False,multi_attack>0)
    hpbar(multi_player[0],multi_player[1]-68,multi_hp,160,95); draw_controls()
    if not multi_enemies:
        multi_round+=1
        if multi_round>15:
            data["gold"]+=300; save_data(); set_message("15 ROUND KAZANILDI!",3); state="multiplayer"; return
        n=min(9,3+multi_round//2)
        multi_enemies.extend({"x":random.randint(W//2,W-80),"y":random.randint(110,H-160),"hp":75+multi_round*8,"cd":0} for _ in range(n))
    if multi_hp<=0: set_message("DOVUSU KAYBETTIN!",2); state="multiplayer"

# ------------------------------------------------------------
# SICAK PATATES'E OZEL TUNEL VE ENGELLER
# Ana haritalar ayni kalir; sadece bu modda cizilir.
# ------------------------------------------------------------
def hot_potato_obstacles():
    return [pygame.Rect(W*.40,H*.30,95,28), pygame.Rect(W*.18,H*.66,120,28), pygame.Rect(W*.62,H*.72,105,28), pygame.Rect(W*.47,H*.48,75,30), pygame.Rect(W*.73,H*.25,65,30)]

def hot_potato_tunnels():
    # Aynı haritaların sadece Sıcak Patates sürümünde aktif olan iki uçlu tüneller.
    return [pygame.Rect(18,H*.42,125,72), pygame.Rect(W-143,H*.38,125,72)]

def tunnel_exit(index):
    ts=hot_potato_tunnels(); other=ts[1-index]
    return [other.centerx, other.centery]

def use_hot_tunnel(pos):
    for i,t in enumerate(hot_potato_tunnels()):
        if math.hypot(pos[0]-t.centerx,pos[1]-t.centery)<90:
            return tunnel_exit(i)
    return None

def hp_move(pos,dx,dy):
    nx=clamp(pos[0]+dx,30,W-30); ny=clamp(pos[1]+dy,95,H-30)
    r=pygame.Rect(nx-16,ny-16,32,32)
    for ob in hot_potato_obstacles():
        if r.colliderect(ob):
            nx=pos[0]; ny=pos[1]; break
    return [nx,ny]

def draw_hot_potato_features():
    for t in hot_potato_tunnels():
        pygame.draw.rect(screen,(55,55,65),t,border_radius=10)
        pygame.draw.rect(screen,(180,180,190),t,3,border_radius=10)
        text("TUNEL",FS,WHITE,t.centerx,t.centery)
    for ob in hot_potato_obstacles():
        pygame.draw.rect(screen,(95,70,45),ob,border_radius=5)
        pygame.draw.rect(screen,(190,150,85),ob,2,border_radius=5)

# ------------------------------------------------------------
# HOT POTATO - OTOMATIK YAKALAMA / KOVALAMA
# ------------------------------------------------------------
potato_player=[W*.3,H*.55]
potato_bots=[]
potato_holder=0
potato_time=11.0
potato_return_state="multiplayer"
potato_transfer_lock=0.0  # Patates verildikten sonra geri alma koruması
potato_bot_tunnel_cd=[]

def setup_hot_potato(return_state="multiplayer"):
    global potato_player,potato_bots,potato_holder,potato_time,potato_return_state,potato_transfer_lock,potato_bot_tunnel_cd
    potato_player=[W*.3,H*.55]
    potato_bots=[[W*.65,H*.3],[W*.72,H*.65],[W*.48,H*.75]]
    # Başlangıçta patates bir rakipte: rakip oyuncuya doğru gelir.
    potato_holder=random.randint(1,len(potato_bots))
    potato_time=11.0
    potato_transfer_lock=0.0
    potato_bot_tunnel_cd=[0.0 for _ in potato_bots]
    potato_return_state=return_state

def hot_potato_screen(touches,click,keys):
    global state,potato_time,potato_holder,potato_transfer_lock,potato_bot_tunnel_cd
    draw_map(2)
    draw_hot_potato_features()
    text("SICAK PATATES",FT,GOLD,W//2,38)
    text("Patatesli rakip sana gelir. Patates sende olursa rakipler kaçar!",FS,WHITE,W//2,76)

    speed=CHARACTERS[char_index]["speed"]+data["speed"]
    dx,dy=movement(touches,keys,speed)
    potato_player[:]=hp_move(potato_player,dx,dy)

    # Daha zeki bot AI: taşıyan bot kovalar, diğerleri yol keser/kaçar ve tünel kullanır.
    for i,b in enumerate(potato_bots):
        potato_bot_tunnel_cd[i]=max(0.0,potato_bot_tunnel_cd[i]-1/FPS)
        vx=potato_player[0]-b[0]; vy=potato_player[1]-b[1]
        dist=max(1.0,math.hypot(vx,vy)); ux=vx/dist; uy=vy/dist
        bs=speed*0.82
        mx=my=0.0
        if potato_holder==i+1:
            # Patates taşıyan bot doğrudan kovalamak yerine oyuncunun kaçış yönünü tahmin eder.
            pdx,pdy=movement(touches,keys,speed)
            tx=potato_player[0]+pdx*8; ty=potato_player[1]+pdy*8
            dx=tx-b[0]; dy=ty-b[1]; dd=max(1,math.hypot(dx,dy)); mx=dx/dd*bs; my=dy/dd*bs
        elif potato_holder==0:
            # Patates oyuncudayken en yakın bot kaçarken diğer botlar uzak güvenli noktalar arar.
            flee=bs*(1.05 if dist<210 else .65)
            mx=-ux*flee; my=-uy*flee
        else:
            # Patates başka bottaysa iki bot oyuncunun kaçış yollarını kapatacak şekilde yaklaşır.
            ang=math.atan2(vy,vx)+(0.9 if i%2 else -0.9)
            mx=math.cos(ang)*bs*.55; my=math.sin(ang)*bs*.55
        old=b[:]
        moved=hp_move(b,mx,my); b[0],b[1]=moved
        # Bot tüneli akıllıca kullanır: taşıyan bot oyuncuya uzak tüneli, kaçan bot yakın tüneli seçebilir.
        if potato_bot_tunnel_cd[i]<=0:
            for ti,t in enumerate(hot_potato_tunnels()):
                if math.hypot(b[0]-t.centerx,b[1]-t.centery)<52:
                    exitpos=tunnel_exit(ti)
                    # Çıkış oyuncuya göre avantajlıysa kullan.
                    before=math.hypot(b[0]-potato_player[0],b[1]-potato_player[1])
                    after=math.hypot(exitpos[0]-potato_player[0],exitpos[1]-potato_player[1])
                    if potato_holder==i+1 or (potato_holder==0 and after>before):
                        b[0],b[1]=exitpos; potato_bot_tunnel_cd[i]=2.0
                    break
    # Patates rakipteyse yakına gelince otomatik olarak sana geçer.
    # Patates sende olduğunda ise artık ekrandaki PATATESI VER düğmesine basman gerekir.
    transfer_dist=78
    if potato_holder>0:
        holder=potato_bots[potato_holder-1]
        if potato_transfer_lock<=0 and math.hypot(potato_player[0]-holder[0],potato_player[1]-holder[1])<transfer_dist:
            potato_holder=0
            set_message("PATATES SANA GECTI! SIMDI RAKIBI KOVALA!",1.2)

    potato_time-=1/FPS

    # Karakterleri çiz.
    for i,b in enumerate(potato_bots):
        draw_warrior(b[0],b[1],(i+1)%len(CHARACTERS),1.05,True)

    holder_pos=potato_player if potato_holder==0 else potato_bots[potato_holder-1]
    pygame.draw.circle(screen,(255,120,35),(int(holder_pos[0]),int(holder_pos[1]-55)),15)
    pygame.draw.circle(screen,GOLD,(int(holder_pos[0]),int(holder_pos[1]-55)),15,3)

    draw_warrior(potato_player[0],potato_player[1],char_index,1.25,False)
    draw_controls()
    tunnel_btn=pygame.Rect(20,H-165,210,62)
    near_tunnel=any(math.hypot(potato_player[0]-t.centerx,potato_player[1]-t.centery)<90 for t in hot_potato_tunnels())
    if near_tunnel:
        button(tunnel_btn,"TUNELE GIR",PURPLE,True)
        if click and touched(touches,tunnel_btn):
            out=use_hot_tunnel(potato_player)
            if out:
                potato_player[:]=out; set_message("TUNELDEN DIGER CIKISA GECTIN!",1.2)
    text(f"PATATES: {max(0,potato_time):.1f}",FM,WHITE,W//2,115)
    status=(f"SEN KORUMADASIN: {potato_transfer_lock:.1f} SN" if potato_holder==0 and potato_transfer_lock>0 else "SENDE! RAKIBIN YANINA GIT VE PATATESI VER'E BAS.") if potato_holder==0 else (f"RAKIP KORUMASI: {potato_transfer_lock:.1f} SN - UZAKLAS!" if potato_transfer_lock>0 else "RAKIPTE! UZAKLAS VE SUREYI BITIR.")
    text(status,FS,GOLD,W//2,145)

    # Patates oyuncudayken görünür: yakındaki rakibe patatesi verir.
    give_btn=pygame.Rect(W-235,H-165,215,62)
    if potato_holder==0:
        button(give_btn,"PATATESI VER",ORANGE,True)
        if click and touched(touches,give_btn):
            near=[]
            for i,b in enumerate(potato_bots):
                d=math.hypot(potato_player[0]-b[0],potato_player[1]-b[1])
                if d<transfer_dist:
                    near.append((d,i))
            if near:
                near.sort()
                potato_holder=near[0][1]+1
                # Süre sıfırlanmaz; rakip koruması başlar.
                # Rakip patatesi aldıktan sonra kısa süre geri veremez;
                # böylece oyuncu kaçmak için gerçek bir şans bulur.
                potato_transfer_lock=2.5
                set_message("PATATES RAKIBE VERILDI! 2.5 SN KORUMA! UZAKLAS!",1.2)
            else:
                set_message("PATATESI VERMEK ICIN BIR RAKIBE YAKLAS!",1.2)

    back=pygame.Rect(20,20,125,48)
    save_btn=pygame.Rect(W-170,20,150,48)
    button(back,"GERI",GRAY,True)
    button(save_btn,"KAYDET",GREEN,True)
    if click and touched(touches,save_btn):
        open_save_screen("hot_potato"); return
    if click and touched(touches,back):
        state=potato_return_state
        return

    if potato_time<=0:
        if potato_holder==0:
            set_message("PATATES SENDE PATLADI!",3)
        else:
            data["gold"]+=100
            save_data()
            set_message("RAKIPTE PATLADI! KAZANDIN!",3)
        state=potato_return_state

# ------------------------------------------------------------
# MULTIPLAYER GROWTH (LOCAL SIMULATION)
# ------------------------------------------------------------

def growth_screen(touches,click):
    global state
    draw_map(4)
    draw_resource_hud()
    text("MULTIPLAYER GELIS MODU",FT,GOLD,W//2,65)
    a=pygame.Rect(W//2-240,180,480,75)
    r=pygame.Rect(W//2-240,280,480,75)
    shop=pygame.Rect(W//2-240,380,230,65)
    save_btn=pygame.Rect(W//2+10,380,230,65)
    b=pygame.Rect(20,20,125,48)
    button(a,"ARENA",RED)
    button(r,"YARIS ALANI",GREEN)
    button(shop,"MAGAZA",BROWN,True)
    button(save_btn,"KAYDET",GREEN,True)
    button(b,"MENU",GRAY,True)
    if click and touched(touches,a):state="arena"
    elif click and touched(touches,r):state="race_hub"
    elif click and touched(touches,shop):state="growth_shop"
    elif click and touched(touches,save_btn):open_save_screen("growth")
    elif click and touched(touches,b):state="menu"

arena_points=0
def arena_screen(touches,click):
    global state,arena_points
    draw_map(0)
    text("ARENA",FT,GOLD,W//2,60)
    text(f"PUAN {arena_points}",FM,WHITE,W//2,115)
    fight=pygame.Rect(W//2-200,220,400,80)
    shop=pygame.Rect(W//2-200,320,400,60)
    save_btn=pygame.Rect(W//2-200,390,400,55)
    back=pygame.Rect(20,20,125,48)
    button(fight,"SAVAS VE PUAN KAZAN",RED)
    button(shop,"ARENA MAGAZASI",BROWN,True)
    button(save_btn,"KAYDET",GREEN,True)
    button(back,"GERI",GRAY,True)
    if click and touched(touches,fight):
        arena_points+=10
        data["gold"]+=25
        save_data()
    if click and touched(touches,shop):state="arena_shop"
    if click and touched(touches,save_btn):open_save_screen("arena")
    if click and touched(touches,back):state="growth"

horse=False
race_player=[70,H*.5]
rivals=[]

def race_hub(touches,click):
    global state,horse,rivals,race_player
    draw_map(4)
    text("YARIS ALANI",FT,GOLD,W//2,60)
    buy=pygame.Rect(W//2-230,180,460,70)
    start=pygame.Rect(W//2-230,280,460,70)
    shop=pygame.Rect(W//2-230,380,225,60)
    save_btn=pygame.Rect(W//2+5,380,225,60)
    back=pygame.Rect(20,20,125,48)
    button(buy,"AT SAHIPLISIN" if horse else "AT SATIN AL - 300 ALTIN",BROWN)
    button(start,"YARISA BASLA",GREEN)
    button(shop,"MAGAZA",BROWN,True)
    button(save_btn,"KAYDET",GREEN,True)
    button(back,"GERI",GRAY,True)

    if click and touched(touches,buy) and not horse:
        if data["gold"]>=300:
            data["gold"]-=300;horse=True;save_data()
        else:set_message("300 altin gerekli.",2)

    if click and touched(touches,start):
        if horse:
            race_player=[70,H*.5]
            rivals=[[70,H*.5-85],[70,H*.5+85],[70,H*.5+155]]
            state="race"
        else:set_message("Once at almalisin!",2)

    if click and touched(touches,shop):state="race_shop"
    if click and touched(touches,save_btn):open_save_screen("race_hub")
    if click and touched(touches,back):state="growth"

def race_screen(touches,click,keys):
    global state
    screen.fill((80,130,72))
    track=pygame.Rect(40,120,W-140,H-240)
    pygame.draw.rect(screen,(130,98,58),track,border_radius=20)
    pygame.draw.rect(screen,WHITE,(W-100,120,10,H-240))

    dx,dy=movement(touches,keys,7)
    race_player[0]=clamp(race_player[0]+dx,55,W-105)
    race_player[1]=clamp(race_player[1]+dy,140,H-140)

    draw_warrior(race_player[0],race_player[1],char_index,1.1,False,False,True)
    for rr in rivals:
        rr[0]+=6.4
        draw_warrior(rr[0],rr[1],1,1,True,False,True)

    draw_controls()
    text("YARIS: ILK BITISE ULASAN KAZANIR",FM,GOLD,W//2,50)

    if race_player[0]>=W-105:
        data["gold"]+=250;save_data();set_message("YARISI KAZANDIN!",3);state="growth"
    elif any(rr[0]>=W-105 for rr in rivals):
        set_message("RAKIP YARISI KAZANDI!",2);state="growth"


# ------------------------------------------------------------
# YENI MODLAR: DENIZ SAVASI + KALE FETHI
# ------------------------------------------------------------
def sea_data():
    d=data.get("sea")
    if not isinstance(d,dict): d={}
    defaults={"city":1,"population":120,"troops":20,"ships":1,"cannons":0,"gold":300,"pirates":0,
              "ship_hp":100,"ship_max_hp":100,"ship_level":1,"fish":{},"treasures":0,
              "discovered":1,"x":W*.18,"y":H*.55,"pirate_units":[],"last_fish":0,"fish_xp":0,"map_fragments":0,"relics":0,"island_loot":{},"fishing_active":False,"fishing_start":0,"fish_target":0.5,"fish_name":""}
    for k,v in defaults.items(): d.setdefault(k,v)
    if not isinstance(d.get("fish"),dict): d["fish"]={}
    data["sea"]=d
    return d

SEA_ISLANDS=[
    {"name":"Baslangic Kiyisi","x":.16,"y":.55,"c":(220,195,125),"unlock":1},
    {"name":"Mercan Adasi","x":.48,"y":.28,"c":(230,155,110),"unlock":1},
    {"name":"Firtina Adalari","x":.74,"y":.63,"c":(120,160,95),"unlock":2},
    {"name":"Korsan Takimadalari","x":1.06,"y":.35,"c":(150,120,85),"unlock":3},
    {"name":"Altin Kiyilar","x":1.38,"y":.70,"c":(225,190,75),"unlock":4},
]
FISH_TYPES=[("Hamsi",12),("Levrek",28),("Ton Baligi",55),("Kilic Baligi",110),("Altin Balik",250)]

def sea_spawn_pirates(d):
    if not isinstance(d.get('pirate_units'),list) or not d['pirate_units']:
        d['pirate_units']=[{"x":W*.58,"y":H*.48,"hp":70},{"x":W*.83,"y":H*.25,"hp":100},{"x":W*1.18,"y":H*.68,"hp":130}]

def draw_ship(x,y,level,pirate=False,hp=100):
    # Katmanli, buyudukce fiziksel olarak belirginlesen gemi cizimi
    scale=1.0+level*.18
    ww=int(72*scale); hh=int(28*scale)
    hull=(62,34,22) if pirate else (112,62,35)
    trim=(145,86,42) if pirate else (195,125,62)
    sail=(35,35,42) if pirate else (238,228,198)
    # dalga ve golge
    pygame.draw.ellipse(screen,(8,65,105),(x-ww//2-12,y+hh-3,ww+24,max(8,int(18*scale))))
    pygame.draw.polygon(screen,hull,[(x-ww//2,y),(x+ww//2,y),(x+ww//2-14,y+hh),(x-ww//2+12,y+hh)])
    pygame.draw.line(screen,trim,(x-ww//2+8,y+5),(x+ww//2-8,y+5),max(2,int(3*scale)))
    # pencereler / top delikleri
    for j in range(max(2,level+1)):
        px=int(x-ww*.25+j*ww*.5/max(1,level))
        pygame.draw.circle(screen,(22,20,18),(px,y+int(hh*.48)),max(2,int(3*scale)))
    # direkler
    masts=1 if level<3 else 2 if level<6 else 3
    for m in range(masts):
        mx=int(x+(m-(masts-1)/2)*ww*.32)
        mh=int((62+level*5)*scale)
        pygame.draw.line(screen,(65,45,28),(mx,y+3),(mx,y-mh),max(2,int(4*scale)))
        pygame.draw.polygon(screen,sail,[(mx+3,y-mh+8),(mx+3,y-12),(mx+int(28*scale),y-int(24*scale))])
    # bayrak
    flag=(190,30,30) if pirate else GOLD
    pygame.draw.polygon(screen,flag,[(x+ww//2-6,y-int(45*scale)),(x+ww//2+18,y-int(38*scale)),(x+ww//2-6,y-int(30*scale))])
    if pirate:
        pygame.draw.circle(screen,WHITE,(x+ww//2+5,y-int(38*scale)),max(2,int(3*scale)))
    hpbar(x,y+hh+9,hp,100,72)

def draw_sea_world(d=None,cam=0):
    screen.fill((18,102,158))
    # animated layered waves
    for y in range(55,H,38):
        for x in range(-40,W+80,95):
            off=int((pygame.time.get_ticks()/30+y)%30)
            pygame.draw.arc(screen,(72,168,205),(x-off,y,75,20),0,math.pi,2)
    for isl in SEA_ISLANDS:
        ix=int(isl['x']*W-cam); iy=int(isl['y']*H)
        pygame.draw.ellipse(screen,(45,105,65),(ix-90,iy-42,180,85))
        pygame.draw.ellipse(screen,isl['c'],(ix-72,iy-34,145,68))
        pygame.draw.circle(screen,(35,100,58),(ix-25,iy-35),18)
        pygame.draw.circle(screen,(40,118,62),(ix+18,iy-28),22)
        text(isl['name'],FS,WHITE,ix,iy+48)
    # distant horizon and sun
    pygame.draw.circle(screen,(255,210,85),(W-90,70),35)

def sea_hub(touches,click):
    global state
    d=sea_data(); draw_sea_world(d)
    text("DENIZ SAVASI",FT,GOLD,W//2,42)
    text(f"KIYI KENTI LVL {d['city']} | NUFUS {d['population']} | ORDU {d['troops']}",FS,WHITE,W//2,88)
    text(f"GEMI LVL {d['ship_level']} | CAN {int(d['ship_hp'])}/{int(d['ship_max_hp'])} | TOP {d['cannons']} | ALTIN {d['gold']}",FS,GOLD,W//2,124)
    opts=[("KENTI GELISTIR - 250",165),("NUFUS ARTIR - 100",235),("ASKER TOPLA - 80",305),("GEMIYI BUYUT - 220",375),("TOP SATIN AL - 120",445),("DENIZE ACIL",525)]
    rs=[]
    for label,y in opts:
        r=pygame.Rect(W//2-250,y,500,52); rs.append(r); button(r,label,(40,105,155) if y<525 else GREEN)
    back=pygame.Rect(20,20,130,48); button(back,"GERI",GRAY,True)
    if click:
        if touched(touches,back): state="menu"
        elif touched(touches,rs[0]) and d['gold']>=250: d['gold']-=250; d['city']+=1; d['population']+=60; save_data()
        elif touched(touches,rs[1]) and d['gold']>=100: d['gold']-=100; d['population']+=80; save_data()
        elif touched(touches,rs[2]) and d['gold']>=80: d['gold']-=80; d['troops']+=10; save_data()
        elif touched(touches,rs[3]) and d['gold']>=220: d['gold']-=220; d['ship_level']+=1; d['ship_max_hp']+=40; d['ship_hp']=d['ship_max_hp']; save_data()
        elif touched(touches,rs[4]) and d['gold']>=120: d['gold']-=120; d['cannons']+=1; save_data()
        elif touched(touches,rs[5]):
            if d['ship_hp']<=0: set_message("GEMIN KIRIK! ONARIM YAP.",2)
            else: sea_spawn_pirates(d); state="sea_world"; save_data()

def sea_world(touches,click,keys):
    global state
    d=sea_data(); sea_spawn_pirates(d)
    max_world=W*1.70
    d['x']=float(clamp(d.get('x',W*.18),50,max_world-50)); d['y']=float(clamp(d.get('y',H*.55),100,H-100))
    cam=clamp(d['x']-W*.5,0,max_world-W)
    draw_sea_world(d,cam)
    dx,dy=movement(touches,keys,4.0+d['ship_level']*.30)
    d['x']=clamp(d['x']+dx,40,max_world-40); d['y']=clamp(d['y']+dy,95,H-90)

    # Korsanlar daha anlamli devriye gezer; yakin olduklarinda takip eder.
    for pr in d['pirate_units']:
        vx=d['x']-pr['x']; vy=d['y']-pr['y']; dist=max(1,math.hypot(vx,vy))
        if dist<360: pr['x']+=vx/dist*1.25; pr['y']+=vy/dist*1.25
        else: pr['x']+=math.sin(pygame.time.get_ticks()/850+pr['y'])*.9; pr['y']+=math.cos(pygame.time.get_ticks()/1200+pr['x'])*.35
        pr['x']=clamp(pr['x'],40,max_world-40); pr['y']=clamp(pr['y'],90,H-90)
        if dist<82 and random.random()<.010:
            d['ship_hp']=max(0,d['ship_hp']-(3+pr['hp']//65)); set_message("KORSAN TOPU GEMINE ISABET ETTI!",1)
        draw_ship(int(pr['x']-cam),int(pr['y']),1+int(pr['hp']//110),True,pr['hp'])

    new_disc=int(d['x']//(W*.31))+1
    if new_disc>d['discovered']:
        d['discovered']=min(5,new_disc); set_message(f"YENI DENIZ BOLGESI KESFEDILDI! SEVIYE {d['discovered']}",3)
    draw_ship(int(d['x']-cam),int(d['y']),d['ship_level'],False,max(0,d['ship_hp']))
    text("ACIK DENIZ - OZGOR KESIF",FM,GOLD,W//2,32)
    text(f"GEMI {int(d['ship_hp'])}/{int(d['ship_max_hp'])} | KESIF {d['discovered']}/5 | HARITA PARCASI {d.get('map_fragments',0)}/3 | RELIK {d.get('relics',0)}",FS,WHITE,W//2,68)
    back=pygame.Rect(18,18,125,48); fish_btn=pygame.Rect(W-205,H-150,185,55); attack_btn=pygame.Rect(W-205,H-85,185,55)
    button(back,"LIMANA DON",GRAY,True); button(fish_btn,"BALIK AVCILIGI",BLUE); button(attack_btn,"TOP ATESLE",RED)
    draw_controls()
    if click and touched(touches,back): d['fishing_active']=False; save_data(); state="sea_hub"

    # Balik tutma artik tek tusla para degil: zamanlamali mini oyun.
    now=pygame.time.get_ticks()
    if click and touched(touches,fish_btn):
        if not d.get('fishing_active',False):
            d['fishing_active']=True; d['fishing_start']=now; d['fish_target']=random.uniform(.20,.80)
            d['fish_name']=random.choices([x[0] for x in FISH_TYPES],[48,27,14,7,1.5])[0]
            set_message("OLTA ATILDI! YESIL ALANA GELINCE YAKALA.",2)
        else:
            phase=((now-d['fishing_start'])%2600)/2600.0
            pos=(math.sin(phase*math.pi*2-math.pi/2)+1)/2
            target=d['fish_target']
            difficulty=.10 if d['fish_name'] in ('Hamsi','Levrek') else .065 if d['fish_name']=='Ton Baligi' else .045
            if abs(pos-target)<=difficulty:
                d['fish'][d['fish_name']]=d['fish'].get(d['fish_name'],0)+1; d['fish_xp']+=1
                set_message(f"YAKALADIN: {d['fish_name']}!",2)
            else: set_message("BALIK KACTI! ZAMANLAMAYI TUTTUR.",1)
            d['fishing_active']=False
    if d.get('fishing_active',False):
        phase=((now-d['fishing_start'])%2600)/2600.0; pos=(math.sin(phase*math.pi*2-math.pi/2)+1)/2
        bx=W//2-190; by=H-72; bw=380
        pygame.draw.rect(screen,(20,30,42),(bx,by,bw,24),border_radius=10)
        tx=bx+int(d['fish_target']*bw); tw=26
        pygame.draw.rect(screen,GREEN,(tx-tw//2,by+3,tw,18),border_radius=8)
        pygame.draw.circle(screen,GOLD,(bx+int(pos*bw),by+12),10)
        text("BALIK YAKALA: GOSTERGE YESIL ALANA GELINCE BALIK AVCILIGI",FS,WHITE,W//2,by-20)

    if click and touched(touches,attack_btn):
        hit=None; best=99999
        for pr in d['pirate_units']:
            dist=math.hypot(d['x']-pr['x'],d['y']-pr['y'])
            if dist<best: best=dist; hit=pr
        if hit and best<330:
            hit['hp']-=18+d['cannons']*14+d['ship_level']*4
            if hit['hp']<=0:
                reward=35+random.randint(10,35)+d['pirates']*4
                d['gold']+=reward; d['pirates']+=1; d['pirate_units'].remove(hit); set_message(f"KORSAN GEMISI BATIRILDI! +{reward} ALTIN",3)
            else: set_message("TOP ATESI KORSAN GEMISINE ISABET ETTI!",1)
        else: set_message("KORSAN MENZILDE DEGIL!",1)

    # Ada kesfi: hazine artik nadir, harita parcasi ve relik odakli.
    for isl in SEA_ISLANDS:
        ix=isl['x']*W; iy=isl['y']*H
        if math.hypot(d['x']-ix,d['y']-iy)<115:
            land=pygame.Rect(W//2-180,H-225,360,52); button(land,"ADAYA IN / KESIF YAP",BROWN)
            if click and touched(touches,land):
                key=isl['name']; count=d.get('island_loot',{}).get(key,0)
                d.setdefault('island_loot',{})[key]=count+1
                roll=random.random()
                if d.get('map_fragments',0)>=3 and roll<.16:
                    d['map_fragments']-=3; d['treasures']+=1; d['relics']+=1; d['gold']+=random.randint(45,90)
                    set_message("EFSANEVI HAZINE! RELIK VE ALTIN BULDUN.",3)
                elif roll<.28:
                    d['map_fragments']+=1; set_message("ESKI HARITA PARCASI BULDUN! 3 PARCA HAZINEYI ACAR.",3)
                elif roll<.72:
                    set_message("IZLER BULUNDUN AMA HAZINE YOK. ADAYI DAHA FAZLA ARA.",2)
                else:
                    gain=random.randint(8,24); d['gold']+=gain; set_message(f"KUCUK GANIMET: +{gain} ALTIN",2)
            break

    if d['fish']:
        sell=pygame.Rect(W-430,18,255,48); button(sell,"BALIKLARI SAT",GREEN,True)
        if click and touched(touches,sell):
            # Degerler azaltildi; nadir balik hala anlamli ama ekonomi bozulmuyor.
            values={"Hamsi":6,"Levrek":15,"Ton Baligi":32,"Kilic Baligi":70,"Altin Balik":150}
            total=sum(d['fish'].get(n,0)*values.get(n,5) for n in d['fish'])
            d['gold']+=total; d['fish']={}; set_message(f"BALIKLAR SATILDI: +{total} ALTIN",3)

    if d['ship_hp']<=0:
        repair=pygame.Rect(W//2-230,H//2-45,460,80); cost=150+d['ship_level']*75
        button(repair,f"GEMI KIRILDI - ONAR {cost} ALTIN",RED)
        if click and touched(touches,repair):
            if d['gold']>=cost: d['gold']-=cost; d['ship_hp']=d['ship_max_hp']; set_message("GEMI TAMIR EDILDI!",2)
            else: set_message("YETERLI ALTIN YOK!",2)
    save_data()

def difficulty_select(touches,click):
    global state,game_difficulty
    draw_menu_background(); text("ZORLUK SEC",FT,GOLD,W//2,H*.16)
    text("Classic ve Sonsuz Dusman icin zorlugu sec.",FS,SILVER,W//2,H*.24)
    opts=[("KOLAY",GREEN,"Dusmanlar daha yavas ve daha zayif"),("ORTA",BLUE,"Dengeli savas"),("ZOR",RED,"Cok daha hizli ve guclu dusmanlar")]
    for i,(name,col,desc) in enumerate(opts):
        r=pygame.Rect(W//2-260,int(H*.34)+i*105,520,72);button(r,name,col)
        text(desc,FS,WHITE,W//2,r.bottom+18)
        if click and touched(touches,r): game_difficulty=name; state="map_select"
    back=pygame.Rect(20,20,130,48);button(back,"GERI",GRAY,True)
    if click and touched(touches,back):state="offline"

def castle_data():
    d=data.get("castle")
    if not isinstance(d,dict): d={}
    defaults={"troops":0,"catapults":0,"cannons":0,"wallbreakers":0,"difficulty":"ORTA",
              "gate_hp":0,"wall_hp":0,"enemy_hp":0,"battle":None,"attack_charges":5}
    for k,v in defaults.items(): d.setdefault(k,v)
    data['castle']=d; return d

def castle_difficulty(touches,click):
    global state
    draw_menu_background(); text("KALE FETHI • ZORLUK",FT,GOLD,W//2,H*.15)
    opts=[("KOLAY",GREEN,"Daha zayif garnizon, daha kirilgan surlar"),("ORTA",BLUE,"Dengeli kusatma"),("ZOR",RED,"Guclu garnizon ve sert surlar")]
    for i,(name,col,desc) in enumerate(opts):
        r=pygame.Rect(W//2-275,int(H*.30)+i*120,550,74);button(r,name,col)
        text(desc,FS,WHITE,W//2,r.bottom+20)
        if click and touched(touches,r):
            d=castle_data();d['difficulty']=name;d['gate_hp']=0;d['wall_hp']=0;d['enemy_hp']=0;d['battle']=None;d['attack_charges']=5
            save_data();play_sfx("click");state="castle_hub"
    back=pygame.Rect(20,20,130,48);button(back,"GERI",GRAY,True)
    if click and touched(touches,back):state="offline"

def draw_siege_castle(d,b):
    wall_hp=d['wall_hp']; gate_hp=d['gate_hp']; enemy_hp=d['enemy_hp']
    screen.fill((60,110,145))
    pygame.draw.rect(screen,(55,82,52),(0,H*.50,W,H*.50))
    # distant mountains and flags
    for x in range(0,W,95):
        pygame.draw.polygon(screen,(66,70,74),[(x,H*.28),(x+48,H*.12),(x+96,H*.28)])
    # fortress body
    pygame.draw.rect(screen,(104,92,78),(W*.55,H*.24,W*.38,H*.46))
    pygame.draw.rect(screen,(72,68,63),(W*.53,H*.35,W*.42,H*.10))
    for x in (W*.57,W*.85):
        pygame.draw.rect(screen,(120,108,90),(x,H*.14,W*.085,H*.52))
        pygame.draw.rect(screen,(68,63,59),(x-8,H*.12,W*.102,H*.07))
        pygame.draw.polygon(screen,RED,[(x+W*.04,H*.10),(x+W*.04,H*.05),(x+W*.085,H*.08)])
    # wall cracks appear as damage increases
    maxwall=max(1,b.get("max_wall",1))
    dmg_ratio=1-max(0,wall_hp)/maxwall
    for i in range(int(dmg_ratio*16)):
        x=int(W*.56+(i*61)%(W*.35)); y=int(H*.36+(i*37)%(H*.22))
        pygame.draw.line(screen,(45,40,38),(x,y),(x+12,y+18),3)
    gate=pygame.Rect(int(W*.72),int(H*.48),int(W*.11),int(H*.22))
    pygame.draw.rect(screen,(92,49,28),gate,border_radius=8)
    pygame.draw.line(screen,(45,25,18),gate.topleft,gate.bottomright,5)
    # HP bars with fixed maximums
    hpbar(W*.70,H*.31,wall_hp,max(1,b.get("max_wall",1)),230); text("SUR",FS,GOLD,W*.70,H*.28)
    hpbar(W*.775,H*.45,gate_hp,max(1,b.get("max_gate",1)),150); text("KALE KAPISI",FS,GOLD,W*.775,H*.42)
    hpbar(W*.88,H*.31,enemy_hp,max(1,b.get("max_enemy",1)),150); text("GARNIZON",FS,GOLD,W*.88,H*.28)
    # catapult and cannon
    pygame.draw.circle(screen,(45,35,30),(int(W*.20),int(H*.73)),20);pygame.draw.circle(screen,(45,35,30),(int(W*.30),int(H*.73)),20)
    pygame.draw.line(screen,(125,82,38),(W*.20,H*.70),(W*.30,H*.58),8)
    pygame.draw.rect(screen,(80,70,62),(W*.39,H*.68,W*.12,H*.06))
    pygame.draw.circle(screen,(30,30,33),(int(W*.41),int(H*.75)),15);pygame.draw.circle(screen,(30,30,33),(int(W*.49),int(H*.75)),15)
    pygame.draw.rect(screen,(40,40,42),(W*.45,H*.64,W*.08,H*.025))

def castle_hub(touches,click):
    global state
    d=castle_data(); draw_map(4)
    text("🏰 KALE FETHI • GERCEK KUSATMA",FT,GOLD,W//2,40)
    text(f"ALTIN: {int(data.get('gold',0))}  |  ZORLUK: {d['difficulty']}",FM,GOLD,W//2,88)
    text(f"ASKER {d['troops']}  |  MANCINIK {d['catapults']}  |  TOP {d['cannons']}  |  KOCBASI {d['wallbreakers']}",FS,WHITE,W//2,125)
    specs=[("ASKER AL +5 • 100 ALTIN",175,"troops",5,100,GREEN),("MANCINIK AL • 180 ALTIN",245,"catapults",1,180,BROWN),("TOP AL • 220 ALTIN",315,"cannons",1,220,RED),("KOCBASI AL • 160 ALTIN",385,"wallbreakers",1,160,ORANGE)]
    for lab,y,k,amt,cost,col in specs:
        r=pygame.Rect(W//2-270,y,540,56);button(r,lab,col)
        if click and touched(touches,r):
            if data.get('gold',0)>=cost:
                data['gold']-=cost;d[k]+=amt;save_data();play_sfx("coin");set_message("KUSATMA ORDUSU GUCLENDI!",1.5)
            else:set_message("YETERLI ALTIN YOK!",2);play_sfx("hit")
    attack=pygame.Rect(W//2-270,455,540,68);button(attack,"KALEYI KUSAT VE SALDIR",RED)
    diff=pygame.Rect(W//2-270,535,540,55);button(diff,"ZORLUGU DEGISTIR",BLUE)
    back=pygame.Rect(20,20,130,48);button(back,"GERI",GRAY,True)
    if click and touched(touches,attack):
        if d['troops']>0: play_sfx("click"); state="castle_battle"
        else:set_message("ONCE ASKER TOPLA!",2)
    if click and touched(touches,diff):state="castle_difficulty"
    if click and touched(touches,back):state="offline"

def init_castle_battle(d):
    mul={"KOLAY":0.75,"ORTA":1.0,"ZOR":1.55}.get(d['difficulty'],1.0)
    if not d.get('battle'):
        max_wall=int(700*mul); max_gate=int(950*mul); max_enemy=int(1000*mul)
        d['wall_hp']=max_wall;d['gate_hp']=max_gate;d['enemy_hp']=max_enemy;d['attack_charges']=5
        d['battle']={"ammo":d['catapults']*7+d['cannons']*10,"enemy_count":int(9*mul)+2,
                     "enemy_archers":max(2,int(3*mul)+d['troops']//12),"flash":0,"reward":int(400*mul),
                     "max_wall":max_wall,"max_gate":max_gate,"max_enemy":max_enemy,
                     "last_enemy_hit":pygame.time.get_ticks(),"player_hp":140,"max_player_hp":140}

def castle_battle(touches,click,keys):
    global state
    d=castle_data();init_castle_battle(d);b=d['battle'];draw_siege_castle(d,b)
    text(f"KUSATMA • {d['difficulty']}",FM,GOLD,W//2,35)
    text(f"ALTIN {int(data.get('gold',0))} | SALDIRI HAKKI {d.get('attack_charges',0)}/5 | MÜHIMMAT {b['ammo']}",FS,GOLD,W//2,74)
    # player and allied troops
    draw_warrior(W*.08,H*.53,data.get("selected_char",0),1.05,False,False)
    hpbar(W*.10,H*.49,b.get("player_hp",140),b.get("max_player_hp",140),95); text("SEN",FS,WHITE,W*.10,H*.46)
    for i in range(min(10,d['troops'])): draw_warrior(W*.17+(i%5)*46,H*.50+(i//5)*65,random.choice([0,1,2,5,6]),.72,False)
    # enemy swordsmen
    for i in range(min(8,b['enemy_count'])): draw_warrior(W*.61+(i%4)*54,H*.40+(i//4)*70,random.choice([1,2,3,5,6]),.78,True)
    # enemy archers (bow + arrows)
    for i in range(min(6,b.get("enemy_archers",0))):
        ax=W*.56+(i%3)*58; ay=H*.26+(i//3)*58
        draw_warrior(ax,ay,3,.68,True)
        pygame.draw.arc(screen,BROWN,(int(ax-18),int(ay-2),22,34),-1.2,1.2,3)
        pygame.draw.line(screen,WHITE,(ax-8,ay+8),(ax+16,ay-6),2)
        text("OKCU",font(H*.022),GOLD,ax,ay-40)
    # action buttons
    sword_wall=pygame.Rect(W*.02,H-142,W*.22,70)
    siege_wall=pygame.Rect(W*.26,H-142,W*.22,70)
    gate_btn=pygame.Rect(W*.50,H-142,W*.22,70)
    troop_btn=pygame.Rect(W*.74,H-142,W*.24,70)
    button(sword_wall,"KILICLA SUR",ORANGE)
    button(siege_wall,"MANCINIK/TOP",BROWN)
    button(gate_btn,"KAPIYA SALDIR",RED)
    button(troop_btn,"GARNIZONA GIR",PURPLE)
    if click and touched(touches,sword_wall):
        if d.get('attack_charges',0)<=0: set_message("BUGUNLUK 5 KILIC SALDIRISI BITTI!",2);play_sfx("hit")
        elif d['wall_hp']<=0: set_message("SUR ZATEN YIKILDI!",1)
        else:
            dmg=8+int(data.get("sword_level",0)*1.5)
            d['wall_hp']-=dmg; d['attack_charges']-=1
            reward=max(1,dmg//3); data['gold']+=reward
            play_sfx("slash"); play_sfx("thud"); set_message(f"KILIC DARBESI -{dmg} SUR! +{reward} ALTIN",1.5)
    if click and touched(touches,siege_wall):
        if b['ammo']>0 and (d['catapults']+d['cannons'])>0:
            dmg=d['catapults']*42+d['cannons']*58+20;d['wall_hp']-=dmg;b['ammo']-=1;b['flash']=.25;play_sfx("boom");set_message(f"KUSATMA ATISI! -{dmg} SUR HASARI",1)
        else:set_message("MÜHIMMAT VEYA KUSATMA MAKINESI YOK!",2);play_sfx("hit")
    if click and touched(touches,gate_btn):
        if d['wall_hp']<=0:
            dmg=d['wallbreakers']*85+d['troops']*7+d['cannons']*25;d['gate_hp']-=max(8,dmg);play_sfx("hit");set_message("KAPIYA YUKLENIYORUZ!",1)
        else:set_message("ONCE SURLARI YIK!",2)
    if click and touched(touches,troop_btn):
        if d['gate_hp']<=0:
            dmg=d['troops']*18+d['catapults']*5+int(data.get("damage",25)*.6)
            d['enemy_hp']-=dmg;b['enemy_count']=max(0,b['enemy_count']-max(1,d['troops']//5));play_sfx("hit");set_message("SEN VE ORDUN GARNIZONA SALDIRIYOR!",1)
        else:set_message("KAPI ACILMADAN GARNIZONA GIREMEZSIN!",2)
    # archers periodically shoot the player/army
    now=pygame.time.get_ticks()
    if now-b.get("last_enemy_hit",now)>1800 and b.get("enemy_archers",0)>0:
        b["last_enemy_hit"]=now
        ad=max(2,int(b["enemy_archers"]*2.2))
        b["player_hp"]=max(0,b.get("player_hp",140)-ad)
        if d["troops"]>0 and random.random()<.55: d["troops"]=max(0,d["troops"]-1)
        play_sfx("hit"); set_message(f"GARNIZON OKCULARI SALDIRDI! -{ad} CAN",1)
    if b.get("player_hp",1)<=0:
        d['battle']=None;save_data();set_message("SAVASTA DUSTUN! KUSATMA GERI CEKILDI.",3);state="castle_hub";return
    if d['enemy_hp']<=0:
        reward=b['reward']+d['troops']*10+d['catapults']*35+d['cannons']*45;data['gold']+=reward;d['battle']=None;save_data();play_sfx("win");set_message(f"KALE FETHEDILDI! +{reward} ALTIN",4);state="castle_hub";return
    if d['troops']<=0:
        d['battle']=None;save_data();set_message("KUSATMA ORDUN YOK EDILDI!",3);state="castle_hub";return
    back=pygame.Rect(20,20,130,48);button(back,"GERI",GRAY,True)
    if click and touched(touches,back):save_data();state="castle_hub"

# ------------------------------------------------------------
# TEPENIN KRALI - OFFLINE + MULTIPLAYER
# ------------------------------------------------------------
hill_mode="offline"
hill_player=[W*.30,H*.58]
hill_bots=[]
hill_scores=[]
hill_start=0
hill_push_cd=0
HILL_DURATION=150.0  # 2 dakika 30 saniye

def setup_hill(kind="offline"):
    global hill_mode,hill_player,hill_bots,hill_scores,hill_start
    hill_mode=kind; hill_player=[W*.30,H*.60]; hill_start=pygame.time.get_ticks()
    n=4 if kind=="offline" else 5
    hill_bots=[]
    for i in range(n):
        hill_bots.append({"x":random.randint(int(W*.10),int(W*.90)),"y":random.randint(int(H*.20),int(H*.85)),"score":0.0,"ch":random.choice([0,1,2,3,5,6,7,8]),"vx":0,"vy":0})
    hill_scores=[0.0]

def hill_char(touches,click):
    # Tepenin Krali karakter secimi kullanmaz: herkes ayni normal ALTIN savasciyla baslar.
    global state
    draw_menu_background()
    text("TEPENIN KRALI",FT,GOLD,W//2,H*.18)
    text("BU MODDA HERKES NORMAL ALTIN SAVASCI OLARAK OYNAR",FM,WHITE,W//2,H*.31)
    preview=pygame.Rect(W//2-220,int(H*.40),440,150)
    panel(preview,(55,50,38),GOLD,18)
    draw_hill_gold_warrior(preview.centerx,preview.centery+25,1.55)
    play=pygame.Rect(W//2-240,int(H*.68),480,66); button(play,"OYUNA BASLA",GREEN)
    back=pygame.Rect(20,20,130,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,play): setup_hill("offline"); state="hill"; play_sfx("click")
    if click and touched(touches,back): state="offline"

def draw_hill_gold_warrior(x,y,s=1.0):
    x=int(x); y=int(y); gold=(210,157,48); light=(255,220,105); dark=(62,45,30)
    # daha temiz normal altin asker
    pygame.draw.polygon(screen,(130,85,35),[(x-22*s,y-5*s),(x+22*s,y-5*s),(x+26*s,y+36*s),(x-26*s,y+36*s)])
    pygame.draw.rect(screen,gold,(int(x-19*s),int(y-6*s),int(38*s),int(38*s)),border_radius=max(5,int(8*s)))
    pygame.draw.rect(screen,light,(int(x-16*s),int(y+2*s),int(32*s),int(5*s)),border_radius=3)
    pygame.draw.circle(screen,(238,190,150),(x,int(y-25*s)),int(14*s))
    pygame.draw.arc(screen,(95,65,38),(int(x-16*s),int(y-40*s),int(32*s),int(25*s)),3.1,6.25,max(2,int(6*s)))
    pygame.draw.line(screen,dark,(int(x-8*s),int(y+40*s)),(int(x-8*s),int(y+58*s)),max(2,int(5*s)))
    pygame.draw.line(screen,dark,(int(x+8*s),int(y+40*s)),(int(x+8*s),int(y+58*s)),max(2,int(5*s)))
    shield=pygame.Rect(int(x-38*s),int(y),int(19*s),int(34*s)); pygame.draw.ellipse(screen,gold,shield); pygame.draw.ellipse(screen,light,shield,max(2,int(2*s)))
    pygame.draw.line(screen,(230,235,240),(int(x+18*s),int(y+8*s)),(int(x+45*s),int(y-24*s)),max(2,int(4*s)))
    pygame.draw.line(screen,dark,(int(x+12*s),int(y+12*s)),(int(x+28*s),int(y+16*s)),max(2,int(4*s)))

def draw_hill_world():
    # Tepenin Krali'na özel gerçek arena: merkezde yükseltili tepe,
    # sarı hakimiyet alanı, kayalar, sütunlar ve dört giriş yolu.
    screen.fill((25,63,54))
    # dış çerçeve / arena zemini
    pygame.draw.rect(screen,(34,82,62),(0,105,W,H-105))
    for y in range(110,H,12):
        shade=70+int(18*(y-110)/max(1,H-110))
        pygame.draw.line(screen,(30,shade,58),(0,y),(W,y),1)
    # taş arena sınırı
    pygame.draw.rect(screen,(56,68,72),(14,112,W-28,H-128),6,border_radius=24)
    # dört geniş yol merkezi tepeye bağlanır
    road=(106,91,62)
    pygame.draw.polygon(screen,road,[(W*.47,115),(W*.57,115),(W*.55,H*.40),(W*.49,H*.40)])
    pygame.draw.polygon(screen,road,[(W*.47,H-25),(W*.57,H-25),(W*.55,H*.64),(W*.49,H*.64)])
    pygame.draw.polygon(screen,road,[(18,H*.45),(18,H*.57),(W*.41,H*.55),(W*.41,H*.49)])
    pygame.draw.polygon(screen,road,[(W-18,H*.45),(W-18,H*.57),(W*.63,H*.55),(W*.63,H*.49)])
    # merkez tepe: katmanlı yükselti
    cx,cy=W*.52,H*.52
    pygame.draw.ellipse(screen,(55,92,49),(int(cx-W*.23),int(cy-H*.18),int(W*.46),int(H*.36)))
    pygame.draw.ellipse(screen,(83,122,55),(int(cx-W*.19),int(cy-H*.145),int(W*.38),int(H*.29)))
    pygame.draw.ellipse(screen,(122,150,60),(int(cx-W*.145),int(cy-H*.105),int(W*.29),int(H*.21)))
    # sarı kontrol alanı net biçimde görünür
    zone=pygame.Rect(int(cx-W*.105),int(cy-H*.078),int(W*.21),int(H*.156))
    pygame.draw.ellipse(screen,(218,176,35),zone)
    pygame.draw.ellipse(screen,(255,224,86),zone,5)
    pygame.draw.ellipse(screen,(255,238,130),zone.inflate(-int(W*.035),-int(H*.026)),2)
    text("SARI ALAN",font(max(18,int(H*.023))),BLACK,cx,cy)
    # stratejik engeller: merkezden uzak, geçişleri tamamen kapatmaz
    obstacles=[(.17,.30),(.84,.30),(.18,.74),(.84,.74),(.34,.24),(.70,.80),(.31,.68),(.73,.35)]
    for i,(px,py) in enumerate(obstacles):
        x=int(W*px); y=int(H*py)
        pygame.draw.ellipse(screen,(48,48,48),(x-24,y-16,48,32))
        pygame.draw.ellipse(screen,(94,96,91),(x-20,y-22,40,30))
        pygame.draw.circle(screen,(120,121,112),(x-8,y-12),5)
    # bayraklar arena hissini güçlendirir
    for px,py in [(W*.07,H*.18),(W*.93,H*.18),(W*.07,H*.84),(W*.93,H*.84)]:
        pygame.draw.line(screen,(110,80,45),(int(px),int(py)),(int(px),int(py+48)),5)
        pygame.draw.polygon(screen,GOLD,[(int(px),int(py)),(int(px+25),int(py+9)),(int(px),int(py+18))])
    return cx,cy,min(W*.105,H*.078)

def hill(touches,click,keys):
    global state
    cx,cy,rr=draw_hill_world()
    elapsed=(pygame.time.get_ticks()-hill_start)/1000.0; remain=max(0,HILL_DURATION-elapsed)
    text("👑 TEPENIN KRALI",FT,GOLD,W//2,38)
    text(f"SURE: {int(remain//60)}:{int(remain%60):02d}  |  SEN: {hill_scores[0]:.1f} SN",FM,WHITE,W//2,78)
    speed=7+data.get("speed",0)
    dx,dy=movement(touches,keys,speed); hill_player[0]=clamp(hill_player[0]+dx,25,W-25); hill_player[1]=clamp(hill_player[1]+dy,110,H-35)
    # Oyuncuya özel ITME düğmesi: yakındaki rakipleri tepeden uzaklaştırır.
    global hill_push_cd
    push_btn=pygame.Rect(W-230,H-112,200,68)
    ready=max(0,(hill_push_cd-pygame.time.get_ticks())/1000)
    button(push_btn,"IT ⚡" if ready<=0 else f"IT {ready:.1f}",ORANGE if ready<=0 else GRAY)
    if click and touched(touches,push_btn) and ready<=0:
        pushed=0
        for bot in hill_bots:
            dd=math.hypot(bot["x"]-hill_player[0],bot["y"]-hill_player[1])
            if dd<145:
                ux=(bot["x"]-hill_player[0])/max(1,dd); uy=(bot["y"]-hill_player[1])/max(1,dd)
                bot["x"]=clamp(bot["x"]+ux*95,25,W-25); bot["y"]=clamp(bot["y"]+uy*95,110,H-35); pushed+=1
        hill_push_cd=pygame.time.get_ticks()+2200
        play_sfx("thud"); set_message(f"ITME! {pushed} RAKIP GERI SAVRULDU",1.2)
    # Bots center priority + push AI
    for bot in hill_bots:
        dx=cx-bot["x"]; dy=cy-bot["y"]; dist=max(1,math.hypot(dx,dy))
        # if player owns center, smart bots target player to push them out
        pd=math.hypot(hill_player[0]-cx,hill_player[1]-cy)
        target=(hill_player[0],hill_player[1]) if pd<rr and random.random()<.48 else (cx,cy)
        tx,ty=target; vx=tx-bot["x"]; vy=ty-bot["y"]; dd=max(1,math.hypot(vx,vy)); sp=2.1
        bot["x"]+=vx/dd*sp; bot["y"]+=vy/dd*sp
        # collision push
        ddp=math.hypot(bot["x"]-hill_player[0],bot["y"]-hill_player[1])
        if ddp<58:
            ux=(hill_player[0]-bot["x"])/max(1,ddp); uy=(hill_player[1]-bot["y"])/max(1,ddp)
            hill_player[0]=clamp(hill_player[0]+ux*3.2,25,W-25); hill_player[1]=clamp(hill_player[1]+uy*3.2,110,H-35)
            play_sfx("thud") if random.random()<.035 else None
        if math.hypot(bot["x"]-cx,bot["y"]-cy)<=rr: bot["score"]+=1/FPS
    if math.hypot(hill_player[0]-cx,hill_player[1]-cy)<=rr: hill_scores[0]+=1/FPS
    for bot in hill_bots: draw_warrior(bot["x"],bot["y"],bot["ch"],.82,True)
    draw_hill_gold_warrior(hill_player[0],hill_player[1],1.0)
    # Kontroller Tepenin Krali'nda da her zaman cizilir.
    draw_controls()
    play_map_ambience(-1)
    leaderboard=sorted([(hill_scores[0],"SEN")]+[(b["score"],"BOT "+str(i+1)) for i,b in enumerate(hill_bots)],reverse=True)[:3]
    for i,(sc,nm) in enumerate(leaderboard): text(f"{i+1}. {nm} • {sc:.0f} SN",FS,GOLD if nm=="SEN" else WHITE,W*.86,H*.18+i*34)
    back=pygame.Rect(20,20,130,48); button(back,"GERI",GRAY,True)
    if remain<=0:
        all_scores=[(hill_scores[0],"SEN")]+[(b["score"],"BOT") for b in hill_bots]
        winner=max(all_scores,key=lambda z:z[0])[1]
        if winner=="SEN": data["gold"]+=250; play_sfx("win"); set_message("TEPENIN KRALI OLDUN! +250 ALTIN",4)
        else: set_message("SURE BITTI! KAZANAN: "+winner,4)
        save_data(); state="offline" if hill_mode=="offline" else "multiplayer"; return
    if click and touched(touches,back): state="offline" if hill_mode=="offline" else "multiplayer"


# ------------------------------------------------------------
# FIRTINA DUELLOSU - YENI OYUN MODU
# ------------------------------------------------------------
storm_player=[W*.28,H*.58]
storm_enemies=[]
storm_start=0
storm_score=0
storm_attack_cd=0
def setup_storm_duel():
    global storm_player,storm_enemies,storm_start,storm_score,storm_attack_cd
    storm_player=[W*.28,H*.58]; storm_start=pygame.time.get_ticks(); storm_score=0; storm_attack_cd=0
    storm_enemies=[{"x":W*.70,"y":H*.42,"hp":70},{"x":W*.78,"y":H*.68,"hp":80},{"x":W*.62,"y":H*.28,"hp":90}]

def storm_duel(touches,click,keys):
    global state,storm_score,storm_attack_cd
    draw_map(7)
    text("⚡ FIRTINA DÜELLOSU",FT,GOLD,W//2,42)
    text(f"SKOR: {storm_score}  •  DALGA: {len(storm_enemies)+1}",FM,WHITE,W//2,82)
    dx,dy=movement(touches,keys,7+data.get("speed",0)); storm_player[0]=clamp(storm_player[0]+dx,30,W-30); storm_player[1]=clamp(storm_player[1]+dy,120,H-35)
    attack=pygame.Rect(W-220,H-105,190,64); button(attack,"SALDIR ⚔",RED)
    now=pygame.time.get_ticks()
    if click and touched(touches,attack) and now>=storm_attack_cd:
        storm_attack_cd=now+450; play_sfx("slash")
        for e in storm_enemies[:]:
            if math.hypot(e["x"]-storm_player[0],e["y"]-storm_player[1])<105:
                e["hp"]-=int(data.get("damage",25)*CHARACTERS[char_index]["bonus"]*.55)
                if e["hp"]<=0: storm_enemies.remove(e); storm_score+=1; data["gold"]+=15; play_sfx("win")
    for e in storm_enemies:
        vx=storm_player[0]-e["x"]; vy=storm_player[1]-e["y"]; dd=max(1,math.hypot(vx,vy)); e["x"]+=vx/dd*1.5; e["y"]+=vy/dd*1.5
        draw_warrior(e["x"],e["y"],random.choice([2,3,4,8]),.9,True)
    draw_warrior(storm_player[0],storm_player[1],char_index,1.0,False)
    draw_controls(); play_map_ambience(7)
    if not storm_enemies:
        data["gold"]+=100; set_message("FIRTINA DÜELLOSUNU KAZANDIN! +100 ALTIN",3); save_data(); setup_storm_duel()
    back=pygame.Rect(20,20,130,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): save_data(); state="offline"


# ------------------------------------------------------------
# V49 EFSANEVI BOSS ARENASİ
# ------------------------------------------------------------
boss_data=None
def setup_boss_arena():
    global boss_data
    boss_data={"x":W*.68,"y":H*.48,"hp":900,"maxhp":900,"level":1,"reward":250,"cool":0}

def boss_arena(touches,click,keys):
    global state,boss_data
    draw_map(8)
    if boss_data is None: setup_boss_arena()
    dx,dy=movement(touches,keys,7)
    p=data.setdefault("v49_boss_player",[W*.30,H*.58]); p[0]=clamp(p[0]+dx,35,W-35); p[1]=clamp(p[1]+dy,110,H-35)
    b=boss_data
    # boss playeri takip eder
    vx=p[0]-b["x"]; vy=p[1]-b["y"]; d=max(1,math.hypot(vx,vy))
    if d>72: b["x"]+=vx/d*2.0; b["y"]+=vy/d*2.0
    atk=pygame.Rect(W-185,H-115,155,65); button(atk,"BOSS'A VUR",RED)
    if click and touched(touches,atk) and d<125:
        b["hp"]-=int(data.get("damage",25)*2.2); play_sfx("hit"); set_message("EFSANEVI DARBE!",.7)
    draw_warrior(p[0],p[1],char_index,1.05,False)
    # büyük boss çizimi
    pygame.draw.circle(screen,(65,25,25),(int(b["x"]),int(b["y"]-45)),38)
    pygame.draw.rect(screen,(80,45,35),(int(b["x"]-38),int(b["y"]-10),76,82),border_radius=18)
    pygame.draw.polygon(screen,(220,70,40),[(b["x"]-32,b["y"]-75),(b["x"]-8,b["y"]-120),(b["x"]+2,b["y"]-70)])
    pygame.draw.polygon(screen,(220,70,40),[(b["x"]+20,b["y"]-75),(b["x"]+44,b["y"]-120),(b["x"]+34,b["y"]-70)])
    hpbar(b["x"],b["y"]-145,b["hp"],b["maxhp"],140); text("EJDERHA BOSS",FS,GOLD,b["x"],b["y"]-170)
    draw_controls()
    back=pygame.Rect(20,20,130,48); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="offline"
    if b["hp"]<=0:
        data["gold"]+=b["reward"]; save_data(); set_message(f"BOSS YENILDI! +{b['reward']} ALTIN",4); setup_boss_arena()


# ------------------------------------------------------------
# V49 SAKLAMBAÇ • DEVASA ZOMBI AVI
# ------------------------------------------------------------
hide_data=None
def setup_hide_seek(kind="offline"):
    global hide_data
    hide_data={"kind":kind,"start":pygame.time.get_ticks(),"duration":210.0,"player":[W*.18,H*.78],"infected":False,"alive":True,"winner":"","bots":[],"obstacles":[]}
    # 5 bot + 1 zombi = toplam 6 oyuncu
    for i in range(5):
        hide_data["bots"].append({"x":random.randint(90,W-90),"y":random.randint(130,H-90),"infected":i==0,"alive":True,"name":f"OYUNCU {i+2}","dir":random.uniform(0,6.28)})
    # devasa dünya hissi: evler, ağaç kümeleri, kayalar, sandıklar, kule
    for i in range(34):
        hide_data["obstacles"].append((random.randint(70,W-70),random.randint(120,H-70),random.randint(18,42)))

def draw_hide_map(d):
    screen.fill((34,92,58))
    # yollar, dere ve köy alanları
    pygame.draw.rect(screen,(125,105,65),(0,H*.44,W,H*.12))
    pygame.draw.rect(screen,(55,135,175),(W*.48,90,W*.10,H-90))
    pygame.draw.circle(screen,(235,210,115),(W*.18,H*.20),72)
    pygame.draw.rect(screen,(105,62,35),(W*.12,H*.12,110,80),border_radius=12)
    pygame.draw.polygon(screen,(165,50,42),[(W*.09,H*.12),(W*.175,H*.03),(W*.26,H*.12)])
    for x,y,r in d["obstacles"]:
        pygame.draw.circle(screen,(25,70,35),(x,y),r)
        pygame.draw.circle(screen,(55,125,58),(x-r//3,y-r//3),max(5,r-8))
    # saklanma noktaları
    for x,y in [(W*.15,H*.72),(W*.78,H*.22),(W*.82,H*.76),(W*.35,H*.28)]:
        pygame.draw.rect(screen,(85,55,35),(x-24,y-20,48,40),border_radius=6)
        pygame.draw.polygon(screen,(150,48,38),[(x-30,y-20),(x,y-48),(x+30,y-20)])

def hide_seek(touches,click,keys):
    global state
    if hide_data is None: setup_hide_seek("offline")
    d=hide_data; draw_hide_map(d)
    elapsed=(pygame.time.get_ticks()-d["start"])/1000.0
    left=max(0,int(d["duration"]-elapsed))
    text(f"SAKLAMBAÇ • {left} SN",FT,GOLD,W//2,38)
    text("6 OYUNCU • 1 ZOMBI • SON KALAN KAZANIR",FS,WHITE,W//2,78)
    dx,dy=movement(touches,keys,7.2 if not d["infected"] else 6.5)
    d["player"][0]=clamp(d["player"][0]+dx,28,W-28); d["player"][1]=clamp(d["player"][1]+dy,110,H-28)
    # zombi oyuncuyu takip eder; diğerleri saklanır/kaçar
    for b in d["bots"]:
        if not b["alive"]: continue
        tx,ty=d["player"]
        if b["infected"]:
            vx,vy=tx-b["x"],ty-b["y"]; dist=max(1,(vx*vx+vy*vy)**.5); b["x"]+=vx/dist*1.8; b["y"]+=vy/dist*1.8
            if dist<34 and not d["infected"]:
                d["infected"]=True; set_message("ZOMBI SENI BULDU! SIMDI DIGERLERINI AVLA!",1.2); play_sfx("thud")
        else:
            vx,vy=b["x"]-tx,b["y"]-ty; dist=max(1,(vx*vx+vy*vy)**.5)
            if d["infected"] and dist<220: b["x"]+=vx/dist*2.0; b["y"]+=vy/dist*2.0
            else:
                b["dir"]+=random.uniform(-.08,.08); b["x"]+=math.cos(b["dir"])*.8; b["y"]+=math.sin(b["dir"])*.8
        b["x"]=clamp(b["x"],28,W-28); b["y"]=clamp(b["y"],110,H-28)
        draw_warrior(b["x"],b["y"],0,.72,b["infected"])
    # oyuncu zombi ise yakındaki saklananları enfekte et
    if d["infected"]:
        infect_btn=pygame.Rect(W-210,H-110,175,62); button(infect_btn,"YAKALA",RED)
        if click and touched(touches,infect_btn):
            for b in d["bots"]:
                if b["alive"] and not b["infected"] and math.hypot(b["x"]-d["player"][0],b["y"]-d["player"][1])<75:
                    b["infected"]=True; set_message(b["name"]+" ZOMBI OLDU!",.8); play_sfx("thud"); break
    draw_warrior(d["player"][0],d["player"][1],char_index,1.0,d["infected"])
    draw_controls()
    alive=sum(1 for b in d["bots"] if b["alive"] and not b["infected"])+(0 if d["infected"] else 1)
    text(f"KALAN INSAN: {alive}",FS,GREEN,W//2,108)
    if alive==0 or left<=0:
        if not d["infected"] and alive==1: data["gold"]+=180; set_message("SAKLAMBAÇ USTASI! +180 ALTIN",2)
        else: set_message("TUR BITTI!",1.2)
        save_data(); state="offline" if d["kind"]=="offline" else "multiplayer"
    back=pygame.Rect(18,18,120,46); button(back,"GERI",GRAY,True)
    if click and touched(touches,back): state="offline" if d["kind"]=="offline" else "multiplayer"



# ============================================================
# SPARTA ARENA - EXECUTED BEFORE MAIN LOOP
# ============================================================
_v56_warrior_base=draw_warrior
_v56_conquest_base=draw_conquest_world
_v56_sea_base=draw_sea_world

def developer_settings_menu(touches,click):
    global state
    draw_menu_background()
    text("GELISTIRICI OZELLIKLERI",FT,GOLD,W//2,H*.10)
    dev=data.setdefault("developer",{"infinite_gold":False,"unlock_all":False,"test_mode":False})
    a=pygame.Rect(W//2-240,int(H*.24),480,62)
    b=pygame.Rect(W//2-240,int(H*.34),480,62)
    c=pygame.Rect(W//2-240,int(H*.44),480,62)
    button(a,"SONSUZ ALTIN: "+("ACIK" if dev.get("infinite_gold") else "KAPALI"),GREEN if dev.get("infinite_gold") else GRAY)
    button(b,"TUM KILITLER: "+("ACIK" if dev.get("unlock_all") else "KAPALI"),GREEN if dev.get("unlock_all") else GRAY)
    button(c,"TEST MODU: "+("ACIK" if dev.get("test_mode") else "KAPALI"),GREEN if dev.get("test_mode") else GRAY)
    text("GELISTIRICI TEST AYARLARI",FS,SILVER,W//2,H*.58)
    back=pygame.Rect(W//2-220,int(H*.68),440,60); button(back,"AYARLARA DON",GRAY)
    if click:
        if touched(touches,a): dev["infinite_gold"]=not dev.get("infinite_gold"); save_data()
        elif touched(touches,b): dev["unlock_all"]=not dev.get("unlock_all"); save_data()
        elif touched(touches,c): dev["test_mode"]=not dev.get("test_mode"); save_data()
        elif touched(touches,back): state="settings"

def draw_warrior(x,y,ch_index,scale=1.0,enemy=False,attacking=False,horse=False):
    _v56_warrior_base(x,y,ch_index,scale,enemy,attacking,horse)
    ss=max(.45,scale); idx=ch_index%len(CHARACTERS)
    # Warband-style layered cloak and armor
    cape=CHARACTERS[idx].get("cape",(70,55,45))
    pygame.draw.polygon(screen,cape,[(x-int(17*ss),y),(x-int(28*ss),y+int(27*ss)),(x-int(8*ss),y+int(33*ss)),(x+int(2*ss),y+int(7*ss))])
    for z in (-1,0,1):
        pygame.draw.line(screen,(225,205,160),(x-int(12*ss),y+int((z*5+2)*ss)),(x+int(12*ss),y+int((z*5+2)*ss)),max(1,int(2*ss)))
    # Different weapon families give characters distinct silhouettes
    if idx%4==0:
        pygame.draw.line(screen,(110,70,35),(x+18*ss,y+23*ss),(x+38*ss,y-44*ss),max(2,int(3*ss)))
        pygame.draw.polygon(screen,(225,230,235),[(x+38*ss,y-44*ss),(x+31*ss,y-31*ss),(x+41*ss,y-34*ss)])
    elif idx%4==1:
        pygame.draw.line(screen,(85,55,32),(x+18*ss,y+20*ss),(x+39*ss,y-29*ss),max(2,int(4*ss)))
        pygame.draw.polygon(screen,(175,180,190),[(x+34*ss,y-29*ss),(x+49*ss,y-21*ss),(x+39*ss,y-9*ss)])
    elif idx%4==2:
        pygame.draw.arc(screen,(150,95,45),(int(x+10*ss),int(y-20*ss),int(34*ss),int(48*ss)),-1.4,1.4,max(2,int(3*ss)))
    else:
        for q in (-1,1): pygame.draw.line(screen,(225,230,238),(x+q*11*ss,y+17*ss),(x+q*28*ss,y-13*ss),max(2,int(3*ss)))
    pygame.draw.arc(screen,(210,175,90),(int(x-15*ss),int(y-48*ss),int(30*ss),int(27*ss)),3.2,6.15,max(2,int(3*ss)))
    if attacking: pygame.draw.arc(screen,(255,220,120),(int(x-42*ss),int(y-40*ss),int(84*ss),int(84*ss)),-.8,.8,max(1,int(2*ss)))

def draw_conquest_world():
    _v56_conquest_base()
    cam=world_camera_x
    for k in range(unlocked_continents):
        left=k*W-cam
        pts=[(left+70,H*.72),(left+W*.28,H*.58),(left+W*.53,H*.68),(left+W*.82,H*.48)]
        ip=[(int(x),int(y)) for x,y in pts]
        pygame.draw.lines(screen,(160,120,75),False,ip,8)
        pygame.draw.lines(screen,(220,185,120),False,ip,2)
        pygame.draw.line(screen,(65,150,190),(int(left+W*.12),125),(int(left+W*.70),H-80),7)
        for i in range(3):
            vx=int(left+W*(.18+i*.22)); vy=int(H*(.40+(i%2)*.18))
            pygame.draw.rect(screen,(120,82,48),(vx-12,vy-8,24,18))
            pygame.draw.polygon(screen,(135,48,35),[(vx-17,vy-8),(vx,vy-25),(vx+17,vy-8)])
            text("KOY",FS,(245,220,160),vx,vy+27)

def draw_sea_world(d=None,cam=0):
    _v56_sea_base(d,cam)
    for row in range(5):
        yy=int(H*.18+row*H*.15)
        for i in range(8):
            xx=(i*173+row*61+int(cam*.15))%W
            pygame.draw.arc(screen,(155,220,235),(xx-28,yy-8,56,18),3.25,6.1,2)



# ============================================================
# SPARTA ARENA - SPARTA WORLD RELEASE UPDATE
# Language, cinematic intro, optimized drawing and walkable cities.
# ============================================================
LANG={"TR":{"play":"OYNA","offline":"OFFLINE OYNA","multi":"MULTIPLAYER","settings":"AYARLAR","back":"GERI"},
      "EN":{"play":"PLAY","offline":"OFFLINE PLAY","multi":"MULTIPLAYER","settings":"SETTINGS","back":"BACK"}}
language=data.setdefault("language","TR")
boot_started=pygame.time.get_ticks()
boot_phase="language"
city_walk_x=0.0
city_walk_y=0.0
city_walk_near=None

def draw_3d_card(rect,title,subtitle,color):
    shadow=rect.move(8,10)
    pygame.draw.rect(screen,(8,10,14),shadow,border_radius=18)
    pygame.draw.rect(screen,color,rect,border_radius=18)
    pygame.draw.rect(screen,(255,235,175),rect,3,border_radius=18)
    # perspective highlight
    pygame.draw.polygon(screen,(min(255,color[0]+35),min(255,color[1]+35),min(255,color[2]+35)),
                        [(rect.x+12,rect.y+12),(rect.right-12,rect.y+12),(rect.right-28,rect.y+24),(rect.x+28,rect.y+24)])
    text(title,FM,WHITE,rect.centerx,rect.y+rect.height*.42)
    text(subtitle,FS,(235,225,200),rect.centerx,rect.y+rect.height*.70)

def language_screen(touches,click):
    global state,language,boot_phase
    draw_menu_background()
    text("SPARTA ARENA",FT,GOLD,W//2,H*.20)
    text("DIL / LANGUAGE",FM,WHITE,W//2,H*.31)
    tr=pygame.Rect(W//2-250,int(H*.43),230,100)
    en=pygame.Rect(W//2+20,int(H*.43),230,100)
    draw_3d_card(tr,"TURKCE","TURKISH",(42,105,150))
    draw_3d_card(en,"ENGLISH","ENGLISH",(90,70,145))
    if click and touched(touches,tr):
        language="TR"; data["language"]="TR"; save_data(); boot_phase="world"; state="sparta_world_intro"
    elif click and touched(touches,en):
        language="EN"; data["language"]="EN"; save_data(); boot_phase="world"; state="sparta_world_intro"

def sparta_world_intro(touches,click):
    global state
    screen.fill((4,8,18))
    t=(pygame.time.get_ticks()-boot_started)%8000/8000
    # rotating-style planet made from layered arcs: cheap enough for mobile.
    cx,cy=W//2,H//2
    r=int(min(W,H)*(.20+.025*math.sin(t*math.tau)))
    for rr in range(r,10,-8):
        shade=int(35+120*(rr/r))
        pygame.draw.circle(screen,(10,shade//2,shade),(cx,cy),rr)
    pygame.draw.circle(screen,(70,125,160),(cx,cy),r,3)
    # continents
    pygame.draw.ellipse(screen,(70,130,72),(cx-r*.65,cy-r*.30,r*.70,r*.38))
    pygame.draw.ellipse(screen,(85,145,70),(cx-r*.10,cy-r*.05,r*.62,r*.42))
    text("SPARTA",FT,GOLD,cx,cy-r-70)
    text("WORLD",FT,WHITE,cx,cy+r+60)
    text("A WORLD OF WARRIORS",FS,SILVER,cx,H*.82)
    if t>.62 or click:
        state="menu"

def city_walk_init():
    global city_walk_x,city_walk_y,city_walk_near
    city_walk_x=W*.50; city_walk_y=H*.62
    city_walk_near=min(cities,key=lambda c:math.hypot(world_player[0]-c["x"],world_player[1]-c["y"]))

def city_walk_screen(touches,click,keys):
    global state,city_walk_x,city_walk_y
    # Perspective-like street with buildings and a walkable player.
    screen.fill((112,145,175))
    horizon=int(H*.30)
    pygame.draw.rect(screen,(92,105,108),(0,horizon,W,H-horizon))
    # converging road
    pygame.draw.polygon(screen,(118,104,88),[(W*.42,horizon),(W*.58,horizon),(W,H),(0,H)])
    for side in (0,1):
        for i in range(6):
            depth=i/6
            yy=int(horizon+depth*depth*(H-horizon))
            bw=int(110+depth*170); bh=int(70+depth*180)
            x=int((W*.04+i*31) if side==0 else (W-bw-(W*.04+i*31)))
            pygame.draw.rect(screen,(88+int(depth*35),62+int(depth*25),48), (x,yy-bh,bw,bh))
            pygame.draw.polygon(screen,(70,42,32),[(x-10,yy-bh),(x+bw//2,yy-bh-35),(x+bw+10,yy-bh)])
    # landmarks
    labels=[("PAZAR",W*.20,H*.48),( "HAN",W*.78,H*.52),("GARNIZON",W*.22,H*.73),("KALE",W*.76,H*.76)]
    for name,x,y in labels:
        text(name,FS,GOLD,int(x),int(y))
    speed=5.5
    dx=dy=0
    if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx=-speed
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx=speed
    if keys[pygame.K_UP] or keys[pygame.K_w]: dy=-speed
    if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy=speed
    city_walk_x=clamp(city_walk_x+dx,35,W-35); city_walk_y=clamp(city_walk_y+dy,horizon+35,H-55)
    draw_warrior(city_walk_x,city_walk_y,data.get("selected",0),1.15)
    text(f"{city_walk_near['name']} - SEHIRDE SERBEST DOLAS",FS,WHITE,W//2,45)
    text("YAKINLAS: PAZAR / HAN / GARNIZON / KALE",FS,SILVER,W//2,75)
    back=pygame.Rect(20,20,140,48); button(back,"MEYDANA DON",GRAY,True)
    if click and touched(touches,back): state="city"
    # proximity interaction zones
    if city_walk_x<W*.34 and city_walk_y<H*.58 and click: state="city_shop"
    elif city_walk_x>W*.66 and city_walk_y<H*.62 and click: state="city_tavern"
    elif city_walk_x<W*.36 and city_walk_y>H*.65 and click: state="city_barracks"
    elif city_walk_x>W*.64 and city_walk_y>H*.65 and click: state="city_castle"

# Server-oriented multiplayer client configuration.
# A production build must point this client at a real HTTPS/WebSocket backend.
SERVER_CONFIG={"mode":"server","endpoint":"https://YOUR-SPARTA-SERVER.example","region":"EU/TR"}

def server_multiplayer_screen(touches,click):
    global state
    draw_menu_background()
    text("SERVER MULTIPLAYER",FT,GOLD,W//2,H*.12)
    text("ODALAR INTERNET UZERINDEN SUNUCU TARAFINDAN YONETILIR",FS,WHITE,W//2,H*.22)
    panel(pygame.Rect(W//2-280,int(H*.30),560,150),(22,30,45),GOLD,18)
    text("SUNUCU BOLGESI: "+SERVER_CONFIG["region"],FS,GOLD,W//2,H*.37)
    text("PRODUCTION BACKEND GEREKLI",FS,SILVER,W//2,H*.45)
    text("ODA LISTESI / MATCHMAKING / HESAP SENKRONIZASYONU",FS,SILVER,W//2,H*.52)
    back=pygame.Rect(W//2-220,int(H*.65),440,60); button(back,"GERI",GRAY)
    if click and touched(touches,back): state="menu"

# SPARTA ARENA
# ------------------------------------------------------------
# MAIN LOOP
# ------------------------------------------------------------

setup_conquest(False)

while True:
    touches,click,keys=get_input()
    screen.fill(BLACK)

    if state=="language": language_screen(touches,click)
    elif state=="sparta_world_intro": sparta_world_intro(touches,click)
    elif state=="menu": main_menu(touches,click)
    elif state=="settings": settings_menu(touches,click)
    elif state=="developer_settings": developer_settings_menu(touches,click)
    elif state=="about": about_menu(touches,click)
    elif state=="achievements": achievements_menu(touches,click)
    elif state=="offline": offline_menu(touches,click)
    elif state=="hill_char": hill_char(touches,click)
    elif state=="hill": hill(touches,click,keys)
    elif state=="hide_seek": hide_seek(touches,click,keys)
    elif state=="storm_duel": storm_duel(touches,click,keys)
    elif state=="boss_arena": boss_arena(touches,click,keys)
    elif state=="sea_hub": sea_hub(touches,click)
    elif state=="sea_world": sea_world(touches,click,keys)
    elif state=="sea_battle": sea_battle(touches,click,keys)
    elif state=="difficulty_select": difficulty_select(touches,click)
    elif state=="castle_difficulty": castle_difficulty(touches,click)
    elif state=="castle_hub": castle_hub(touches,click)
    elif state=="castle_battle": castle_battle(touches,click,keys)
    elif state=="map_select": map_select(touches,click)
    elif state=="game_char": game_char_select(touches,click)
    elif state=="mode_start": mode_start_screen(touches,click)
    elif state=="bear_start": bear_start_screen(touches,click)
    elif state=="bear_char": bear_char_select(touches,click)
    elif state=="mode_game": mode_game(touches,click,keys)
    elif state=="bear": bear_mode(touches,click,keys)
    elif state=="bear_shop": shop_screen(touches,click,"bear")
    elif state=="mode_shop": shop_screen(touches,click,"mode_game")
    elif state=="caravan_follower_shop": caravan_follower_shop(touches,click)
    elif state=="caravan_upgrade_shop": caravan_upgrade_shop(touches,click)
    elif state=="growth_shop": shop_screen(touches,click,"growth")
    elif state=="arena_shop": shop_screen(touches,click,"arena")
    elif state=="race_shop": shop_screen(touches,click,"race_hub")
    elif state=="save_game": save_game_screen(touches,click)
    elif state=="conquest_class": conquest_class_screen(touches,click)
    elif state=="conquest_start": conquest_start_screen(touches,click)
    elif state=="conquest": conquest_screen(touches,click,keys)
    elif state=="nation": nation_screen(touches,click)
    elif state=="city": city_screen(touches,click)
    elif state=="city_walk": city_walk_screen(touches,click,keys)
    elif state=="city_tavern": city_tavern_screen(touches,click)
    elif state=="city_barracks": city_barracks_screen(touches,click)
    elif state=="city_castle": city_castle_screen(touches,click)
    elif state=="city_info": city_info_screen(touches,click)
    elif state=="city_shop": shop_screen(touches,click,"city")
    elif state=="siege": siege_screen(touches,click,keys)
    elif state=="world_battle": world_battle_screen(touches,click,keys)
    elif state=="trade": trade_screen(touches,click)
    elif state=="server_multiplayer": server_multiplayer_screen(touches,click)
    elif state=="multiplayer": multiplayer_screen(touches,click)
    elif state=="multi_ip": multi_ip_screen(touches,click)
    elif state=="multi_wait": multi_wait_screen(touches,click)
    elif state=="multi_fight": multi_fight_screen(touches,click,keys)
    elif state=="hot_potato": hot_potato_screen(touches,click,keys)
    elif state=="growth": growth_screen(touches,click)
    elif state=="arena": arena_screen(touches,click)
    elif state=="race_hub": race_hub(touches,click)
    elif state=="race": race_screen(touches,click,keys)

    if message_timer>0:
        message_timer-=1/FPS
        # Kucuk, ustte ve hizli kaybolan bildirim: oyunun gorusunu kapatmaz.
        bw=min(int(W*.62),max(260,int(len(str(message))*14)+70))
        bh=54
        panel(pygame.Rect(W//2-bw//2,92,bw,bh),(25,30,38),GOLD,14)
        text(message,FS,GOLD,W//2,119)

    pygame.display.flip()
    clock.tick(FPS)
