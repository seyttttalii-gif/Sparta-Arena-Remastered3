#!/usr/bin/env bash
set -e
echo "SPARTA ARENA Android debug APK build"
buildozer android debug
echo "APK çıktısı bin/ klasöründe olacak."
