# SPARTA ARENA REMASTERED — Windows 3D Migration Build

**Yapımcı:** SPARTA WORLD  
**Hedef:** Windows bilgisayar, 16:9 yatay  
**Motor:** Godot 4.7.2 Standard / GDScript

## Bu paket nedir?

Bu, Android/Pygame V57 kaynaklarını koruyan ve yeni Windows Godot projesine ilk geniş aktarımı yapan **oynanabilirlik odaklı geçiş sürümüdür**. Eski proje `legacy_v57/` altında tutulur; orijinal yüklenen ZIP de `legacy_v57/ORIGINAL_ANDROID_SOURCE_ARCHIVE.zip` olarak korunur.

Bu paketteki ilk aktarım şunları içerir:

- V57 listesinden 20 karakterin adı ve temel istatistikleri; Cengiz Han'ın 5 ve Fatih Sultan Mehmet'in 7 klasik zafer koşuluyla açılması.
- Dokuz V57 haritasının adı ve 3D arena için renk/atmosfer teması.
- V57 çevrim dışı menüsünde bulunan on modun kataloğu; ortak 3D hareket, düşman dalgaları, sağlık, saldırı, zafer/yenilgi döngüsü ve moda göre farklılaştırılmış ilk hedefler.
- Karakter/harita seçimi, kalıcı kayıt, ses ve zorluk ayarları, yeniden atanabilir hareket/saldırı/iksir tuşları ve tam ekran seçeneği.
- Mağaza, iksirler, ekipman geliştirmeleri, günlük ödül, başarımlar ve geliştirici test anahtarları.
- 72 şehir adıyla temel dünya fethi/şehir ilerlemesi ve kayıtlı deniz balıkçılığı/keşif/olta/gemi sistemi.
- İlk çalıştırmada bir kez oynayan 13 saniyelik sinematik kamera açılışı, ATLA ve menüden yeniden oynatma.
- Keskin UI click ve sword-swish örnekleri yerine düşük seviyeli, özgün yumuşak dokunuş ve tok darbe efektleri.

**Metehan**, verilen V57 `CHARACTERS` listesinde yer almıyor; kullanıcı isteğiyle Remastered kataloğuna yeni karakter olarak eklendi. Veri kataloğunda bu ayrım işaretlidir.

## Önemli: Henüz tamamlanmamış işler

Bu bir tam V57 eşdeğeri veya son kalite sürümü değildir. V57 kaynakları 2D Pygame mantığıyla yazılmıştır ve Godot'a otomatik olarak gerçek 3D dönüştürülemez. Yeni karakter modelleri şimdilik prosedürel/geometriktir. Özgün görev kuralları, şehir savaşları ve kuşatmaların bütün yapay zekâsı, deniz savaşı ve gemi hareketleri, her haritanın ayrı çevre modeli, sinematik yüz/iskelet animasyonları ve gerçek çevrim içi multiplayer henüz birebir taşınmadı. `MIGRATION_STATUS.md` ve `data/v57_feature_inventory.json` hangi bölümün taşındığını ve neyin kaldığını açıkça listeler.

Yüklenen Android arşivi başlangıç JSON kayıtlarını içeriyordu; telefondaki kişisel kullanıcı kaydı bu arşivde bulunmadığından ona ait ilerleme otomatik aktarılamaz.

## Windows'ta açma

1. Godot 4.7.2 Standard sürümünü resmi indirme sayfasından indirip ZIP'ini çıkar: https://godotengine.org/download/windows/
2. Godot'u aç, **Import** seç ve bu klasördeki `project.godot` dosyasını göster.
3. Proje açıldıktan sonra **F6/F5** ile ana sahneyi çalıştır. İlk açılış 13 saniyelik tanıtımdır; ATLA ile geçilebilir.
4. Ana menüden mod, karakter, harita, ayar, mağaza, dünya fethi ve deniz menülerini deneyebilirsin.

## GitHub Actions ile EXE üretme

Bu projenin içine konan `.github/workflows/windows-build.yml`, proje kökünde bulunduğunda doğrudan Godot projesini derlemek içindir. GitHub deposuna proje dosyaları yerine yalnızca ZIP yüklenmişse, deponun köküne ayrıca indirdiğin `windows-build.yml` dosyasının içeriğini `.github/workflows/windows-build.yml` olarak ekle; bu ayrı iş akışı ZIP'i açıp içindeki `project.godot` konumundan derler.

Windows `.exe` ve gerçek Godot çalışma zamanı bu hazırlama ortamında çalıştırılarak test edilemedi. İlk Actions sonucu motorun GDScript hatalarını, kaynak içe aktarmayı ve export işlemini doğrulamalı. Yeşil derleme yalnızca EXE'nin üretildiğini doğrular; tüm modların son kalite ve birebir eşdeğerliğini değil.

## Dizin yapısı

- `project.godot`, `scenes/`, `scripts/`: yeni Godot projesi
- `assets/audio/`: özgün üretilmiş düşük seviyeli sesler
- `data/`: karakter, harita, mod, şehir ve aktarım envanteri
- `.github/workflows/`: proje kökünden derleme iş akışı
- `legacy_v57/`: korunan V57 Python kaynakları, başlangıç JSON'ları ve orijinal ZIP yedeği
- `MIGRATION_STATUS.md`: aktarım ve test durumu
