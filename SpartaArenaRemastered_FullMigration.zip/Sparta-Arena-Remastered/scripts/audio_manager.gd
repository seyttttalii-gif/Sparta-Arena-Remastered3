extends Node

# Gentle original audio assets. There are deliberately no sharp UI clicks or sword-swish sounds.
const INTRO_SCORE: AudioStreamWAV = preload("res://assets/audio/intro_score.wav")
const MENU_AMBIENCE: AudioStreamWAV = preload("res://assets/audio/menu_ambience.wav")
const UI_TAP: AudioStreamWAV = preload("res://assets/audio/ui_soft_tap.wav")
const MUTED_IMPACT: AudioStreamWAV = preload("res://assets/audio/muted_metal_impact.wav")

var music_volume: float = 0.58
var sfx_volume: float = 0.34
var sfx_enabled: bool = true
var _music_player: AudioStreamPlayer
var _sfx_players: Array[AudioStreamPlayer] = []
var _next_sfx_player: int = 0

func _ready() -> void:
    _music_player = AudioStreamPlayer.new()
    _music_player.name = "MusicPlayer"
    add_child(_music_player)
    _music_player.finished.connect(_on_music_finished)

    for i in range(4):
        var player := AudioStreamPlayer.new()
        player.name = "SfxPlayer%d" % i
        add_child(player)
        _sfx_players.append(player)

func set_music_volume(value: float) -> void:
    music_volume = clampf(value, 0.0, 1.0)
    if is_instance_valid(_music_player):
        _music_player.volume_db = linear_to_db(maxf(0.001, music_volume))

func set_sfx_volume(value: float) -> void:
    sfx_volume = clampf(value, 0.0, 1.0)

func set_sfx_enabled(enabled: bool) -> void:
    sfx_enabled = enabled

func play_intro_score() -> void:
    _start_music(INTRO_SCORE, false)

func play_menu_ambience() -> void:
    _start_music(MENU_AMBIENCE, true)

func stop_music() -> void:
    if is_instance_valid(_music_player):
        _music_player.stop()

func play_ui() -> void:
    _play_sfx(UI_TAP, -2.5)

func play_muted_impact() -> void:
    _play_sfx(MUTED_IMPACT, -5.0)

func _start_music(source: AudioStreamWAV, should_loop: bool) -> void:
    if not is_instance_valid(_music_player):
        return
    _music_player.stop()
    var copied := source.duplicate() as AudioStreamWAV
    if copied == null:
        return
    if should_loop:
        copied.loop_mode = AudioStreamWAV.LOOP_FORWARD
    _music_player.stream = copied
    _music_player.volume_db = linear_to_db(maxf(0.001, music_volume))
    _music_player.play()

func _play_sfx(source: AudioStreamWAV, trim_db: float) -> void:
    if not sfx_enabled or sfx_volume <= 0.001 or _sfx_players.is_empty():
        return
    var player := _sfx_players[_next_sfx_player]
    _next_sfx_player = (_next_sfx_player + 1) % _sfx_players.size()
    player.stream = source
    # Both assets are intentionally low-amplitude, with no harsh high-frequency transient.
    player.volume_db = linear_to_db(maxf(0.001, sfx_volume * 0.55)) + trim_db
    player.play()

func _on_music_finished() -> void:
    # The intro score is one-shot; menu ambience is looped by its WAV resource setting.
    pass
