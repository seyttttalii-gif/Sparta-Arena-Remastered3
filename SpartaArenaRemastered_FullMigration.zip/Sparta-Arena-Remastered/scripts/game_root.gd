extends Node3D

# SPARTA ARENA REMASTERED
# Broad first-pass migration of V57's catalog and progression into Godot.
# Temporary procedural 3D art is used because the V57 ZIP contains no 3D model assets.

const INTRO_DURATION: float = 13.0
const GOLD := Color(0.82, 0.62, 0.29)
const PALE_GOLD := Color(0.96, 0.82, 0.55)
const TEXT_LIGHT := Color(0.89, 0.89, 0.86)
const MUTED_TEXT := Color(0.68, 0.70, 0.72)
const CONFIG_PATH := "user://sparta_remastered.cfg"
const SAVE_PATH := "user://sparta_remastered_save.json"
const CHARACTER_FILE := "res://data/characters.json"
const MAP_FILE := "res://data/maps.json"
const MODE_FILE := "res://data/game_modes.json"
const CITY_FILE := "res://data/world_city_pools.json"
const ITEMS_PER_PAGE := 5

var _characters: Array = []
var _maps: Array = []
var _modes: Array = []
var _city_pools: Array = []
var _save_data: Dictionary = {}
var _config := ConfigFile.new()
var _awaiting_rebind: String = ""

var _camera: Camera3D
var _world_environment: WorldEnvironment
var _arena_floor: MeshInstance3D
var _map_decor: Node3D
var _screen_mode: String = "boot"
var _intro_time: float = 0.0
var _intro_seen: bool = false
var _music_volume: float = 0.44
var _sfx_volume: float = 0.28
var _sfx_enabled: bool = true
var _difficulty: String = "ORTA"

var _ui_layer: CanvasLayer
var _intro_layer: Control
var _menu_layer: Control
var _intro_title: Label
var _intro_subtitle: Label
var _intro_progress: ProgressBar
var _skip_button: Button
var _menu_panel: PanelContainer
var _page_title: Label
var _page_subtitle: Label
var _page_body: Label
var _menu_buttons: VBoxContainer
var _menu_scroll: ScrollContainer
var _dim_layer: ColorRect
var _menu_warriors: Array[Node3D] = []

var _player: Node3D
var _enemies: Array[Dictionary] = []
var _combat_health: float = 100.0
var _combat_max_health: float = 100.0
var _attack_was_down: bool = false
var _potion_was_down: bool = false
var _attack_cooldown: float = 0.0
var _enemy_hit_cooldown: float = 0.0
var _wave_delay: float = 0.0
var _wave_transition_pending: bool = false
var _combat_ended: bool = false
var _wave: int = 0
var _kills_this_run: int = 0
var _mode_time_left: float = 0.0
var _hill_progress: float = 0.0
var _hud_tick: float = 0.0
var _selected_mode_key: String = "classic"
var _last_result_text: String = ""

func _ready() -> void:
    randomize()
    DisplayServer.window_set_title("SPARTA ARENA REMASTERED")
    _load_catalogs()
    _load_preferences()
    _load_save_data()
    _build_3d_world()
    _build_ui()
    _apply_map_theme(int(_save_data.get("selected_map", 0)))
    if _intro_seen:
        _show_menu()
        AudioManager.play_menu_ambience()
    else:
        _begin_intro()

func _process(delta: float) -> void:
    if _screen_mode == "intro":
        _intro_time += delta
        _update_intro_camera()
        if is_instance_valid(_intro_progress):
            _intro_progress.value = clampf(_intro_time / INTRO_DURATION * 100.0, 0.0, 100.0)
        if is_instance_valid(_intro_title):
            _intro_title.modulate.a = clampf(_intro_time / 1.4, 0.0, 1.0)
            _intro_subtitle.modulate.a = clampf((_intro_time - 0.7) / 1.4, 0.0, 1.0)
        if _intro_time >= INTRO_DURATION:
            _finish_intro()
    elif _screen_mode == "menu":
        _update_menu_camera(delta)
    elif _screen_mode == "combat":
        _update_combat(delta)

func _unhandled_input(event: InputEvent) -> void:
    if _awaiting_rebind != "" and event is InputEventKey and event.pressed and not event.echo:
        var key_event := event as InputEventKey
        if key_event.keycode == KEY_ESCAPE:
            _awaiting_rebind = ""
            _show_settings()
            get_viewport().set_input_as_handled()
            return
        var code := int(key_event.physical_keycode if key_event.physical_keycode != 0 else key_event.keycode)
        var binds: Dictionary = _save_data.get("keybinds", {})
        binds[_awaiting_rebind] = code
        _save_data["keybinds"] = binds
        _awaiting_rebind = ""
        _save_game()
        _show_settings()
        get_viewport().set_input_as_handled()
        return
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        if _screen_mode == "combat":
            _show_pause_menu()
            get_viewport().set_input_as_handled()
        elif _screen_mode == "paused":
            _resume_combat()
            get_viewport().set_input_as_handled()

func _load_catalogs() -> void:
    _characters = _read_json_array(CHARACTER_FILE)
    _maps = _read_json_array(MAP_FILE)
    _modes = _read_json_array(MODE_FILE)
    _city_pools = _read_json_array(CITY_FILE)
    if _characters.is_empty():
        _characters = [{"name":"Spartalı", "speed":7.0, "attack":8, "defense":5, "hp_bonus":0, "cape":[0.7,0.15,0.1], "armor":[0.6,0.4,0.2]}]
    if _maps.is_empty():
        _maps = [{"name":"Antik Roma Arenası", "floor":[0.36,0.29,0.20], "sky":[0.012,0.018,0.032], "accent":[0.76,0.50,0.20]}]
    if _modes.is_empty():
        _modes = [{"key":"classic", "name":"Klasik Arena", "description":"Dalga tabanlı arena mücadelesi."}]

func _read_json_array(path: String) -> Array:
    if not FileAccess.file_exists(path):
        push_warning("Veri dosyası bulunamadı: " + path)
        return []
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
    if parsed is Array:
        return parsed
    push_warning("JSON listesi okunamadı: " + path)
    return []

func _default_save_data() -> Dictionary:
    return {
        "gold": 500,
        "classic_wins": 0,
        "total_games": 0,
        "total_kills": 0,
        "selected_character": 1,
        "selected_map": 0,
        "classic_round_limit": 30,
        "potions": 2,
        "full_potions": 0,
        "damage_bonus": 0,
        "defense_bonus": 0,
        "sword_level": 0,
        "armor_level": 0,
        "captured_cities": [],
        "conquest_continent": 0,
        "troops": 20,
        "daily_reward_date": "",
        "achievements": {},
        "settings": {"music_volume":0.44, "sfx_volume":0.28, "sfx_enabled":true, "difficulty":"ORTA", "fullscreen":false, "control_mode":"keyboard_mouse"},
        "keybinds": {"move_forward":KEY_W, "move_back":KEY_S, "move_left":KEY_A, "move_right":KEY_D, "attack":KEY_SPACE, "potion":KEY_H},
        "sea": {"gold":300, "ships":0, "rod_level":1, "fish_caught":0, "islands_discovered":0, "map_fragments":0, "relics":0},
        "dev": {"unlock_all":false, "infinite_gold":false, "test_mode":false},
        "mode_stats": {"endless_kills":0, "bosses_defeated":0, "hill_wins":0, "sea_runs":0}
    }

func _load_save_data() -> void:
    _save_data = _default_save_data()
    if FileAccess.file_exists(SAVE_PATH):
        var parsed = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
        if parsed is Dictionary:
            for key in parsed.keys():
                if _save_data.get(key) is Dictionary and parsed[key] is Dictionary:
                    var destination: Dictionary = _save_data[key]
                    for subkey in parsed[key].keys():
                        destination[subkey] = parsed[key][subkey]
                    _save_data[key] = destination
                else:
                    _save_data[key] = parsed[key]
    _save_data["selected_character"] = clampi(int(_save_data.get("selected_character", 1)), 0, _characters.size() - 1)
    _save_data["selected_map"] = clampi(int(_save_data.get("selected_map", 0)), 0, _maps.size() - 1)
    var settings: Dictionary = _save_data.get("settings", {})
    _music_volume = clampf(float(settings.get("music_volume", 0.44)), 0.0, 1.0)
    _sfx_volume = clampf(float(settings.get("sfx_volume", 0.28)), 0.0, 1.0)
    _sfx_enabled = bool(settings.get("sfx_enabled", true))
    _difficulty = str(settings.get("difficulty", "ORTA"))
    if bool(settings.get("fullscreen", false)):
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
    AudioManager.set_music_volume(_music_volume)
    AudioManager.set_sfx_volume(_sfx_volume)
    AudioManager.set_sfx_enabled(_sfx_enabled)

func _save_game() -> void:
    _refresh_achievement_flags()
    var settings: Dictionary = _save_data.get("settings", {})
    settings["music_volume"] = _music_volume
    settings["sfx_volume"] = _sfx_volume
    settings["sfx_enabled"] = _sfx_enabled
    settings["difficulty"] = _difficulty
    _save_data["settings"] = settings
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(_save_data, "\t"))
    _save_preferences()

func _load_preferences() -> void:
    var err := _config.load(CONFIG_PATH)
    _intro_seen = false
    if err == OK:
        _intro_seen = bool(_config.get_value("progress", "intro_seen", false))
    _music_volume = float(_config.get_value("audio", "music_volume", 0.44))
    _sfx_volume = float(_config.get_value("audio", "sfx_volume", 0.28))
    _sfx_enabled = bool(_config.get_value("audio", "sfx_enabled", true))

func _save_preferences() -> void:
    _config.set_value("progress", "intro_seen", _intro_seen)
    _config.set_value("audio", "music_volume", _music_volume)
    _config.set_value("audio", "sfx_volume", _sfx_volume)
    _config.set_value("audio", "sfx_enabled", _sfx_enabled)
    _config.save(CONFIG_PATH)

func _build_3d_world() -> void:
    _world_environment = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.012, 0.018, 0.032)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.38, 0.42, 0.54)
    env.ambient_light_energy = 0.62
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.26
    _world_environment.environment = env
    add_child(_world_environment)

    var sun := DirectionalLight3D.new()
    sun.name = "CinematicKeyLight"
    sun.rotation_degrees = Vector3(-43.0, -31.0, 0.0)
    sun.light_color = Color(1.0, 0.76, 0.52)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

    var fill := OmniLight3D.new()
    fill.name = "CoolArenaFill"
    fill.position = Vector3(0.0, 7.0, 7.0)
    fill.light_color = Color(0.28, 0.42, 0.78)
    fill.light_energy = 1.8
    fill.omni_range = 24.0
    add_child(fill)

    _add_cylinder(self, "ArenaFoundation", 15.0, 1.1, Vector3(0.0, -0.62, 0.0), Color(0.12, 0.105, 0.10), 64)
    _arena_floor = _add_cylinder(self, "ArenaFloor", 12.25, 0.12, Vector3(0.0, -0.025, 0.0), Color(0.36, 0.29, 0.20), 64)
    _add_torus(self, "GoldArenaRing", 12.25, 11.97, Vector3(0.0, 0.055, 0.0), GOLD)
    _add_torus(self, "InnerStoneRing", 10.75, 10.63, Vector3(0.0, 0.052, 0.0), Color(0.35, 0.28, 0.19))

    for i in range(28):
        var angle := TAU * float(i) / 28.0
        var pos := Vector3(cos(angle) * 14.1, 0.45, sin(angle) * 14.1)
        var pillar := _add_box(self, "WallButtress_%02d" % i, Vector3(0.75, 2.25, 0.75), pos, Color(0.20, 0.18, 0.17))
        pillar.rotation.y = -angle
        _add_box(self, "WallCap_%02d" % i, Vector3(0.9, 0.18, 0.9), pos + Vector3(0.0, 1.18, 0.0), Color(0.31, 0.25, 0.19))

    for i in range(13):
        var angle := TAU * float(i) / 13.0
        var radius := 28.0 + float(i % 3) * 2.6
        var mountain := MeshInstance3D.new()
        mountain.name = "HorizonMountain_%02d" % i
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.15
        mesh.bottom_radius = 5.0 + float(i % 4) * 1.1
        mesh.height = 8.5 + float(i % 5) * 2.4
        mesh.radial_segments = 6
        mountain.mesh = mesh
        mountain.position = Vector3(cos(angle) * radius, mesh.height * 0.35 - 1.5, sin(angle) * radius)
        mountain.rotation.y = angle
        mountain.material_override = _material(Color(0.045 + 0.008 * float(i % 3), 0.065, 0.105 + 0.01 * float(i % 2)))
        add_child(mountain)

    for i in range(8):
        var angle := TAU * float(i) / 8.0
        var p := Vector3(cos(angle) * 9.1, 0.0, sin(angle) * 9.1)
        _add_cylinder(self, "BrazierStand_%d" % i, 0.16, 1.1, p + Vector3(0.0, 0.55, 0.0), Color(0.24, 0.18, 0.12), 12)
        var flame_mat := _material(Color(1.0, 0.30, 0.07))
        flame_mat.emission_enabled = true
        flame_mat.emission = Color(1.0, 0.18, 0.035)
        flame_mat.emission_energy_multiplier = 2.0
        _add_sphere(self, "BrazierGlow_%d" % i, 0.19, p + Vector3(0.0, 1.22, 0.0), Color(1.0, 0.39, 0.07), flame_mat)
        var glow := OmniLight3D.new()
        glow.name = "BrazierLight_%d" % i
        glow.position = p + Vector3(0.0, 1.25, 0.0)
        glow.light_color = Color(1.0, 0.31, 0.08)
        glow.light_energy = 1.3
        glow.omni_range = 5.0
        add_child(glow)

    _map_decor = Node3D.new()
    _map_decor.name = "SelectedMapDecor"
    add_child(_map_decor)

    _camera = Camera3D.new()
    _camera.name = "CinematicCamera"
    _camera.fov = 47.0
    _camera.position = Vector3(0.0, 8.5, 31.0)
    add_child(_camera)
    _camera.current = true

    _menu_warriors.append(_make_warrior(Vector3(0.0, 0.0, 0.0), Color(0.37, 0.105, 0.08), Color(0.76, 0.21, 0.08)))
    _menu_warriors.append(_make_warrior(Vector3(-3.1, 0.0, -1.2), Color(0.19, 0.22, 0.26), Color(0.74, 0.55, 0.22)))
    _menu_warriors.append(_make_warrior(Vector3(3.1, 0.0, -1.5), Color(0.28, 0.21, 0.13), Color(0.76, 0.21, 0.08)))
    _menu_warriors[0].rotation.y = -0.12
    _menu_warriors[1].rotation.y = 0.30
    _menu_warriors[2].rotation.y = -0.26

func _build_ui() -> void:
    _ui_layer = CanvasLayer.new()
    _ui_layer.name = "UI"
    add_child(_ui_layer)

    _dim_layer = ColorRect.new()
    _dim_layer.color = Color(0.008, 0.012, 0.025, 0.54)
    _dim_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_dim_layer)

    _intro_layer = Control.new()
    _intro_layer.name = "IntroLayer"
    _intro_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_intro_layer)

    _intro_title = _make_label("SPARTA ARENA", 72, PALE_GOLD)
    _intro_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_title.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_title.offset_left = 40.0
    _intro_title.offset_right = -40.0
    _intro_title.offset_top = 105.0
    _intro_title.offset_bottom = 200.0
    _intro_layer.add_child(_intro_title)

    _intro_subtitle = _make_label("KÜLLERDEN DOĞAN EFSANE", 23, TEXT_LIGHT)
    _intro_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _intro_subtitle.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _intro_subtitle.offset_left = 40.0
    _intro_subtitle.offset_right = -40.0
    _intro_subtitle.offset_top = 203.0
    _intro_subtitle.offset_bottom = 250.0
    _intro_layer.add_child(_intro_subtitle)

    _intro_progress = ProgressBar.new()
    _intro_progress.show_percentage = false
    _intro_progress.min_value = 0.0
    _intro_progress.max_value = 100.0
    _intro_progress.value = 0.0
    _intro_progress.anchor_left = 0.12
    _intro_progress.anchor_right = 0.88
    _intro_progress.anchor_top = 1.0
    _intro_progress.anchor_bottom = 1.0
    _intro_progress.offset_top = -28.0
    _intro_progress.offset_bottom = -20.0
    _intro_layer.add_child(_intro_progress)

    var intro_caption := _make_label("13 SANİYELİK SİNEMATİK AÇILIŞ", 15, MUTED_TEXT)
    intro_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro_caption.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    intro_caption.offset_left = 30.0
    intro_caption.offset_right = -30.0
    intro_caption.offset_top = -75.0
    intro_caption.offset_bottom = -42.0
    _intro_layer.add_child(intro_caption)

    _skip_button = _make_button("ATLA  ›", 180)
    _skip_button.anchor_left = 1.0
    _skip_button.anchor_right = 1.0
    _skip_button.anchor_top = 1.0
    _skip_button.anchor_bottom = 1.0
    _skip_button.offset_left = -235.0
    _skip_button.offset_right = -48.0
    _skip_button.offset_top = -108.0
    _skip_button.offset_bottom = -50.0
    _skip_button.pressed.connect(_on_skip_pressed)
    _intro_layer.add_child(_skip_button)

    _menu_layer = Control.new()
    _menu_layer.name = "MenuLayer"
    _menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _ui_layer.add_child(_menu_layer)

    _menu_panel = PanelContainer.new()
    _menu_panel.name = "MenuPanel"
    _menu_panel.anchor_left = 0.045
    _menu_panel.anchor_right = 0.49
    _menu_panel.anchor_top = 0.045
    _menu_panel.anchor_bottom = 0.955
    var panel_style := StyleBoxFlat.new()
    panel_style.bg_color = Color(0.025, 0.032, 0.052, 0.94)
    panel_style.border_color = Color(0.51, 0.35, 0.15, 0.9)
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(10)
    panel_style.set_content_margin_all(20.0)
    _menu_panel.add_theme_stylebox_override("panel", panel_style)
    _menu_layer.add_child(_menu_panel)

    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_left", 12)
    margin.add_theme_constant_override("margin_right", 12)
    margin.add_theme_constant_override("margin_top", 10)
    margin.add_theme_constant_override("margin_bottom", 10)
    _menu_panel.add_child(margin)

    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 7)
    margin.add_child(content)

    _page_title = _make_label("SPARTA ARENA", 34, PALE_GOLD)
    content.add_child(_page_title)
    _page_subtitle = _make_label("REMASTERED • SPARTA WORLD", 13, MUTED_TEXT)
    content.add_child(_page_subtitle)
    content.add_child(HSeparator.new())
    _page_body = _make_label("V57 kaynakları korunarak gerçek 3D sürüme taşınıyor.", 14, TEXT_LIGHT)
    _page_body.custom_minimum_size = Vector2(0.0, 66.0)
    _page_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    content.add_child(_page_body)

    _menu_scroll = ScrollContainer.new()
    _menu_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _menu_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    content.add_child(_menu_scroll)
    _menu_buttons = VBoxContainer.new()
    _menu_buttons.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _menu_buttons.add_theme_constant_override("separation", 5)
    _menu_scroll.add_child(_menu_buttons)

    _menu_layer.hide()

func _make_label(text_value: String, font_size: int, color: Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.7))
    label.add_theme_constant_override("shadow_offset_x", 2)
    label.add_theme_constant_override("shadow_offset_y", 2)
    return label

func _make_button(label_text: String, min_width: int = 0) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(float(min_width), 40.0)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 15)
    button.add_theme_color_override("font_color", TEXT_LIGHT)
    button.add_theme_color_override("font_hover_color", PALE_GOLD)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.075, 0.09, 0.12, 0.94)
    normal.border_color = Color(0.39, 0.29, 0.16, 0.9)
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(6)
    normal.set_content_margin_all(6.0)
    button.add_theme_stylebox_override("normal", normal)
    var hover := normal.duplicate() as StyleBoxFlat
    hover.bg_color = Color(0.15, 0.13, 0.095, 0.98)
    hover.border_color = GOLD
    button.add_theme_stylebox_override("hover", hover)
    var pressed_style := normal.duplicate() as StyleBoxFlat
    pressed_style.bg_color = Color(0.20, 0.15, 0.085, 0.98)
    button.add_theme_stylebox_override("pressed", pressed_style)
    button.pressed.connect(_on_any_button_pressed)
    return button

func _add_menu_button(label_text: String, callback: Callable, disabled: bool = false) -> void:
    var button := _make_button(label_text)
    button.disabled = disabled
    button.pressed.connect(callback)
    _menu_buttons.add_child(button)

func _clear_menu_buttons() -> void:
    for child in _menu_buttons.get_children():
        child.queue_free()

func _set_page(title_value: String, subtitle_value: String, body_value: String) -> void:
    _menu_layer.show()
    _intro_layer.hide()
    _menu_panel.show()
    _page_title.text = title_value
    _page_subtitle.text = subtitle_value
    _page_body.text = body_value
    _clear_menu_buttons()

func _show_menu() -> void:
    _screen_mode = "menu"
    _menu_panel.show()
    _set_page("SPARTA ARENA", "REMASTERED • SPARTA WORLD", "Karanlık Antik Dünya'da savaş, fetih ve efsaneler. V57'nin 20 karakteri, 9 haritası ve 10 modunun katalogları yeni PC projesine taşındı. Yeni eklenen Metehan, V57'nin orijinal listesinde yoktu.")
    _add_menu_button("OYNA  /  TÜM OYUN MODLARI", _show_modes)
    _add_menu_button("KARAKTER SEÇİMİ", _show_characters)
    _add_menu_button("HARİTA SEÇİMİ", _show_maps)
    _add_menu_button("DÜNYA FETHİ  /  ŞEHİRLER", _show_world_conquest)
    _add_menu_button("DENİZ DÜNYASI  /  BALIKÇILIK", _show_sea_world)
    _add_menu_button("MAĞAZA  /  İKSİRLER / EKİPMAN", _show_shop)
    _add_menu_button("BAŞARIMLAR", _show_achievements)
    _add_menu_button("AYARLAR  /  KONTROLLER", _show_settings)
    _add_menu_button("GELİŞTİRİCİ ARAÇLARI", _show_developer_tools)
    _add_menu_button("TANITIMI OYNAT", _begin_intro)
    _add_menu_button("ÇIKIŞ", _quit_game)
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    AudioManager.play_menu_ambience()

func _show_modes() -> void:
    _screen_mode = "menu"
    _set_page("OYUN MODLARI", "V57 MOD LİSTESİ", "Bir mod seç; sonraki ekranda dokuz haritadan birini seçerek 3D oynanışı başlat. Bu ilk aktarım, ortak bir savaş döngüsü kullanır; V57'nin tüm özgün görev kuralları henüz birebir eşdeğer değildir.")
    for mode_data in _modes:
        var info: Dictionary = mode_data
        _add_menu_button(str(info.get("name", "Oyun modu")), Callable(self, "_choose_mode").bind(str(info.get("key", "classic"))))
    _add_menu_button("GERİ", _show_menu)

func _choose_mode(mode_key: String) -> void:
    _selected_mode_key = mode_key
    _show_maps()

func _show_characters() -> void:
    _show_character_page(0)

func _show_character_page(page: int) -> void:
    _screen_mode = "menu"
    var max_page := maxi(0, int(ceil(float(_characters.size()) / ITEMS_PER_PAGE)) - 1)
    var current_page := clampi(page, 0, max_page)
    var selected_name := str(_characters[int(_save_data.get("selected_character", 0))].get("name", "Spartalı"))
    _set_page("KARAKTERLER", "SAYFA %d / %d • %d KARAKTER" % [current_page + 1, max_page + 1, _characters.size()], "Seçili: %s. Karakterlerin temel hız/saldırı/savunma istatistikleri V57 listesinden aktarıldı. Görsel modeller şu an prosedürel 3D prototipidir; tarihî kişilere özel ayrıntılı model/animasyon dosyaları arşivde bulunmuyor." % selected_name)
    var first_index := current_page * ITEMS_PER_PAGE
    var last_index := mini(first_index + ITEMS_PER_PAGE, _characters.size())
    for i in range(first_index, last_index):
        var character: Dictionary = _characters[i]
        var locked := _is_character_locked(i)
        var marker := "✓ " if i == int(_save_data.get("selected_character", 0)) else ""
        var source_note := " • YENİ EKLENDİ" if not bool(character.get("source_v57", true)) else ""
        var info := "%s%s%s | Hız %.0f • Saldırı %d • Savunma %d • Can +%d%s" % [marker, str(character.get("name", "Savaşçı")), source_note, float(character.get("speed", 6.0)), int(character.get("attack", 5)), int(character.get("defense", 0)), int(character.get("hp_bonus", 0)), " • KİLİTLİ" if locked else ""]
        _add_menu_button(info, Callable(self, "_select_character").bind(i), locked)
    var prev := _make_button("‹ ÖNCEKİ", 0)
    prev.disabled = current_page <= 0
    prev.pressed.connect(Callable(self, "_show_character_page").bind(current_page - 1))
    _menu_buttons.add_child(prev)
    var next := _make_button("SONRAKİ ›", 0)
    next.disabled = current_page >= max_page
    next.pressed.connect(Callable(self, "_show_character_page").bind(current_page + 1))
    _menu_buttons.add_child(next)
    _add_menu_button("ANA MENÜ", _show_menu)

func _is_character_locked(index: int) -> bool:
    var character: Dictionary = _characters[index]
    var unlock: String = str(character.get("unlock", ""))
    var dev: Dictionary = _save_data.get("dev", {})
    if bool(dev.get("unlock_all", false)):
        return false
    if unlock == "classic5":
        return int(_save_data.get("classic_wins", 0)) < 5
    if unlock == "classic7":
        return int(_save_data.get("classic_wins", 0)) < 7
    return false

func _select_character(index: int) -> void:
    if index < 0 or index >= _characters.size() or _is_character_locked(index):
        return
    _save_data["selected_character"] = index
    _save_game()
    _show_character_page(int(index / ITEMS_PER_PAGE))

func _show_maps() -> void:
    _screen_mode = "menu"
    var mode_name := "Serbest seçim"
    for mode_data in _modes:
        if str(mode_data.get("key", "")) == _selected_mode_key:
            mode_name = str(mode_data.get("name", "Oyun modu"))
            break
    _set_page("HARİTA SEÇİMİ", "%d V57 HARİTASI • %s" % [_maps.size(), mode_name], "Harita düğmesine basınca renk/atmosfer teması değişir ve seçilen mod başlar. Bu aşamada dokuz tema 3D arena geometrisine uygulanır; her haritanın son çevre modelleri ve özel görevleri ayrıca geliştirilecek.")
    for i in range(_maps.size()):
        var map_data: Dictionary = _maps[i]
        var prefix := "✓ " if i == int(_save_data.get("selected_map", 0)) else ""
        _add_menu_button(prefix + str(map_data.get("name", "Harita")), Callable(self, "_select_map").bind(i))
    _add_menu_button("MODLARA GERİ DÖN", _show_modes)
    _add_menu_button("ANA MENÜ", _show_menu)

func _select_map(index: int) -> void:
    _save_data["selected_map"] = clampi(index, 0, _maps.size() - 1)
    _save_game()
    _apply_map_theme(int(_save_data["selected_map"]))
    _start_combat()

func _apply_map_theme(index: int) -> void:
    if _maps.is_empty() or not is_instance_valid(_arena_floor):
        return
    var safe_index := clampi(index, 0, _maps.size() - 1)
    var map_data: Dictionary = _maps[safe_index]
    var floor_color := _color_from(map_data.get("floor", []), Color(0.36, 0.29, 0.20))
    var sky_color := _color_from(map_data.get("sky", []), Color(0.012, 0.018, 0.032))
    var accent := _color_from(map_data.get("accent", []), GOLD)
    _arena_floor.material_override = _material(floor_color)
    if is_instance_valid(_world_environment) and _world_environment.environment != null:
        _world_environment.environment.background_color = sky_color
        _world_environment.environment.ambient_light_color = sky_color.lightened(0.40)
    if is_instance_valid(_map_decor):
        for child in _map_decor.get_children():
            child.queue_free()
        var theme := str(map_data.get("theme", "arena"))
        for i in range(8):
            var angle := TAU * float(i) / 8.0
            var radius := 8.8 if theme != "ice" else 8.2
            var p := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius)
            if theme == "desert" or theme == "temple":
                var obelisk := _add_cylinder(_map_decor, "ThemeObelisk_%d" % i, 0.20, 2.7 + float(i % 3) * 0.4, p + Vector3(0.0, 1.35, 0.0), accent, 6)
                obelisk.rotation.z = 0.10 * sin(angle)
            elif theme == "forest":
                _add_cylinder(_map_decor, "TreeTrunk_%d" % i, 0.25, 2.5, p + Vector3(0.0, 1.25, 0.0), Color(0.20, 0.12, 0.07), 8)
                _add_sphere(_map_decor, "TreeCanopy_%d" % i, 1.0, p + Vector3(0.0, 2.75, 0.0), accent)
            elif theme == "lava":
                _add_cylinder(_map_decor, "LavaSpire_%d" % i, 0.10, 2.6 + float(i % 4) * 0.3, p + Vector3(0.0, 1.25, 0.0), accent.darkened(0.35), 5)
            else:
                _add_box(_map_decor, "ThemePillar_%d" % i, Vector3(0.55, 2.2, 0.55), p + Vector3(0.0, 1.1, 0.0), accent.darkened(0.28))

func _show_shop() -> void:
    _screen_mode = "menu"
    _set_page("MAĞAZA / İKSİRLER", "ALTIN: %d" % int(_save_data.get("gold", 0)), "İksirler ve ekipman geliştirmeleri kalıcı kaydedilir. Saldırı/savunma yükseltmeleri yeni 3D savaş döngüsünde kullanılır.")
    _add_menu_button("Can İksiri +1  —  80 altın", Callable(self, "_buy_item").bind("potion", 80))
    _add_menu_button("Tam Can İksiri +1  —  120 altın", Callable(self, "_buy_item").bind("full_potion", 120))
    _add_menu_button("Kılıç Hasarı +5  —  220 altın", Callable(self, "_buy_item").bind("sword", 220))
    _add_menu_button("Zırh Savunması +2  —  180 altın", Callable(self, "_buy_item").bind("armor", 180))
    _add_menu_button("Savaş Gücü +3  —  200 altın", Callable(self, "_buy_item").bind("damage", 200))
    _add_menu_button("GERİ", _show_menu)

func _buy_item(item_key: String, cost: int) -> void:
    var gold := int(_save_data.get("gold", 0))
    var dev: Dictionary = _save_data.get("dev", {})
    if gold < cost and not bool(dev.get("infinite_gold", false)):
        _page_body.text = "Yeterli altın yok. Kazanmak için savaş modlarına gir veya deniz/dünya sistemlerini kullan."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = gold - cost
    match item_key:
        "potion": _save_data["potions"] = int(_save_data.get("potions", 0)) + 1
        "full_potion": _save_data["full_potions"] = int(_save_data.get("full_potions", 0)) + 1
        "sword": _save_data["sword_level"] = int(_save_data.get("sword_level", 0)) + 1
        "armor": _save_data["armor_level"] = int(_save_data.get("armor_level", 0)) + 1
        "damage": _save_data["damage_bonus"] = int(_save_data.get("damage_bonus", 0)) + 3
    _save_game()
    _show_shop()
    _page_body.text = "Satın alma başarılı. Kalan altın: %d" % int(_save_data.get("gold", 0))

func _show_achievements() -> void:
    _screen_mode = "menu"
    var wins := int(_save_data.get("classic_wins", 0))
    var kills := int(_save_data.get("total_kills", 0))
    var sea: Dictionary = _save_data.get("sea", {})
    var cities: Array = _save_data.get("captured_cities", [])
    var rows: Array[String] = []
    rows.append("%s İlk Zafer — Herhangi bir modu kazan" % _achievement_mark("first_win", wins > 0))
    rows.append("%s Arena Ustası — 5 klasik zafer (%d/5)" % [_achievement_mark("arena_master", wins >= 5), mini(wins, 5)])
    rows.append("%s Efsane Fatih — 7 klasik zafer (%d/7)" % [_achievement_mark("fatih_unlock", wins >= 7), mini(wins, 7)])
    rows.append("%s Demir Kılıç — 150 düşman yen (%d/150)" % [_achievement_mark("iron_sword", kills >= 150), mini(kills, 150)])
    rows.append("%s Denizci — 3 gemi al (%d/3)" % [_achievement_mark("sailor", int(sea.get("ships", 0)) >= 3), mini(int(sea.get("ships", 0)), 3)])
    rows.append("%s Deniz Kaşifi — 5 ada keşfet (%d/5)" % [_achievement_mark("sea_explorer", int(sea.get("islands_discovered", 0)) >= 5), mini(int(sea.get("islands_discovered", 0)), 5)])
    rows.append("%s Şehir Fatihi — 12 şehir ele geçir (%d/12)" % [_achievement_mark("conqueror", cities.size() >= 12), mini(cities.size(), 12)])
    rows.append("%s Zengin Savaşçı — 1000 altın biriktir (%d/1000)" % [_achievement_mark("rich", int(_save_data.get("gold", 0)) >= 1000), mini(int(_save_data.get("gold", 0)), 1000)])
    rows.append("%s Boss Avcısı — 3 boss yen (%d/3)" % [_achievement_mark("boss_hunter", int(_save_data.get("mode_stats", {}).get("bosses_defeated", 0)) >= 3), mini(int(_save_data.get("mode_stats", {}).get("bosses_defeated", 0)), 3)])
    var done := 0
    for row in rows:
        if row.begins_with("✓"):
            done += 1
    _set_page("BAŞARIMLAR", "%d / %d TAMAMLANDI" % [done, rows.size()], "Başarımlar kayıt verilerinden hesaplanır; V57'deki isimlerle birlikte Remastered sürümüne ait birkaç takip ölçütü eklendi.\n\n" + "\n".join(rows))
    _add_menu_button("ANA MENÜ", _show_menu)

func _achievement_mark(_key: String, unlocked: bool) -> String:
    return "✓" if unlocked else "◇"

func _refresh_achievement_flags() -> void:
    var flags: Dictionary = _save_data.get("achievements", {})
    var sea: Dictionary = _save_data.get("sea", {})
    var cities: Array = _save_data.get("captured_cities", [])
    var stats: Dictionary = _save_data.get("mode_stats", {})
    var wins := int(_save_data.get("classic_wins", 0))
    var kills := int(_save_data.get("total_kills", 0))
    flags["first_win"] = wins > 0 or int(_save_data.get("total_games", 0)) > 0
    flags["arena_master"] = wins >= 5
    flags["fatih_unlock"] = wins >= 7
    flags["iron_sword"] = kills >= 150
    flags["sailor"] = int(sea.get("ships", 0)) >= 3
    flags["sea_explorer"] = int(sea.get("islands_discovered", 0)) >= 5
    flags["conqueror"] = cities.size() >= 12
    flags["rich"] = int(_save_data.get("gold", 0)) >= 1000
    flags["boss_hunter"] = int(stats.get("bosses_defeated", 0)) >= 3
    _save_data["achievements"] = flags

func _show_settings() -> void:
    _screen_mode = "menu"
    var settings: Dictionary = _save_data.get("settings", {})
    var binds: Dictionary = _save_data.get("keybinds", {})
    _set_page("AYARLAR", "SES • EKRAN • KONTROLLER", "Yüksek frekanslı keskin UI click ve sword swish kullanılmıyor. Butonlar yumuşak dokunuş sesi, savaşta ise düşük seviyeli tok darbe sesi kullanır. Tuş atamak için ilgili düğmeye basıp yeni tuşa bas.")
    _add_menu_button("MÜZİK SESİ: %d%%  (değiştir)" % int(round(_music_volume * 100.0)), _cycle_music_volume)
    _add_menu_button("EFEKT SESİ: %d%%  (değiştir)" % int(round(_sfx_volume * 100.0)), _cycle_sfx_volume)
    _add_menu_button("EFEKT SESLERİ: %s" % ("AÇIK" if _sfx_enabled else "KAPALI"), _toggle_sfx)
    _add_menu_button("ZORLUK: %s" % _difficulty, _cycle_difficulty)
    _add_menu_button("KLASİK TUR LİMİTİ: %d" % int(_save_data.get("classic_round_limit", 30)), _cycle_round_limit)
    _add_menu_button("GÜNLÜK ÖDÜLÜ AL", _claim_daily_reward)
    _add_menu_button("TAM EKRAN: %s" % ("AÇIK" if bool(settings.get("fullscreen", false)) else "KAPALI"), _toggle_fullscreen)
    _add_menu_button("İLERİ TUŞU: %s" % _key_label(binds, "move_forward", KEY_W), Callable(self, "_request_rebind").bind("move_forward"))
    _add_menu_button("GERİ TUŞU: %s" % _key_label(binds, "move_back", KEY_S), Callable(self, "_request_rebind").bind("move_back"))
    _add_menu_button("SOL TUŞU: %s" % _key_label(binds, "move_left", KEY_A), Callable(self, "_request_rebind").bind("move_left"))
    _add_menu_button("SAĞ TUŞU: %s" % _key_label(binds, "move_right", KEY_D), Callable(self, "_request_rebind").bind("move_right"))
    _add_menu_button("SALDIRI TUŞU: %s" % _key_label(binds, "attack", KEY_SPACE), Callable(self, "_request_rebind").bind("attack"))
    _add_menu_button("İKSİR TUŞU: %s" % _key_label(binds, "potion", KEY_H), Callable(self, "_request_rebind").bind("potion"))
    _add_menu_button("GERİ", _show_menu)

func _key_label(binds: Dictionary, action: String, fallback: int) -> String:
    return OS.get_keycode_string(int(binds.get(action, fallback)))

func _request_rebind(action: String) -> void:
    _awaiting_rebind = action
    _page_body.text = "%s için yeni bir tuşa bas. İptal etmek için ESC." % action.replace("move_", "hareket ").to_upper()

func _cycle_music_volume() -> void:
    _music_volume = 0.0 if _music_volume >= 0.99 else minf(1.0, _music_volume + 0.25)
    AudioManager.set_music_volume(_music_volume)
    _save_game()
    _show_settings()

func _cycle_sfx_volume() -> void:
    _sfx_volume = 0.0 if _sfx_volume >= 0.99 else minf(1.0, _sfx_volume + 0.25)
    AudioManager.set_sfx_volume(_sfx_volume)
    _save_game()
    _show_settings()

func _toggle_sfx() -> void:
    _sfx_enabled = not _sfx_enabled
    AudioManager.set_sfx_enabled(_sfx_enabled)
    _save_game()
    _show_settings()

func _cycle_round_limit() -> void:
    var current := int(_save_data.get("classic_round_limit", 30))
    if current == 30:
        current = 60
    elif current == 60:
        current = 90
    elif current == 90:
        current = 120
    else:
        current = 30
    _save_data["classic_round_limit"] = current
    _save_game()
    _show_settings()

func _claim_daily_reward() -> void:
    var today := Time.get_date_string_from_system()
    if str(_save_data.get("daily_reward_date", "")) == today:
        _page_body.text = "Bugünkü günlük ödülünü zaten aldın. Yarın tekrar gel."
        return
    var reward := 100 + mini(400, int(_save_data.get("classic_wins", 0)) * 20)
    _save_data["gold"] = int(_save_data.get("gold", 0)) + reward
    _save_data["daily_reward_date"] = today
    _save_game()
    _show_settings()
    _page_body.text = "Günlük ödül alındı: +%d altın." % reward

func _cycle_difficulty() -> void:
    if _difficulty == "KOLAY":
        _difficulty = "ORTA"
    elif _difficulty == "ORTA":
        _difficulty = "ZOR"
    else:
        _difficulty = "KOLAY"
    _save_game()
    _show_settings()

func _toggle_fullscreen() -> void:
    var settings: Dictionary = _save_data.get("settings", {})
    var full := not bool(settings.get("fullscreen", false))
    settings["fullscreen"] = full
    _save_data["settings"] = settings
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if full else DisplayServer.WINDOW_MODE_WINDOWED)
    _save_game()
    _show_settings()

func _show_developer_tools() -> void:
    _screen_mode = "menu"
    var dev: Dictionary = _save_data.get("dev", {})
    _set_page("GELİŞTİRİCİ ARAÇLARI", "TEST / HATA AYIKLAMA", "Bunlar tek oyunculu yerel test seçenekleridir; çok oyunculu adalet veya çevrim içi sunucu özelliği değildir.")
    _add_menu_button("TÜM KARAKTERLERİ AÇ: %s" % ("AÇIK" if bool(dev.get("unlock_all", false)) else "KAPALI"), _toggle_unlock_all)
    _add_menu_button("SINIRSIZ ALTIN: %s" % ("AÇIK" if bool(dev.get("infinite_gold", false)) else "KAPALI"), _toggle_infinite_gold)
    _add_menu_button("500 ALTIN TEST HEDİYESİ", _dev_gold_gift)
    _add_menu_button("KAYIT İSTATİSTİKLERİNİ SIFIRLA", _reset_progress_confirm)
    _add_menu_button("ANA MENÜ", _show_menu)

func _toggle_unlock_all() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    dev["unlock_all"] = not bool(dev.get("unlock_all", false))
    _save_data["dev"] = dev
    _save_game()
    _show_developer_tools()

func _toggle_infinite_gold() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    dev["infinite_gold"] = not bool(dev.get("infinite_gold", false))
    _save_data["dev"] = dev
    _save_game()
    _show_developer_tools()

func _dev_gold_gift() -> void:
    _save_data["gold"] = int(_save_data.get("gold", 0)) + 500
    _save_game()
    _show_developer_tools()

func _reset_progress_confirm() -> void:
    _set_page("KAYIT SIFIRLAMA", "BU İŞLEM GERİ ALINAMAZ", "Remastered kayıt dosyasındaki altın, karakter seçimi, fetih, deniz ve başarımlar sıfırlanacak. Eski V57 kaynak dosyaları etkilenmez.")
    _add_menu_button("EVET, REMASTERED KAYDINI SIFIRLA", _reset_progress)
    _add_menu_button("VAZGEÇ", _show_developer_tools)

func _reset_progress() -> void:
    _save_data = _default_save_data()
    _save_game()
    _show_menu()

func _show_world_conquest() -> void:
    _screen_mode = "menu"
    var cities: Array = _save_data.get("captured_cities", [])
    var total_cities := _city_pools.size() * 12
    var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
    var target_name := ""
    if continent_index < _city_pools.size():
        for candidate in _city_pools[continent_index]:
            if not cities.has(candidate):
                target_name = str(candidate)
                break
    var city_name := target_name if target_name != "" else "Bu kıtadaki tüm şehirler fethedildi"
    _set_page("DÜNYA FETHİ", "KITA %d / %d • ŞEHİRLER • ORDU" % [continent_index + 1, _city_pools.size()], "Fethedilen şehir: %d / %d\nOrdu: %d • Altın: %d\nSıradaki hedef: %s\n\nŞehir ilerlemesi ve kayıt işlevleri aktarıldı. V57'nin 2D haritasındaki ordu hareketi, bağımsız devlet yapısı ve kuşatma yapay zekâsı henüz 3D karşılığına taşınmadı." % [cities.size(), total_cities, int(_save_data.get("troops", 0)), int(_save_data.get("gold", 0)), city_name])
    _add_menu_button("SIRADAKİ ŞEHRİ FETHE GİT (100 ALTIN)", _capture_next_city, target_name == "")
    _add_menu_button("ASKER TOPLA (+10) — 80 ALTIN", _recruit_troops)
    _add_menu_button("SONRAKİ KITAYA GEÇ", _next_continent)
    _add_menu_button("ANA MENÜ", _show_menu)

func _capture_next_city() -> void:
    var cities: Array = _save_data.get("captured_cities", [])
    var total_cities := _city_pools.size() * 12
    if cities.size() >= total_cities:
        _show_world_conquest()
        return
    var continent_index := clampi(int(_save_data.get("conquest_continent", 0)), 0, maxi(_city_pools.size() - 1, 0))
    var target_name := ""
    if continent_index < _city_pools.size():
        for candidate in _city_pools[continent_index]:
            if not cities.has(candidate):
                target_name = str(candidate)
                break
    if target_name == "":
        _page_body.text = "Bu kıtadaki şehirlerin tamamı fethedildi. Sonraki kıtaya geç."
        return
    var dev: Dictionary = _save_data.get("dev", {})
    if int(_save_data.get("gold", 0)) < 100 and not bool(dev.get("infinite_gold", false)):
        _page_body.text = "Şehir seferi için en az 100 altın gerekiyor."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = int(_save_data.get("gold", 0)) - 100
    cities.append(target_name)
    _save_data["captured_cities"] = cities
    _save_data["gold"] = int(_save_data.get("gold", 0)) + 160
    _save_game()
    _show_world_conquest()
    _page_body.text = "%s fethedildi! +160 altın. Toplam şehir: %d" % [target_name, cities.size()]

func _recruit_troops() -> void:
    var dev: Dictionary = _save_data.get("dev", {})
    if int(_save_data.get("gold", 0)) < 80 and not bool(dev.get("infinite_gold", false)):
        _page_body.text = "Asker toplamak için 80 altın gerekiyor."
        return
    if not bool(dev.get("infinite_gold", false)):
        _save_data["gold"] = int(_save_data.get("gold", 0)) - 80
    _save_data["troops"] = int(_save_data.get("troops", 0)) + 10
    _save_game()
    _show_world_conquest()

func _next_continent() -> void:
    _save_data["conquest_continent"] = (int(_save_data.get("conquest_continent", 0)) + 1) % maxi(_city_pools.size(), 1)
    _save_game()
    _show_world_conquest()

func _show_sea_world() -> void:
    _screen_mode = "menu"
    var sea: Dictionary = _save_data.get("sea", {})
    _set_page("DENİZ DÜNYASI", "KEŞİF • BALIKÇILIK • GEMİLER", "Deniz ilerlemesi ayrı kaydedilir. Balık tutma, keşif, olta yükseltmesi ve gemi satın alma işlevleri aktif. V57'deki tam deniz savaşı/ada sahnesinin 3D geometrileri henüz birebir port edilmedi.\n\nGemi: %d • Olta seviyesi: %d • Balık: %d • Ada: %d/5\nDeniz altını: %d" % [int(sea.get("ships", 0)), int(sea.get("rod_level", 1)), int(sea.get("fish_caught", 0)), int(sea.get("islands_discovered", 0)), int(sea.get("gold", 300))])
    _add_menu_button("BALIK TUT", _fish_now)
    _add_menu_button("AÇIK DENİZİ KEŞFET (75 DENİZ ALTINI)", _explore_sea)
    _add_menu_button("OLTA SEVİYESİNİ YÜKSELT (120 DENİZ ALTINI)", _upgrade_rod)
    _add_menu_button("GEMİ SATIN AL (250 DENİZ ALTINI)", _buy_ship)
    _add_menu_button("DENİZ HAZİNESİNİ ANA ALTINA ÇEVİR", _convert_sea_gold)
    _add_menu_button("ANA MENÜ", _show_menu)

func _fish_now() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var reward := randi_range(8, 28) * int(sea.get("rod_level", 1))
    sea["fish_caught"] = int(sea.get("fish_caught", 0)) + 1
    sea["gold"] = int(sea.get("gold", 300)) + reward
    sea["relics"] = int(sea.get("relics", 0)) + (1 if randf() < 0.05 else 0)
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()
    _page_body.text += "\nBalık yakaladın; +%d deniz altını." % reward

func _explore_sea() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("gold", 300)) < 75:
        _page_body.text = "Keşif için 75 deniz altını gerekiyor. Önce balık tut."
        return
    sea["gold"] = int(sea.get("gold", 300)) - 75
    sea["sea_runs"] = int(sea.get("sea_runs", 0)) + 1
    if int(sea.get("islands_discovered", 0)) < 5:
        sea["islands_discovered"] = int(sea.get("islands_discovered", 0)) + 1
        sea["map_fragments"] = int(sea.get("map_fragments", 0)) + 1
    var reward := randi_range(55, 125)
    sea["gold"] = int(sea.get("gold", 0)) + reward
    var stats: Dictionary = _save_data.get("mode_stats", {})
    stats["sea_runs"] = int(stats.get("sea_runs", 0)) + 1
    _save_data["mode_stats"] = stats
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()
    _page_body.text += "\nKeşif tamamlandı; +%d deniz altını ve harita parçası." % reward

func _upgrade_rod() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var cost := 120 * int(sea.get("rod_level", 1))
    if int(sea.get("gold", 300)) < cost:
        _page_body.text = "Olta yükseltmesi için %d deniz altını gerekiyor." % cost
        return
    sea["gold"] = int(sea.get("gold", 0)) - cost
    sea["rod_level"] = int(sea.get("rod_level", 1)) + 1
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _buy_ship() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    if int(sea.get("gold", 300)) < 250:
        _page_body.text = "Gemi için 250 deniz altını gerekiyor."
        return
    sea["gold"] = int(sea.get("gold", 0)) - 250
    sea["ships"] = int(sea.get("ships", 0)) + 1
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _convert_sea_gold() -> void:
    var sea: Dictionary = _save_data.get("sea", {})
    var amount := int(sea.get("gold", 0))
    var convert := int(amount / 2)
    sea["gold"] = amount - convert
    _save_data["gold"] = int(_save_data.get("gold", 0)) + convert
    _save_data["sea"] = sea
    _save_game()
    _show_sea_world()

func _start_combat() -> void:
    _screen_mode = "combat"
    _combat_ended = false
    _wave_transition_pending = false
    _wave_delay = 0.0
    _wave = 0
    _kills_this_run = 0
    _hill_progress = 0.0
    _attack_cooldown = 0.0
    _enemy_hit_cooldown = 0.0
    _mode_time_left = 90.0
    _combat_max_health = 100.0 + float(_current_character().get("hp_bonus", 0)) + float(_save_data.get("armor_level", 0)) * 5.0
    _combat_health = _combat_max_health
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.hide()
    _clear_combat_nodes()
    var character: Dictionary = _current_character()
    _player = _make_warrior(Vector3(0.0, 0.0, 5.0), _color_from(character.get("armor", []), Color(0.6, 0.4, 0.2)), _color_from(character.get("cape", []), Color(0.7, 0.15, 0.1)))
    _player.name = "PlayerCharacter"
    _camera.position = Vector3(0.0, 6.5, 15.0)
    _camera.look_at(_player.position + Vector3(0.0, 1.1, -1.0), Vector3.UP)
    _set_page("SAVAŞ BAŞLIYOR", str(_current_mode_name()) + " • " + str(_current_map_name()), "WASD/ok tuşlarıyla hareket • Space/sol tık ile saldırı • H ile iksir • ESC ile duraklat. Bu ortak 3D savaş döngüsünün yanında V57'nin özgün görev mantıkları aşama aşama ayrıştırılacak.")
    _add_menu_button("SALDIR  /  SPACE veya SOL TIK", Callable(self, "_perform_attack"))
    _add_menu_button("İKSİR KULLAN  /  H", _use_potion)
    _add_menu_button("DURAKLAT / MENÜ", _show_pause_menu)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _spawn_wave()
    AudioManager.play_menu_ambience()

func _clear_combat_nodes() -> void:
    for enemy in _enemies:
        var node: Node3D = enemy.get("node")
        if is_instance_valid(node):
            node.queue_free()
    _enemies.clear()
    if is_instance_valid(_player):
        _player.queue_free()
    _player = null

func _spawn_wave() -> void:
    _wave += 1
    _wave_transition_pending = false
    var mode_key := _selected_mode_key
    var is_boss := mode_key == "boss" or mode_key == "storm" or (mode_key == "classic" and _wave % 10 == 0)
    var enemy_count := 1 if is_boss else clampi(2 + _wave, 2, 7)
    if mode_key == "boss" or mode_key == "storm":
        enemy_count = 1
    for i in range(enemy_count):
        var angle := TAU * float(i) / float(maxi(enemy_count, 1)) + randf_range(-0.15, 0.15)
        var radius := 6.0 + randf_range(0.0, 2.2)
        var position := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius - 0.4)
        var color := Color(0.18 + randf() * 0.15, 0.20, 0.23)
        var crest := Color(0.52, 0.12, 0.08) if not is_boss else Color(0.80, 0.17, 0.045)
        var enemy_node := _make_warrior(position, color, crest)
        enemy_node.name = "Enemy_%d_%d" % [_wave, i]
        var hp := 34.0 + float(_wave) * 10.0
        if is_boss:
            hp = 260.0 + float(_wave) * 24.0
            enemy_node.scale = Vector3(1.7, 1.7, 1.7)
        _enemies.append({"node":enemy_node, "hp":hp, "max_hp":hp, "boss":is_boss, "cooldown":randf_range(0.3, 0.9), "dead":false})
    _refresh_combat_hud()

func _update_combat(delta: float) -> void:
    if not is_instance_valid(_player) or _combat_ended:
        return
    _attack_cooldown = maxf(0.0, _attack_cooldown - delta)
    _enemy_hit_cooldown = maxf(0.0, _enemy_hit_cooldown - delta)
    var direction := Vector3.ZERO
    if _is_bound_pressed("move_forward", KEY_W) or Input.is_key_pressed(KEY_UP):
        direction.z -= 1.0
    if _is_bound_pressed("move_back", KEY_S) or Input.is_key_pressed(KEY_DOWN):
        direction.z += 1.0
    if _is_bound_pressed("move_left", KEY_A) or Input.is_key_pressed(KEY_LEFT):
        direction.x -= 1.0
    if _is_bound_pressed("move_right", KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        direction.x += 1.0
    if direction.length() > 0.01:
        direction = direction.normalized()
        var move_speed := float(_current_character().get("speed", 6.0)) * 0.58
        _player.position += direction * move_speed * delta
        _player.position.x = clampf(_player.position.x, -10.3, 10.3)
        _player.position.z = clampf(_player.position.z, -10.3, 10.3)
        _player.rotation.y = atan2(-direction.x, -direction.z)

    var attack_down := _is_bound_pressed("attack", KEY_SPACE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
    if attack_down and not _attack_was_down and _attack_cooldown <= 0.0:
        _perform_attack()
    _attack_was_down = attack_down
    var potion_down := _is_bound_pressed("potion", KEY_H)
    if potion_down and not _potion_was_down:
        _use_potion()
    _potion_was_down = potion_down

    for i in range(_enemies.size()):
        var enemy_data: Dictionary = _enemies[i]
        var node: Node3D = enemy_data.get("node")
        if not is_instance_valid(node):
            enemy_data["dead"] = true
            _enemies[i] = enemy_data
            continue
        var to_player := _player.position - node.position
        to_player.y = 0.0
        var distance := to_player.length()
        if distance > 1.7:
            var move_speed := 1.25 + minf(float(_wave) * 0.06, 0.8)
            if bool(enemy_data.get("boss", false)):
                move_speed *= 0.72
            node.position += to_player.normalized() * move_speed * delta
            if to_player.length() > 0.01:
                node.rotation.y = atan2(-to_player.x, -to_player.z)
        enemy_data["cooldown"] = float(enemy_data.get("cooldown", 0.5)) - delta
        if distance < 1.85 and float(enemy_data["cooldown"]) <= 0.0 and _enemy_hit_cooldown <= 0.0:
            var damage := 5 + int(_wave / 3)
            if bool(enemy_data.get("boss", false)):
                damage += 7
            var char_defense := int(_current_character().get("defense", 0)) + int(_save_data.get("defense_bonus", 0)) + int(_save_data.get("armor_level", 0)) * 2
            _combat_health -= maxf(2.0, float(damage - int(char_defense / 3)))
            enemy_data["cooldown"] = 1.0 if not bool(enemy_data.get("boss", false)) else 1.3
            _enemy_hit_cooldown = 0.22
            AudioManager.play_muted_impact()
        _enemies[i] = enemy_data

    _remove_dead_enemies()
    if _combat_health <= 0.0:
        _finish_combat(false, "Savaşçı düştü. Ekipmanlarını yükseltip tekrar dene.")
        return

    if _selected_mode_key == "hill":
        if _player.position.length() < 3.5:
            _hill_progress += delta
        else:
            _hill_progress = maxf(0.0, _hill_progress - delta * 0.2)
        if _hill_progress >= 35.0:
            _finish_combat(true, "Tepe kontrol altında tutuldu!")
            return
    elif _selected_mode_key == "bear" or _selected_mode_key == "hide_seek":
        _mode_time_left -= delta
        if _mode_time_left <= 0.0:
            _finish_combat(true, "Süre doldu; hayatta kaldın!")
            return
    elif _selected_mode_key == "hot_potato":
        _mode_time_left -= delta
        if _mode_time_left <= 0.0:
            _mode_time_left = 35.0
            _combat_health -= 18.0
            if _combat_health <= 0.0:
                _finish_combat(false, "Süre baskısı çok arttı.")
                return
    if _wave_transition_pending:
        _wave_delay -= delta
        if _wave_delay <= 0.0:
            if _should_finish_after_wave():
                _finish_combat(true, _success_text())
                return
            _spawn_wave()
    elif _enemies.is_empty():
        _wave_transition_pending = true
        _wave_delay = 1.2
    _hud_tick -= delta
    if _hud_tick <= 0.0:
        _hud_tick = 0.22
        _refresh_combat_hud()
    var desired_camera := _player.position + Vector3(0.0, 5.6, 10.5)
    _camera.position = _camera.position.lerp(desired_camera, clampf(delta * 4.0, 0.0, 1.0))
    _camera.look_at(_player.position + Vector3(0.0, 1.0, -1.6), Vector3.UP)

func _is_bound_pressed(action: String, fallback: int) -> bool:
    var binds: Dictionary = _save_data.get("keybinds", {})
    return Input.is_key_pressed(int(binds.get(action, fallback)))

func _remove_dead_enemies() -> void:
    var survivors: Array[Dictionary] = []
    for enemy_data in _enemies:
        if bool(enemy_data.get("dead", false)):
            continue
        var node: Node3D = enemy_data.get("node")
        if is_instance_valid(node):
            survivors.append(enemy_data)
    _enemies = survivors

func _perform_attack() -> void:
    if _screen_mode != "combat" or _combat_ended or _attack_cooldown > 0.0:
        return
    _attack_cooldown = 0.48
    AudioManager.play_muted_impact()
    if _enemies.is_empty():
        return
    var target_index := -1
    var nearest := 3.2
    for i in range(_enemies.size()):
        var enemy_data: Dictionary = _enemies[i]
        var node: Node3D = enemy_data.get("node")
        if not is_instance_valid(node):
            continue
        var distance := Vector2(node.position.x - _player.position.x, node.position.z - _player.position.z).length()
        if distance <= nearest:
            nearest = distance
            target_index = i
    if target_index < 0:
        _page_body.text = "Saldırı boşa gitti; düşmana yaklaş."
        return
    var target: Dictionary = _enemies[target_index]
    var character := _current_character()
    var damage := int(character.get("attack", 7)) + int(_save_data.get("damage_bonus", 0)) + int(_save_data.get("sword_level", 0)) * 5
    damage = int(round(float(damage) * _difficulty_multiplier()))
    target["hp"] = float(target.get("hp", 30.0)) - float(damage)
    var node: Node3D = target.get("node")
    if float(target["hp"]) <= 0.0:
        if is_instance_valid(node):
            node.queue_free()
        _enemies.remove_at(target_index)
        _kills_this_run += 1
        _save_data["total_kills"] = int(_save_data.get("total_kills", 0)) + 1
        _save_data["gold"] = int(_save_data.get("gold", 0)) + (18 if not bool(target.get("boss", false)) else 110)
        if bool(target.get("boss", false)):
            var stats: Dictionary = _save_data.get("mode_stats", {})
            stats["bosses_defeated"] = int(stats.get("bosses_defeated", 0)) + 1
            _save_data["mode_stats"] = stats
        _save_game()
        _page_body.text = "Düşman alt edildi! +%d altın. Saldırı: %d" % [18 if not bool(target.get("boss", false)) else 110, damage]
    else:
        _enemies[target_index] = target
        _page_body.text = "Vuruş: %d hasar. Hedefin kalan canı: %d" % [damage, int(target["hp"])]
    _refresh_combat_hud()

func _use_potion() -> void:
    if _screen_mode != "combat" or _combat_ended:
        return
    if int(_save_data.get("full_potions", 0)) > 0:
        _save_data["full_potions"] = int(_save_data.get("full_potions", 0)) - 1
        _combat_health = _combat_max_health
        _save_game()
    elif int(_save_data.get("potions", 0)) > 0:
        _save_data["potions"] = int(_save_data.get("potions", 0)) - 1
        _combat_health = minf(_combat_max_health, _combat_health + _combat_max_health * 0.45)
        _save_game()
    else:
        _page_body.text = "İksir yok. Mağazadan alabilirsin."
    _refresh_combat_hud()

func _should_finish_after_wave() -> bool:
    match _selected_mode_key:
        "classic": return _wave >= int(_save_data.get("classic_round_limit", 30))
        "caravan": return _wave >= 5
        "castle": return _wave >= 8
        "boss", "storm": return _wave >= 1
        "bear", "hide_seek", "hill", "hot_potato": return false
        _: return false

func _success_text() -> String:
    match _selected_mode_key:
        "classic": return "Klasik tur serisi tamamlandı!"
        "caravan": return "Kervan 5 dalgayı atlattı!"
        "castle": return "Kale kapısı ele geçirildi!"
        "boss": return "Efsanevi boss yenildi!"
        "storm": return "Fırtına düellosu kazanıldı!"
        "hill": return "Tepenin kralı oldun!"
        "bear": return "Ayıdan kurtuldun!"
        "hide_seek": return "Saklambaç mücadelesini tamamladın!"
        _: return "Zafer!"

func _finish_combat(victory: bool, message: String) -> void:
    if _combat_ended:
        return
    _combat_ended = true
    if victory:
        _save_data["total_games"] = int(_save_data.get("total_games", 0)) + 1
        _save_data["gold"] = int(_save_data.get("gold", 0)) + 100 + _wave * 12
        if _selected_mode_key == "classic":
            _save_data["classic_wins"] = int(_save_data.get("classic_wins", 0)) + 1
        if _selected_mode_key == "hill":
            var stats: Dictionary = _save_data.get("mode_stats", {})
            stats["hill_wins"] = int(stats.get("hill_wins", 0)) + 1
            _save_data["mode_stats"] = stats
    _last_result_text = message
    _save_game()
    _remove_dead_enemies()
    _clear_combat_nodes()
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    _screen_mode = "menu"
    _set_page("ZAFER" if victory else "YENİLGİ", _current_mode_name(), "%s\n\nBu denemede yenilen düşman: %d\nKlasik zafer: %d\nAltın: %d\n\nKazanımlar otomatik kaydedildi." % [message, _kills_this_run, int(_save_data.get("classic_wins", 0)), int(_save_data.get("gold", 0))])
    _add_menu_button("AYNI MODU TEKRAR OYNA", _start_combat)
    _add_menu_button("MOD SEÇİMİ", _show_modes)
    _add_menu_button("MAĞAZA / İKSİRLER", _show_shop)
    _add_menu_button("ANA MENÜ", _show_menu)
    if victory:
        AudioManager.play_menu_ambience()

func _show_pause_menu() -> void:
    if _screen_mode != "combat":
        return
    _screen_mode = "paused"
    _set_page("DURAKLATILDI", _current_mode_name(), "Oyun geçici olarak durdu.")
    _add_menu_button("DEVAM ET", _resume_combat)
    _add_menu_button("MODU YENİDEN BAŞLAT", _start_combat)
    _add_menu_button("ANA MENÜYE DÖN", _return_to_menu)

func _resume_combat() -> void:
    if _combat_ended:
        return
    _screen_mode = "combat"
    _set_page("SAVAŞ", _current_mode_name(), "WASD/ok tuşları hareket • Space/sol tık saldırı • H iksir • ESC duraklat.")
    _add_menu_button("SALDIR  /  SPACE veya SOL TIK", Callable(self, "_perform_attack"))
    _add_menu_button("İKSİR KULLAN  /  H", _use_potion)
    _add_menu_button("DURAKLAT / MENÜ", _show_pause_menu)

func _return_to_menu() -> void:
    _clear_combat_nodes()
    _combat_ended = true
    for warrior in _menu_warriors:
        if is_instance_valid(warrior):
            warrior.show()
    _show_menu()

func _refresh_combat_hud() -> void:
    if not is_instance_valid(_page_body) or _screen_mode != "combat":
        return
    var mode_key := _selected_mode_key
    var objective := "Dalga %d • Düşman: %d" % [_wave, _enemies.size()]
    if mode_key == "hill":
        objective = "Tepede kal: %.1f / 35 saniye • Düşman: %d" % [_hill_progress, _enemies.size()]
    elif mode_key == "bear" or mode_key == "hide_seek":
        objective = "Hayatta kalma: %d saniye • Düşman: %d" % [int(maxf(0.0, _mode_time_left)), _enemies.size()]
    elif mode_key == "hot_potato":
        objective = "Zaman baskısı: %d saniye • Düşman: %d" % [int(maxf(0.0, _mode_time_left)), _enemies.size()]
    _page_body.text = "%s\nHarita: %s • Karakter: %s\nCan: %d / %d • İksir: %d + %d tam\nAltın: %d\n\n%s" % [_current_mode_name(), _current_map_name(), _current_character().get("name", "Savaşçı"), int(maxf(0.0, _combat_health)), int(_combat_max_health), int(_save_data.get("potions", 0)), int(_save_data.get("full_potions", 0)), int(_save_data.get("gold", 0)), objective]

func _difficulty_multiplier() -> float:
    if _difficulty == "KOLAY":
        return 1.20
    if _difficulty == "ZOR":
        return 0.78
    return 1.0

func _current_character() -> Dictionary:
    var index := clampi(int(_save_data.get("selected_character", 0)), 0, _characters.size() - 1)
    return _characters[index]

func _current_mode_name() -> String:
    for mode_data in _modes:
        if str(mode_data.get("key", "")) == _selected_mode_key:
            return str(mode_data.get("name", "Savaş"))
    return "Savaş"

func _current_map_name() -> String:
    var index := clampi(int(_save_data.get("selected_map", 0)), 0, _maps.size() - 1)
    return str(_maps[index].get("name", "Arena"))

func _begin_intro() -> void:
    _screen_mode = "intro"
    _intro_time = 0.0
    _intro_progress.value = 0.0
    _intro_title.modulate.a = 0.0
    _intro_subtitle.modulate.a = 0.0
    _menu_layer.hide()
    _intro_layer.show()
    AudioManager.play_intro_score()

func _finish_intro() -> void:
    if _screen_mode != "intro":
        return
    _intro_seen = true
    _save_preferences()
    _show_menu()
    AudioManager.play_menu_ambience()

func _on_skip_pressed() -> void:
    _finish_intro()

func _on_any_button_pressed() -> void:
    AudioManager.play_ui()

func _quit_game() -> void:
    _save_game()
    get_tree().quit()

func _update_intro_camera() -> void:
    var t := clampf(_intro_time / INTRO_DURATION, 0.0, 1.0)
    var angle := -0.9 + t * 2.2
    var radius := lerpf(25.0, 15.8, smoothstep(0.0, 1.0, t))
    var height := 8.5 + sin(t * TAU * 1.15) * 1.25
    _camera.position = Vector3(sin(angle) * radius, height, cos(angle) * radius)
    _camera.look_at(Vector3(0.0, 1.25, 0.0), Vector3.UP)

func _update_menu_camera(delta: float) -> void:
    if not is_instance_valid(_camera):
        return
    var t := float(Time.get_ticks_msec()) / 1000.0
    var desired := Vector3(sin(t * 0.10) * 2.2, 7.2 + sin(t * 0.16) * 0.25, 22.2 + cos(t * 0.08) * 1.0)
    _camera.position = _camera.position.lerp(desired, clampf(delta * 0.4, 0.0, 1.0))
    _camera.look_at(Vector3(0.0, 1.25, 0.0), Vector3.UP)

func _material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.82
    return mat

func _add_box(parent: Node3D, object_name: String, dimensions: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_cylinder(parent: Node3D, object_name: String, radius: float, height: float, pos: Vector3, color: Color, segments: int = 24) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh.radial_segments = segments
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_torus(parent: Node3D, object_name: String, outer_radius: float, inner_radius: float, pos: Vector3, color: Color) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := TorusMesh.new()
    mesh.outer_radius = outer_radius
    mesh.inner_radius = inner_radius
    mesh.rings = 72
    mesh.ring_segments = 12
    item.mesh = mesh
    item.position = pos
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _add_sphere(parent: Node3D, object_name: String, radius: float, pos: Vector3, color: Color, material: StandardMaterial3D = null) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    item.mesh = mesh
    item.position = pos
    item.material_override = material if material != null else _material(color)
    parent.add_child(item)
    return item

func _make_warrior(pos: Vector3, armor_color: Color, crest_color: Color) -> Node3D:
    var warrior := Node3D.new()
    warrior.name = "ProceduralWarrior"
    warrior.position = pos
    add_child(warrior)

    var torso := CapsuleMesh.new()
    torso.radius = 0.38
    torso.height = 1.15
    _add_mesh_part(warrior, "BronzeArmor", torso, Vector3(0.0, 1.22, 0.0), armor_color, Vector3.ZERO, Vector3(1.0, 1.0, 0.75))
    _add_sphere(warrior, "Head", 0.27, Vector3(0.0, 1.98, 0.0), Color(0.62, 0.42, 0.30))

    var helmet := SphereMesh.new()
    helmet.radius = 0.31
    helmet.height = 0.45
    _add_mesh_part(warrior, "Helmet", helmet, Vector3(0.0, 2.13, 0.0), Color(0.50, 0.39, 0.22), Vector3.ZERO, Vector3(1.1, 0.65, 1.0))
    _add_box(warrior, "HelmetNoseGuard", Vector3(0.09, 0.30, 0.12), Vector3(0.0, 1.98, 0.25), Color(0.55, 0.43, 0.24))
    _add_box(warrior, "HelmetCrest", Vector3(0.09, 0.35, 0.48), Vector3(0.0, 2.40, -0.015), crest_color)

    var arm_mesh := CylinderMesh.new()
    arm_mesh.top_radius = 0.13
    arm_mesh.bottom_radius = 0.16
    arm_mesh.height = 0.74
    _add_mesh_part(warrior, "LeftArm", arm_mesh, Vector3(-0.48, 1.30, 0.0), armor_color.darkened(0.08), Vector3(0.0, 0.0, -22.0), Vector3.ONE)
    _add_mesh_part(warrior, "RightArm", arm_mesh, Vector3(0.48, 1.30, 0.0), armor_color.darkened(0.08), Vector3(0.0, 0.0, 22.0), Vector3.ONE)
    var leg_mesh := CylinderMesh.new()
    leg_mesh.top_radius = 0.14
    leg_mesh.bottom_radius = 0.12
    leg_mesh.height = 0.72
    _add_mesh_part(warrior, "LeftLeg", leg_mesh, Vector3(-0.20, 0.38, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)
    _add_mesh_part(warrior, "RightLeg", leg_mesh, Vector3(0.20, 0.38, 0.0), Color(0.22, 0.20, 0.18), Vector3.ZERO, Vector3.ONE)
    _add_box(warrior, "ClothCape", Vector3(0.66, 0.98, 0.13), Vector3(0.0, 1.21, -0.32), crest_color.darkened(0.12))
    _add_box(warrior, "BronzeWaistBand", Vector3(0.72, 0.13, 0.52), Vector3(0.0, 0.83, 0.0), Color(0.55, 0.40, 0.20))
    _add_box(warrior, "SwordBlade", Vector3(0.075, 0.72, 0.10), Vector3(0.59, 1.14, -0.10), Color(0.64, 0.69, 0.72))
    _add_box(warrior, "SwordGrip", Vector3(0.12, 0.18, 0.14), Vector3(0.59, 0.73, -0.10), Color(0.24, 0.14, 0.08))
    return warrior

func _add_mesh_part(parent: Node3D, object_name: String, mesh: Mesh, pos: Vector3, color: Color, rot_deg: Vector3, scale_value: Vector3) -> MeshInstance3D:
    var item := MeshInstance3D.new()
    item.name = object_name
    item.mesh = mesh
    item.position = pos
    item.rotation_degrees = rot_deg
    item.scale = scale_value
    item.material_override = _material(color)
    parent.add_child(item)
    return item

func _color_from(parts: Variant, fallback: Color) -> Color:
    if parts is Array and parts.size() >= 3:
        return Color(float(parts[0]), float(parts[1]), float(parts[2]))
    return fallback
